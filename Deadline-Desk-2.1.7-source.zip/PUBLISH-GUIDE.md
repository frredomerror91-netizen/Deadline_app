# v2.1.7 GitHub 发布指南

本目录只准备本地发布资料，尚未提交、推送、上传或创建 GitHub Release。

## 发布前核验

1. 在 Windows x64 上按 `SOURCE-README.md` 安装依赖并运行 `pnpm run test:unit`、`pnpm run test:v217` 与 `pnpm run test:edit`。
2. 在版本目录执行 `pnpm run dist`，再运行 `pnpm run release`，检查 EXE 产品信息、文件版本、SHA-256、ASAR 与源码 ZIP 内容。
3. 核对 `dist/github-v2.1.7/` 仅有三个附件，文件名均为 `2.1.7`，不要混用历史附件。
4. 重点确认：未完成的远期任务在三种主题的悬浮预览、展开列表和主清单中均显示白色文字，绿色只允许出现在已完成任务上；悬浮窗展开后能看到不同月份的未完成任务；已完成任务为绿色；红、黄、白色时间阈值连续；最大化、还原和最小化动画可关闭且遵循减少动态效果设置。

5. 核对任务名称旁的铅笔入口：主清单、完成清单和悬浮窗能修改名称与时间；取消不写入，保存后同步月份分组与倒计时，已完成任务保留完成时间。

## 手动发布

1. 在项目 GitHub 仓库创建正式 Release：标签 `v2.1.7`，标题 `Deadline Desk v2.1.7`。
2. 将本目录的 `RELEASE-NOTES.md` 作为发布正文。
3. 上传 `Deadline-Desk-2.1.7.exe`、`Deadline-Desk-2.1.7.exe.sha256`、`Deadline-Desk-2.1.7-source.zip`。
4. 确认附件可下载且 SHA-256 一致，再发布为正式最新版；不要只上传仓库文件或使用预发布标签。

应用通过仓库 `frredomerror91-netizen/Deadline_app` 的正式最新版检测更新；标签、EXE 文件名、文件元数据和校验值必须一致。
