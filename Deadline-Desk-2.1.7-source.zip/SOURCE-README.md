# Deadline Desk v2.1.7 源码说明

本源码包对应 Windows x64 免安装版 v2.1.7，包含应用源码、`package.json`、`pnpm-lock.yaml`、测试与构建脚本、发布说明；不含用户数据、依赖目录、缓存、旧版本或构建产物。需要 Node.js、pnpm 和可交互的 Windows 桌面。

## 安装、测试与构建

在源码目录运行：

~~~powershell
pnpm install --frozen-lockfile
pnpm run test:unit
pnpm run test:v217
pnpm run test:edit
pnpm dist
pnpm run release
~~~

`test:v217` 会写入跨月份任务样本并启动 Electron，验证悬浮窗显示全部任务、月份分组、未完成任务只使用红/黄/白色、已完成任务使用绿色与完成计数，并逐项检查三种主题下的实际文字颜色；`test:unit` 覆盖更新完整性、国际化、任务生命周期、悬浮窗历史回归、本版显示和窗口动画检查。

`test:edit` 在独立用户数据目录中验证主界面/悬浮窗编辑、取消、空白字段、逾期任务、仅改名称时的时间精度、完成记录保留、写入失败、跨月刷新、删除期间拒绝保存、重启持久化及继续新建任务。不会读取或修改本机真实任务数据。

旧综合命令 `pnpm test` 的历史检查链仍包含旧“7 日任务范围”断言，与当前全局悬浮清单不符，本次执行在该断言处失败。请以 `test:unit`、`test:v217` 和 `test:edit` 作为本次已通过的验收命令，不宣称历史综合链全部通过。

## 编辑任务

点击任务名称右侧的铅笔按钮，修改名称和截止时间后点击“保存修改”；关闭或 Escape 取消，不写入数据。主清单和完成清单通过页面弹窗编辑，悬浮窗通过独立小窗编辑。更改截止时间会重新计算倒计时、颜色、排序和月份分组；不会重置任务 ID、完成状态或完成时间。既有任务可保留或改为逾期时间，新建任务仍要求未来时间；回收站记录需先还原。任务被删除/归档，或名称/截止时间已在其他窗口变化时，会拒绝保存，防止恢复已删除任务或覆盖新信息。

打包后可进一步验证包内源码与空白配置启动：

~~~powershell
$env:DDL_RELEASE_ASAR = Join-Path $PWD 'dist/win-unpacked/resources/app.asar'
pnpm exec electron v217-smoke.cjs
pnpm exec electron task-edit-smoke.cjs
pnpm exec electron release-clean-smoke.cjs
Remove-Item Env:DDL_RELEASE_ASAR
~~~

`pnpm run release` 将三个附件集中在 `dist/github-v2.1.7/`，核对 ASAR 与本版源码、EXE 产品和文件版本、EXE SHA-256、源码 ZIP 的逐文件哈希。

实际免安装 EXE 也可在不加载任务数据的模式下核验包内全部应用文件，并检查并发启动的解压目录互不干扰：

~~~powershell
$env:DDL_PORTABLE_EXE = Join-Path $PWD 'dist/github-v2.1.7/Deadline-Desk-2.1.7.exe'
node portable-smoke.cjs
Remove-Item Env:DDL_PORTABLE_EXE
~~~

## 输出文件被正在运行的旧程序占用时

可使用独立输出目录打包，不强制退出正在使用的应用。发布整理脚本接受 `DDL_BUILD_DIR`，仍将三个附件核验后放到标准发布目录。此情况下请运行 `dist/github-v2.1.7/` 内的新 EXE，勿误用仍被占用的原 `dist/Deadline-Desk-2.1.7.exe`。

~~~powershell
pnpm exec electron-builder --win --config.directories.output=dist/edit-build
$env:DDL_BUILD_DIR = 'dist/edit-build'
pnpm run release
Remove-Item Env:DDL_BUILD_DIR
~~~

任务仍存放在 `%APPDATA%/deadline-desk` 对应的应用数据目录；不要为切换版本删除整个用户数据目录。线上发布、Git 提交、推送和创建 GitHub Release 均不由本地整理步骤自动执行。
