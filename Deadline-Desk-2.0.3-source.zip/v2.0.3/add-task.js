const nameInput = document.getElementById('name');
const deadlineInput = document.getElementById('deadline');
const date = new Date();
date.setDate(date.getDate() + 1);
date.setHours(15, 0, 0, 0);
deadlineInput.value = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
document.getElementById('cancel').onclick = () => window.desktop.closeEditor();
document.addEventListener('keydown', event => { if (!event.defaultPrevented && event.key === 'Escape') window.desktop.closeEditor(); });
document.getElementById('quickForm').onsubmit = event => {
  event.preventDefault();
  const name = nameInput.value.trim();
  const deadline = deadlineInput.value;
  if (!name || !Number.isFinite(new Date(deadline).getTime()) || new Date(deadline) <= new Date()) {
    document.getElementById('error').textContent = '请填写任务名和未来时间'; return;
  }
  try {
    const tasks = JSON.parse(localStorage.getItem('deadline-desk.tasks') || '[]');
    if (!Array.isArray(tasks)) throw new Error('Invalid tasks');
    tasks.push({ id: crypto.randomUUID(), name, deadline });
    localStorage.setItem('deadline-desk.tasks', JSON.stringify(tasks));
    window.desktop.tasksChanged();
    window.desktop.closeEditor();
  } catch { document.getElementById('error').textContent = '保存失败，请重试'; }
};
