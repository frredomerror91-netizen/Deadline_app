// Shared animated picker: native segmented fields stay as storage only.
(() => {
  const svg = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><rect x="4" y="5" width="16" height="16" rx="2"/><path d="M8 3v4M16 3v4M4 11h16"/></svg>';
  const dialog = document.createElement('dialog');
  dialog.className = 'date-picker';
  dialog.setAttribute('aria-label', '选择日期与时间');
  dialog.innerHTML = `<div class="picker-heading"><strong id="pickerTitle">选择截止时间</strong><button type="button" class="picker-cancel" aria-label="关闭时间选择器">×</button></div><div class="picker-nav"><button type="button" data-step="-1" aria-label="上一页">‹</button><select class="picker-year" aria-label="年份"></select><select class="picker-month" aria-label="月份"></select><button type="button" data-step="1" aria-label="下一页">›</button></div><div class="picker-week">${[...'一二三四五六日'].map(x=>`<span>${x}</span>`).join('')}</div><div class="picker-grid"></div><div class="picker-time"><span>时间</span><select aria-label="小时" class="picker-hour"></select><span>:</span><select aria-label="分钟" class="picker-minute"></select></div><div class="picker-footer"><button type="button" class="picker-today">今天</button><button type="button" class="picker-confirm">确定</button></div>`;
  document.body.append(dialog);
  const q = selector => dialog.querySelector(selector);
  const year = q('.picker-year'), month = q('.picker-month'), hour = q('.picker-hour'), minute = q('.picker-minute');
  const pad = n => String(n).padStart(2, '0');
  const options = (start, count, suffix='') => Array.from({length: count}, (_, i) => `<option value="${start+i}">${pad(start+i)}${suffix}</option>`).join('');
  month.innerHTML = options(1,12,'月'); hour.innerHTML = options(0,24); minute.innerHTML = options(0,60);
  // Keep the same date grid; the clock is a separate time-only control.
  const calendar = document.createElement('div'); calendar.className = 'picker-calendar';
  q('.picker-nav').before(calendar);
  ['.picker-nav','.picker-week','.picker-grid'].forEach(selector => calendar.append(q(selector)));
  const body = document.createElement('div'); body.className = 'picker-body';
  calendar.before(body); body.append(calendar, q('.picker-time'));
  hour.hidden = true; minute.hidden = true;
  const time = q('.picker-time'); [...time.querySelectorAll('span')].forEach(el => el.remove());
  const controls = document.createElement('div'); controls.className = 'clock-controls';
  controls.innerHTML = '<input type="text" inputmode="numeric" class="clock-hour" aria-label="小时，0至23" autocomplete="off"><span>:</span><input type="text" inputmode="numeric" class="clock-minute" aria-label="分钟，0至59" autocomplete="off">';
  const face = document.createElement('div'); face.className = 'clock-face';
  face.setAttribute('role','slider'); face.tabIndex = 0; face.setAttribute('aria-label','小时表盘');
  const hint = document.createElement('small'); hint.textContent = '拖动指针或点击上方数字输入 · 24 小时制';
  time.append(controls, face, hint);
  const error = document.createElement('div'); error.className='clock-error'; error.id='clockError'; error.setAttribute('role','alert'); time.append(error);
  const inputs = [q('.clock-hour'),q('.clock-minute')];
  inputs.forEach(input => input.setAttribute('aria-describedby','clockError'));
  function validateTime() {
    let valid=true;
    inputs.forEach((input,i) => {
      const ok=/^\d{1,2}$/.test(input.value) && Number(input.value)<(i===0?24:60);
      input.setAttribute('aria-invalid',String(!ok));
      if(ok) (i===0?hour:minute).value=Number(input.value); else valid=false;
    });
    error.textContent=valid?'':'小时须为 0–23，分钟须为 0–59 的整数';
    return valid;
  }
  let clockMode = 'hour';
  function drawClock() {
    const hours = clockMode === 'hour', value = Number(hours ? hour.value : minute.value);
    inputs.forEach((input,i) => { if(document.activeElement!==input && input.getAttribute('aria-invalid')!=='true') input.value=pad(i===0?hour.value:minute.value); });
    q('.clock-hour').setAttribute('aria-pressed',String(hours)); q('.clock-minute').setAttribute('aria-pressed',String(!hours));
    face.setAttribute('aria-label',hours ? '小时表盘' : '分钟表盘');
    face.setAttribute('aria-valuemin','0'); face.setAttribute('aria-valuemax',hours ? '23' : '59'); face.setAttribute('aria-valuenow',String(value));
    const angle = (hours ? value % 12 / 12 : value / 60) * 360;
    const radius = hours && value >= 12 ? 28 : 41;
    face.innerHTML = '<i class="clock-hand"></i><i class="clock-pin"></i>';
    const hand = face.querySelector('.clock-hand'); hand.style.height = radius + '%'; hand.style.transform = 'rotate(' + angle + 'deg)';
    const count = hours ? 24 : 12;
    for (let i=0; i<count; i++) {
      const n = hours ? i : i*5, r = hours && i>=12 ? 28 : 41, a = i%12*Math.PI/6;
      const label = document.createElement('span'); label.className = 'clock-number'; label.textContent = pad(n);
      label.style.left = 50+Math.sin(a)*r+'%'; label.style.top = 50-Math.cos(a)*r+'%';
      label.classList.toggle('selected', n===value); face.append(label);
    }
  }
  inputs.forEach((input,i) => {
    input.onfocus = () => { clockMode=i===0?'hour':'minute'; drawClock(); input.select(); };
    input.oninput = () => { if(validateTime()) drawClock(); };
    input.onblur = () => { if(validateTime()) { input.value=pad(input.value); drawClock(); } };
    input.onkeydown = event => { if(event.key==='Enter') { event.preventDefault(); if(validateTime()) q('.picker-confirm').click(); } };
  });
  function pickTime(event) {
    const r=face.getBoundingClientRect(), x=event.clientX-r.left-r.width/2, y=event.clientY-r.top-r.height/2;
    const turn=(Math.atan2(x,-y)/(Math.PI*2)+1)%1;
    if (clockMode==='hour') hour.value = Math.round(turn*12)%12 + (Math.hypot(x,y)<r.width*.345 ? 12 : 0);
    else minute.value = Math.round(turn*60)%60;
    inputs.forEach((input,i) => input.value=pad(i===0?hour.value:minute.value)); validateTime(); drawClock();
  }
  let clockPointer = null;
  face.onpointerdown = event => { if(event.button!==0)return; event.preventDefault(); face.focus(); clockPointer = event.pointerId; face.setPointerCapture(event.pointerId); pickTime(event); };
  face.onpointermove = event => { if(clockPointer === event.pointerId)pickTime(event); };
  face.onpointerup = event => { if(clockPointer !== event.pointerId)return; clockPointer = null; pickTime(event); if(face.hasPointerCapture(event.pointerId))face.releasePointerCapture(event.pointerId); if(clockMode==='hour'){clockMode='minute';drawClock();} };
  face.onpointercancel = () => { clockPointer = null; };
  face.onkeydown = event => {
    if(!['ArrowRight','ArrowUp','ArrowLeft','ArrowDown','Home','End','Enter'].includes(event.key))return;
    event.preventDefault();
    if(event.key==='Enter'){clockMode=clockMode==='hour'?'minute':'hour';drawClock();return;}
    const input=clockMode==='hour'?hour:minute, total=clockMode==='hour'?24:60;
    input.value = event.key==='Home'?0:event.key==='End'?total-1:(Number(input.value)+(['ArrowRight','ArrowUp'].includes(event.key)?1:-1)+total)%total;
    drawClock();
  };
  let active, selected, view, monthOnly, dateOnly;
  const dateText = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  function render() {
    const y = view.getFullYear(), m = view.getMonth();
    year.innerHTML = options(Math.max(1,y-100),201,'年'); year.value = y; month.value = m+1;
    const grid = q('.picker-grid'); grid.innerHTML = '';
    grid.classList.toggle('months', monthOnly);
    dialog.classList.toggle('month-only', monthOnly || dateOnly);
    q('.picker-week').hidden = monthOnly; q('.picker-time').hidden = monthOnly || dateOnly;
    q('#pickerTitle').textContent = monthOnly ? '选择月份' : dateOnly ? '选择定位日期' : '选择截止时间';
    q('.picker-today').textContent = monthOnly ? '本月' : '今天';
    if (monthOnly) {
      for (let i=0;i<12;i++) {
        const button = document.createElement('button'); button.type='button'; button.textContent=`${i+1}月`;
        button.setAttribute('aria-pressed', String(i===selected.getMonth() && y===selected.getFullYear()));
        button.onclick=()=>{selected=new Date(y,i,1); view=new Date(y,i,1); render();}; grid.append(button);
      }
    } else {
      const offset = (new Date(y,m,1).getDay()+6)%7;
      for(let i=0;i<offset;i++) grid.append(document.createElement('span'));
      for(let day=1;day<=new Date(y,m+1,0).getDate();day++) {
        const date = new Date(y,m,day), button=document.createElement('button'); button.type='button'; button.textContent=day;
        button.setAttribute('aria-label',dateText(date)); button.setAttribute('aria-pressed',String(dateText(date)===dateText(selected)));
        if(dateText(date)===dateText(new Date())) button.classList.add('is-today');
        button.onclick=()=>{selected=date; render(); q(`[aria-label="${dateText(date)}"]`).focus();}; grid.append(button);
      }
    }
  }
  function close() { dialog.close(); active?.button.focus(); }
  q('.picker-cancel').onclick=close;
  dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
  document.addEventListener('keydown',event=>{
    if(dialog.open && event.key==='Escape') {event.preventDefault();event.stopImmediatePropagation();close();}
  },true);
  dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect(); if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)close();}});
  dialog.querySelectorAll('[data-step]').forEach(button=>button.onclick=()=>{
    view=new Date(view.getFullYear()+(monthOnly?Number(button.dataset.step):0), view.getMonth()+(monthOnly?0:Number(button.dataset.step)),1);render();
  });
  year.onchange=month.onchange=()=>{view=new Date(Number(year.value),Number(month.value)-1,1); if(monthOnly) selected=new Date(view); render();};
  q('.picker-today').onclick=()=>{selected=new Date();view=new Date(selected.getFullYear(),selected.getMonth(),1);render();};
  q('.picker-confirm').onclick=()=>{
    if(!monthOnly && !dateOnly && !validateTime()) { inputs.find(input=>input.getAttribute('aria-invalid')==='true')?.focus(); return; }
    active.input.value=monthOnly?dateText(selected).slice(0,7):dateOnly?dateText(selected):`${dateText(selected)}T${pad(hour.value)}:${pad(minute.value)}`;
    active.input.dispatchEvent(new Event('input',{bubbles:true})); active.input.dispatchEvent(new Event('change',{bubbles:true})); close();
  };
  document.querySelectorAll('input[type="datetime-local"], input[type="month"], input[type="date"]').forEach(input=>{
    const type=input.type, button=document.createElement('button'); button.type='button';button.className='date-trigger';button.id=input.id+'Trigger';button.setAttribute('aria-haspopup','dialog');
    button.setAttribute('aria-label',type==='month'?'选择月份':type==='date'?'完成清单定位日期':'选择截止时间');
    input.after(button);input.type='hidden';input.required=false;
    const sync=()=>{
      button.hidden=input.hidden;
      const value=input.value;
      const label=value ? value.replace('T','  ').replace(/^(\d+)-(\d+)(?:-(\d+))?/,(_,y,m,d)=>`${y}年${m}月${d?d+'日':''}`) : '选择截止时间';
      button.innerHTML=`<span></span>${svg}`;button.firstElementChild.textContent=label;
    };
    const descriptor=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
    Object.defineProperty(input,'value',{get(){return descriptor.get.call(this);},set(value){descriptor.set.call(this,value);sync();}});
    new MutationObserver(sync).observe(input,{attributes:true,attributeFilter:['hidden','value']});
    input.addEventListener('change',sync);input.form?.addEventListener('reset',()=>queueMicrotask(sync));
    function open() {
      active={input,button};monthOnly=type==='month';dateOnly=type==='date';selected=new Date(input.value+(monthOnly?'-01T12:00':dateOnly?'T12:00':''));if(!Number.isFinite(selected.getTime()))selected=new Date();
      view=new Date(selected.getFullYear(),selected.getMonth(),1);hour.value=selected.getHours();minute.value=selected.getMinutes();clockMode='hour';inputs.forEach((input,i)=>{input.value=pad(i===0?hour.value:minute.value);input.setAttribute('aria-invalid','false');});error.textContent='';drawClock();render();dialog.showModal();
      let motion=true;try{motion=JSON.parse(localStorage.getItem('deadline-desk.settings')||'{}').motion!==false;}catch{}
      if(motion&&!matchMedia('(prefers-reduced-motion: reduce)').matches) dialog.animate([{opacity:0,transform:'translateY(8px) scale(.97)'},{opacity:1,transform:'translateY(0) scale(1)'}],{duration:180,easing:'ease-out'});
      q('.picker-confirm').focus();
    }
    button.onclick=open;
    const field=input.closest('.deadline-field');if(field)field.addEventListener('click',event=>{if(!event.target.closest('button'))open();});
    document.querySelector(`label[for="${input.id}"]`)?.addEventListener('click',event=>{event.preventDefault();open();});
    sync();
  });
})();
