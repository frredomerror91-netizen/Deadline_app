(() => {
  const button = document.getElementById('checkUpdate');
  const label = document.getElementById('updateStatus');
  let state;
  function render(value) {
    state = value;
    document.getElementById('appVersion').textContent = `Deadline Desk · v${value.version}`;
    document.getElementById('settingsVersion').textContent = value.version;
    button.disabled = ['checking', 'downloading', 'installing'].includes(value.phase);
    button.textContent = value.phase === 'available' ? `更新至 v${value.latest}`
      : value.phase === 'checking' ? '正在检测…'
      : value.phase === 'downloading' ? `正在下载 ${value.progress || 0}%`
      : value.phase === 'installing' ? '正在重启更新…' : '↻ 检测更新';
    label.textContent = value.message || '';
  }
  button.onclick = async () => {
    button.disabled = true;
    try { render(await (state?.phase === 'available' ? window.desktop.installUpdate() : window.desktop.checkUpdate())); }
    catch { label.textContent = '更新服务暂不可用，请重试。'; button.disabled = false; }
  };
  window.desktop?.onUpdate(render);
  window.desktop?.updateStatus().then(render).catch(() => { label.textContent = '无法读取版本信息'; });
})();
