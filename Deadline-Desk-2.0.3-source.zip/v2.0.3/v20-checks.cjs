const assert = require('node:assert/strict');
const { app, screen, BrowserWindow } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
module.exports = async main => {
  const js = code => main.webContents.executeJavaScript(code);
  const capture = async name => { if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, name+'.png'), (await main.webContents.capturePage()).toPNG()); };
  await js("setFloatingMode(false); document.getElementById('settingsButton').click(); document.getElementById('settingTheme').value='gray'; document.getElementById('settingTheme').dispatchEvent(new Event('change',{bubbles:true}))");
  assert.equal(await js('document.documentElement.dataset.theme'), 'gray');
  assert.equal(await js("localStorage.getItem('deadline-desk.theme')"), 'gray');
  assert.equal((await js('desktop.getFloatingSettings()')).edgeCount, true);
  await js("document.getElementById('settingsClose').click(); openModal(); document.getElementById('taskDeadlineTrigger').click()");
  for (const [hour, minute] of [['24','30'],['12','60'],['-1','0'],['1.5','0'],['','12'],['aa','12']]) {
    await js(`document.querySelector('.clock-hour').value=${JSON.stringify(hour)}; document.querySelector('.clock-minute').value=${JSON.stringify(minute)}; document.querySelector('.picker-confirm').click()`);
    assert.equal(await js("document.querySelector('.date-picker').open && !!document.querySelector('.clock-error').textContent"),true, `${hour}:${minute} must be rejected`);
  }
  for (const [hour,minute] of [['0','0'],['23','59']]) {
    await js(`document.querySelector('.clock-hour').value='${hour}'; document.querySelector('.clock-minute').value='${minute}'; document.querySelector('.picker-confirm').click()`);
    assert.equal(await js(`taskDeadlineInput.value.endsWith('T${hour.padStart(2,'0')}:${minute.padStart(2,'0')}')`),true);
    await js("document.getElementById('taskDeadlineTrigger').click()");
  }
  await delay(300);
  assert.equal(await js("document.querySelector('.date-picker').open"),true);
  await capture('v20-gray-picker');
  await js("document.querySelector('.picker-cancel').click(); closeModal()");
  const probe = path.join(app.getPath('userData'), 'second-instance-probe.cjs');
  fs.writeFileSync(probe, `const {app}=require('electron'); app.setName(${JSON.stringify(app.getName())}); app.setPath('userData',${JSON.stringify(app.getPath('userData'))}); const locked=app.requestSingleInstanceLock(); app.whenReady().then(()=>app.exit(locked?2:0));`);
  await require('node:util').promisify(require('node:child_process').execFile)(process.execPath,[probe,'--add-task'],{windowsHide:true});
  await delay(400);
  const editor = BrowserWindow.getAllWindows().find(w=>w!==main);
  assert.ok(editor, 'Desktop menu opens an editor in normal mode');
  if(editor.webContents.isLoading()) await new Promise(resolve=>editor.webContents.once('did-finish-load',resolve));
  assert.equal(await editor.webContents.executeJavaScript('document.documentElement.dataset.theme'),'gray');
  app.emit('second-instance', {}, ['Deadline Desk','--add-task']);
  assert.equal(BrowserWindow.getAllWindows().length,2,'Repeated menu opens reuse the editor');
  await editor.webContents.executeJavaScript("nameInput.value='桌面右键测试任务'; document.getElementById('quickForm').requestSubmit()");
  await delay(200);
  assert.equal(await js("tasks.some(t=>t.name==='桌面右键测试任务')"),true);
  const menuModule = require('./desktop-menu');
  assert.match(menuModule.launchCommand(app), / --add-task$/);
  const key = 'HKCU\\Software\\Classes\\DesktopBackground\\Shell\\DeadlineDesk-QA-'+process.pid;
  const menu = menuModule(app,{key});
  try {
    await menu.install();
    const {stdout} = await require('node:util').promisify(require('node:child_process').execFile)('reg.exe',['query',key+'\\command','/ve'],{windowsHide:true});
    assert.ok(stdout.includes('--add-task') && stdout.includes(app.getAppPath()));
  } finally { await menu.remove(); }
  await js("setFloatingMode(true); locked=false; renderLock(); settings.motion=true; desktop.setEdgeMotion(true)");
  await delay(150);
  const originalCursor=screen.getCursorScreenPoint, originalDisplays=screen.getAllDisplays;
  const display=screen.getPrimaryDisplay(), a=display.workArea;
  let cursor={x:a.x+a.width/2,y:a.y+a.height/2};
  screen.getCursorScreenPoint=()=>cursor; screen.getAllDisplays=()=>[display];
  try {
    for (const side of ['left','right','top','bottom']) {
      const b={x:side==='left'?a.x:side==='right'?a.x+a.width-600:a.x+100,y:side==='top'?a.y:side==='bottom'?a.y+a.height-72:a.y+100,width:600,height:72};
      await js('locked=true; renderLock()'); await delay(60);
      main.setBounds(b); await js('locked=false; renderLock()'); await delay(650);
      const positions=[];
      for(let i=0;i<14;i++){positions.push(main.getBounds());await delay(50);}
      const h=main.getBounds(), vertical=side==='left'||side==='right';
      assert.ok(positions.some(p=>vertical ? p.x!==b.x && p.x!==h.x : p.y!==b.y && p.y!==h.y),side+' has intermediate animation frames');
      assert.equal(await js('document.body.dataset.edge'),side);
      assert.equal(await js("!document.getElementById('edgeBadge').hidden && document.getElementById('edgeBadge').textContent===String(tasks.filter(t=>!t.completed).length)"),true);
      const visible=side==='left'?h.x+h.width-a.x:side==='right'?a.x+a.width-h.x:side==='top'?h.y+h.height-a.y:a.y+a.height-h.y;
      assert.ok(Math.abs(visible-(vertical?40:28))<=1,side+' compact badge');
      await capture('v20-edge-'+side);
      cursor={x:side==='left'?a.x+2:side==='right'?a.x+a.width-2:b.x+300,y:side==='top'?a.y+2:side==='bottom'?a.y+a.height-2:b.y+36};
      await delay(400);
      assert.ok(Math.abs(main.getBounds().x-b.x)<=1 && Math.abs(main.getBounds().y-b.y)<=1,side+' restores');
      cursor={x:a.x+a.width/2,y:a.y+a.height/2};
    }
    await js('desktop.saveFloatingSettings({edgeCount:false})');
    await delay(1200);
    assert.equal(await js("document.getElementById('edgeBadge').hidden"),true);
    assert.ok(Math.abs(a.y+a.height-main.getBounds().y-6)<=1);
    assert.equal(JSON.parse(fs.readFileSync(path.join(app.getPath('userData'),'floating-settings.json'))).edgeCount,false);
    await js('desktop.saveFloatingSettings({edgeCount:true}); locked=true; renderLock()');
    await delay(100);
    assert.ok(main.getBounds().y+main.getBounds().height<=a.y+a.height+1);
  } finally { screen.getCursorScreenPoint=originalCursor; screen.getAllDisplays=originalDisplays; }
  console.log('PASS: v2.0 four-edge animation/badges/reveal, count preference persistence, typed-time validation, gray theme, desktop menu registration/cleanup/editor/save');
};
