const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('desktop', {
  updateStatus: () => ipcRenderer.invoke('update-status'),
  checkUpdate: () => ipcRenderer.invoke('update-check'),
  installUpdate: () => ipcRenderer.invoke('update-install'),
  onUpdate: callback => ipcRenderer.on('update-state', (_, value) => callback(value)),
  desktopMenu: repair => ipcRenderer.invoke('desktop-menu', Boolean(repair)),
  onEdgeState: callback => ipcRenderer.on('edge-state', (_, value) => callback(value)),
  setEdgeMotion: value => ipcRenderer.send('edge-motion', value),
  getFloatingSettings: () => ipcRenderer.invoke('get-floating-settings'),
  saveFloatingSettings: value => ipcRenderer.invoke('save-floating-settings', value),
  onFloatingSettings: callback => ipcRenderer.on('floating-settings-changed', (_, value) => callback(value)),
  onToggleFloating: callback => ipcRenderer.on('toggle-floating', () => callback()),
  onOpenFloatingSettings: callback => ipcRenderer.on('open-floating-settings', () => callback()),
  setExpanded: (value, animate) => ipcRenderer.send('set-expanded', Boolean(value), Boolean(animate)),
  onExpandedSettled: callback => ipcRenderer.on('expanded-settled', (_, value) => callback(value)),
  miniDrag: active => ipcRenderer.send('mini-drag', active),
  miniResize: edge => ipcRenderer.send('mini-resize', edge),
  onMiniResized: callback => ipcRenderer.on('mini-resized', (_, value) => callback(value)),
  onMaximized: callback => ipcRenderer.on('window-maximized', (_, value) => callback(value)),
  setFloatingMode: (enabled) => ipcRenderer.send('set-floating-mode', Boolean(enabled)),
  windowAction: (action) => ipcRenderer.send('window-action', action),
  setLocked: value => ipcRenderer.send('set-locked', Boolean(value)),
  openEditor: () => ipcRenderer.send('open-editor'),
  closeEditor: () => ipcRenderer.send('close-editor'),
  tasksChanged: () => ipcRenderer.send('tasks-changed'),
  onTasksChanged: callback => ipcRenderer.on('tasks-changed', () => callback())
});
