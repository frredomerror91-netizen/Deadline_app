(() => {
  const key = 'deadline-desk.theme';
  function apply(theme) {
    theme = ['light','dark','gray'].includes(theme) ? theme : 'light';
    const dark = theme === 'dark';
    document.documentElement.dataset.theme = theme;
    const setting = document.getElementById('settingTheme');
    if (setting) setting.value = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#141b24' : '#f6f7fb');
    const button = document.getElementById('themeToggle');
    if (button) {
      button.textContent = dark ? '☀ 浅色模式' : '☾ 暗夜模式';
      button.setAttribute('aria-pressed', String(dark));
    }
  }
  window.setDeskTheme = theme => { localStorage.setItem(key, theme); apply(theme); };
  function read() { try { return localStorage.getItem(key) || 'light'; } catch { return 'light'; } }
  apply(read());
  document.addEventListener('DOMContentLoaded', () => {
    apply(read());
    document.getElementById('themeToggle')?.addEventListener('click', () => {
      const theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem(key, theme); } catch { /* Keep the current session usable. */ }
      apply(theme);
    });
  });
  window.addEventListener('storage', event => { if (event.key === key || event.key === null) apply(read()); });
})();
