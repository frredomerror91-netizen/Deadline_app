# Deadline Desk v2.0.3 源码

轻量 Windows 桌面截止时间管理工具，支持任务清单、悬浮倒计时、完成归档与本地数据存储。

A lightweight Windows desktop deadline planner with task lists, floating countdowns, completion archives, and local data storage.

此目录是 Windows x64 免安装版对应源码，不包含个人任务、用户配置、依赖目录或打包缓存。

## 本地开发与打包

安装 Node.js 和支持 lockfileVersion 9 的 pnpm，在本目录执行：

```powershell
pnpm install --frozen-lockfile
pnpm start
```

在 Windows 上运行测试和生成发布包：

```powershell
pnpm run test:update
pnpm test
pnpm dist
pnpm exec electron release-clean-smoke.cjs
```

`pnpm dist` 生成 `dist/Deadline-Desk-2.0.3.exe` 及同名 `.exe.sha256` 文件。空白启动检查使用隔离的临时用户目录，不修改真实用户数据。完整回归包含窗口移动、快捷键及注册表测试，需可交互的 Windows 桌面环境。

任务与设置默认保存在 `%APPDATA%\deadline-desk`，不会被打包。所有历史版本共用该目录，删除它会同时清除这些版本的本机数据。

发布操作见 `PUBLISH-GUIDE.md`，发布正文见 `RELEASE-NOTES.md`。更新源固定为 `frredomerror91-netizen/Deadline_app` 的最新正式 Release。
