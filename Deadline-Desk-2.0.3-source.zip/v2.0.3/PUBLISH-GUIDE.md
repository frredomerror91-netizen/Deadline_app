# v2.0.3 正式发布操作

## 已准备的文件

上传文件集中在 `dist/github-v2.0.3/`，只需上传该目录中的三个文件：

| 文件 | 用途 |
| --- | --- |
| `Deadline-Desk-2.0.3.exe` | Windows x64 免安装程序，71,178,502 字节 |
| `Deadline-Desk-2.0.3.exe.sha256` | 自动更新及人工核验所需的校验文件 |
| `Deadline-Desk-2.0.3-source.zip` | 与程序对应的独立源码包 |

EXE 的 SHA-256：

```text
9596301d477043af1d4256332908ecefb040f20a4efc92be054a64a0a5d22488
```

描述正文使用本文件旁边的 `RELEASE-NOTES.md`。

## 个人数据处理与检查

2026-09-21 已按要求清空本机 `%APPDATA%\deadline-desk` 数据目录，包括任务、完成记录、回收站、偏好设置及缓存。清空后确认目录不存在。再次运行应用会创建新的空白目录；历史版本也使用这个目录，因此原有本机记录一并清空。

最终 EXE 提取出的 `app.asar` 仅含打包白名单中的 19 个程序文件，程序源码逐项一致、版本为 2.0.3，未包含用户数据目录。使用隔离用户目录启动这份包内程序，确认任务数为 0、默认浅色主题。发布程序没有加入“启动时删除数据”的逻辑，因此不会清除其他用户升级前的数据。

更新模块 5 项测试通过，完整功能回归重跑通过。首次完整回归曾在底部贴边动画收缩计时断言失败，未改代码重跑通过；这是本次验证保留的偶发测试限制。真实线上跨版本升级尚未验证。

## 在 GitHub 上发布

1. 登录有发布权限的 GitHub 账号，打开 [Deadline_app 新建 Release](https://github.com/frredomerror91-netizen/Deadline_app/releases/new)。本次只做了本地准备，没有上传、提交、推送或创建 Release。请先创建公开仓库 `frredomerror91-netizen/Deadline_app`；Target 使用新仓库实际包含本版源码的分支。
2. 先确保仓库中准备打标签的提交包含本次 `v2.0.3` 源码。如果尚未同步，可解压 `Deadline-Desk-2.0.3-source.zip`，通过仓库的 **Add file → Upload files** 上传源码至项目对应位置并提交。不要上传整个本地工作区、个人资料、`node_modules` 或整个 `dist`。EXE 只作为 Release 附件上传。
3. 在 **Choose a tag / Select tag** 中输入 `v2.0.3` 并创建标签，Target 选择刚同步源码的分支或提交（通常为 `main`）。若标签已存在，先核对其对应源码，不要直接覆盖。
4. 标题填 `Deadline Desk v2.0.3`，描述粘贴 `RELEASE-NOTES.md`。上传上表三个文件，等待上传完成。EXE 和 `.exe.sha256` 必须同时上传，文件名不要更改。
5. 不勾选 **Set as a pre-release**；若显示 **Set as the latest release**，勾选它。最后点击 **Publish release**，不要只保存草稿。
6. 打开 [最新正式版页面](https://github.com/frredomerror91-netizen/Deadline_app/releases/latest)，确认跳转到 `v2.0.3`，并能看到三个附件。GitHub 自动生成的 `Source code (zip/tar.gz)` 来自标签提交；额外上传的 `-source.zip` 是本次准备的精确源码包。
7. 从 Release 页面重新下载 EXE 和校验文件核验，再启动检查版本号与空清单。当前 v2.0.3 点“检测更新”应提示已是最新；下一版高于 2.0.3 才能验证跨版本自动升级。

可在下载目录运行以下 PowerShell 命令核对哈希：

```powershell
$actual = (Get-FileHash -LiteralPath '.\Deadline-Desk-2.0.3.exe' -Algorithm SHA256).Hash.ToLowerInvariant()
$expected = ((Get-Content -LiteralPath '.\Deadline-Desk-2.0.3.exe.sha256' -Raw).Trim() -split '\s+')[0]
if ($actual -ne $expected) { throw '校验失败，请勿运行' }
'SHA-256 校验通过'
```

## 发布限制

当前构建未进行发布者代码签名，可能出现 Windows 未知发布者提示；校验和用于确认文件一致性，不能替代代码签名。支持 Windows x64，未制作 macOS、Linux 或 ARM64 原生包。源码包未替你选择开源许可证；若希望明确授权他人修改、再分发，应另行确定许可证。
