function constrain(bounds, area, threshold = 16) {
  const right = area.x + area.width - bounds.width;
  const bottom = area.y + area.height - bounds.height;
  let x = Math.max(area.x, Math.min(bounds.x, right));
  let y = Math.max(area.y, Math.min(bounds.y, bottom));
  if (x - area.x <= threshold) x = area.x;
  if (right - x <= threshold) x = right;
  if (y - area.y <= threshold) y = area.y;
  if (bottom - y <= threshold) y = bottom;
  return { ...bounds, x, y };
}
function editorBounds(strip, area) {
  const height = Math.min(420, area.height);
  return constrain({ x: strip.x, y: strip.y + strip.height + 6 + height <= area.y + area.height ? strip.y + strip.height + 6 : strip.y - height - 6, width: Math.min(620, area.width), height }, area, 0);
}
module.exports = { constrain, editorBounds };
