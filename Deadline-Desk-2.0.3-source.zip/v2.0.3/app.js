const STORAGE_KEY = 'deadline-desk.tasks';
const MODE_KEY = 'deadline-desk.floating';

const appShell = document.getElementById('appShell');
const taskList = document.getElementById('taskList');
const taskCount = document.getElementById('taskCount');
const taskArea = document.getElementById('taskArea');
const emptyAddButton = document.getElementById('emptyAddButton');
const modalBackdrop = document.getElementById('modalBackdrop');
const taskForm = document.getElementById('taskForm');
const taskNameInput = document.getElementById('taskName');
const taskDeadlineInput = document.getElementById('taskDeadline');
const formError = document.getElementById('formError');
const floatingToggle = document.getElementById('floatingToggle');
const floatingStrip = document.getElementById('floatingStrip');
const stripTasks = document.getElementById('stripTasks');

floatingStrip.addEventListener('pointerdown', event => {
  if (event.button !== 0 || !event.target.closest('.strip-header') || event.target.closest('button, input, .completion-group') || floatingStrip.classList.contains('is-locked')) return;
  floatingStrip.setPointerCapture(event.pointerId);
  window.desktop?.miniDrag(true);
});
for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
  floatingStrip.addEventListener(type, () => window.desktop?.miniDrag(false));
}

const SETTINGS_KEY = 'deadline-desk.settings';
const defaults = { sort: 'asc', showCompleted: true, motion: true, highlightUrgent: true, retentionDays: 30 };
let settings;
try { settings = { ...defaults, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') }; }
catch { settings = { ...defaults }; }
let completing = false;
let expanded = false;
const motionEnabled = () => settings.motion && !matchMedia('(prefers-reduced-motion: reduce)').matches;
if (!Number.isInteger(settings.retentionDays) || settings.retentionDays < 1 || settings.retentionDays > 1825) settings.retentionDays = 30;
let tasks = readTasks();
let currentView = 'all';
let sortAscending = settings.sort !== 'desc';
const monthFilter = document.getElementById('monthFilter');
monthFilter.value = toDateTimeLocal(new Date()).slice(0, 7);
monthFilter.addEventListener('change', renderTasks);

function readTasks() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(saved) ? saved.filter((task) => task && task.name && Number.isFinite(new Date(task.deadline).getTime())) : [];
  } catch (error) {
    return [];
  }
}

function persistTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function formatDate(date, options = {}) {
  return new Intl.DateTimeFormat('zh-CN', { month: 'long', day: 'numeric', ...options }).format(date);
}

function formatShortDate(date) {
  return new Intl.DateTimeFormat('zh-CN', { month: 'numeric', day: 'numeric', weekday: 'short' }).format(date).replace('周', '周');
}

function startOfDay(date) {
  const result = new Date(date);
  result.setHours(0, 0, 0, 0);
  return result;
}

function isSameDay(first, second) {
  return startOfDay(first).getTime() === startOfDay(second).getTime();
}

function isCompletionView() { return currentView.startsWith('completed-'); }
function completionRange(period, value) {
  const start = startOfDay(new Date(value + 'T12:00:00'));
  if (period === 'year') start.setMonth(0, 1);
  if (period === 'month') start.setDate(1);
  if (period === 'week') start.setDate(start.getDate() - (start.getDay() + 6) % 7);
  const end = new Date(start);
  if (period === 'year') end.setFullYear(end.getFullYear()+1);
  else if (period === 'month') end.setMonth(end.getMonth()+1);
  else end.setDate(end.getDate() + (period === 'week' ? 7 : 1));
  return [start,end];
}
function completionMeta(task) {
  return task.completedAt && Number.isFinite(new Date(task.completedAt).getTime()) ? '完成于 ' + new Date(task.completedAt).toLocaleString('zh-CN', {hour12:false}) : '完成时间未记录';
}
function isUrgent(task, now = Date.now()) { return settings.highlightUrgent !== false && !task.completed && new Date(task.deadline).getTime() - now <= 48*60*60*1000; }
const completionDate = document.getElementById('completionDate');
completionDate.value = toDateTimeLocal(new Date()).slice(0,10);
function updatePeriodLabel() {
  if (!isCompletionView() || currentView === 'completed-all') return;
  const [start,end] = completionRange(currentView.slice(10),completionDate.value);
  const last = new Date(end); last.setDate(last.getDate()-1);
  document.getElementById('periodLabel').textContent = start.toLocaleDateString('zh-CN') + ' — ' + last.toLocaleDateString('zh-CN');
}
completionDate.onchange = () => { if(!completionDate.value) completionDate.value=toDateTimeLocal(new Date()).slice(0,10); updatePeriodLabel(); renderTasks(); };
function shiftCompletionPeriod(direction) {
  const period = currentView.slice(10), [date] = completionRange(period,completionDate.value);
  if (period==='year') date.setFullYear(date.getFullYear()+direction);
  else if(period==='month') date.setMonth(date.getMonth()+direction);
  else date.setDate(date.getDate()+direction*(period==='week'?7:1));
  completionDate.value=toDateTimeLocal(date).slice(0,10); completionDate.onchange();
}
document.getElementById('periodPrevious').onclick=()=>shiftCompletionPeriod(-1);
document.getElementById('periodNext').onclick=()=>shiftCompletionPeriod(1);
document.getElementById('periodToday').onclick=()=>{completionDate.value=toDateTimeLocal(new Date()).slice(0,10);completionDate.onchange();};
function getFilteredTasks() {
  const activeTasks = tasks.filter(task => !task.archivedAt);
  if (currentView === 'trash') return tasks.filter(task => task.archivedAt);
  const now = new Date();
  const today = startOfDay(now);
  if (isCompletionView()) return activeTasks.filter(task => {
    if (!task.completed) return false;
    if (currentView === 'completed-all') return true;
    const time = new Date(task.completedAt).getTime(), [start,end] = completionRange(currentView.slice(10), completionDate.value);
    return Number.isFinite(time) && time >= start && time < end;
  });
  if (currentView === 'month') return activeTasks.filter(task => task.deadline.slice(0, 7) === monthFilter.value);
  if (currentView === 'today') return activeTasks.filter((task) => isSameDay(new Date(task.deadline), now));
  if (currentView === 'week') {
    const weekEnd = new Date(today);
    weekEnd.setDate(today.getDate() + 7);
    return activeTasks.filter((task) => new Date(task.deadline) >= today && new Date(task.deadline) < weekEnd);
  }
  return activeTasks.slice();
}

function sortedTasks(list = getFilteredTasks()) {
  return list.filter(task => isCompletionView() || currentView === 'trash' || settings.showCompleted || !task.completed).sort((first, second) => {
    if (Boolean(first.completed) !== Boolean(second.completed)) return first.completed ? 1 : -1;
    if (currentView === 'trash') return new Date(second.archivedAt) - new Date(first.archivedAt);
    if (isCompletionView()) return (new Date(second.completedAt).getTime() || 0) - (new Date(first.completedAt).getTime() || 0);
    const difference = new Date(first.deadline) - new Date(second.deadline);
    return sortAscending ? difference : -difference;
  });
}

function taskStatus(date) {
  const now = new Date();
  const diff = date - now;
  if (diff < 0) return { label: '已过期', className: 'is-soon', meta: '截止时间已过' };
  if (isSameDay(date, now)) return { label: '今天', className: 'is-today', meta: '今天截止' };
  if (diff < 48 * 60 * 60 * 1000) return { label: '即将截止', className: 'is-soon', meta: '不到两天' };
  return { label: '待完成', className: '', meta: `${Math.ceil(diff / (24 * 60 * 60 * 1000))} 天后` };
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
}

function renderTasks() {
  if (completing) return;
  purgeExpired();
  const sortButton = document.getElementById('sortButton');
  document.getElementById('sortLabel').textContent = '截止：' + (sortAscending ? '最近优先' : '最远优先');
  sortButton.title = '点击切换为' + (sortAscending ? '最远优先' : '最近优先');
  sortButton.setAttribute('aria-label', sortButton.textContent + '，' + sortButton.title);
  sortButton.hidden = isCompletionView() || currentView === 'trash';
  const visibleTasks = sortedTasks();
  taskCount.textContent = tasks.filter(task=>!task.archivedAt).length;
  taskList.classList.toggle('completion-archive', isCompletionView());
  taskList.innerHTML = '';

  if (currentView === 'trash') {
    renderTrash(visibleTasks);
    emptyAddButton.style.display='none'; updateStats(); renderFloatingTasks(); return;
  }
  if (!visibleTasks.length) {
    const emptyTitle = isCompletionView() ? '这个期间还没有完成记录' : currentView === 'all' ? '从一个任务开始吧' : currentView === 'today' ? '今天没有截止任务' : currentView === 'month' ? '本月没有截止任务' : '本周没有截止任务';
    const emptySubtitle = isCompletionView() ? '按实际完成时间归档，可切换日期或查看全部完成' : currentView === 'all' ? '点击中央的加号，写下第一个截止时间' : '去全部任务查看你的完整清单';
    taskList.innerHTML = `<div class="empty-state"><button class="empty-plus" id="centerAddButton" type="button" aria-label="添加任务"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M12 4v16M4 12h16"/></svg></button><p>${emptyTitle}</p><span>${emptySubtitle}</span></div>`;
    emptyAddButton.style.display = currentView === 'all' ? 'inline-block' : 'none';
    if(isCompletionView()) document.getElementById('centerAddButton')?.remove();
    document.getElementById('centerAddButton')?.addEventListener('click', openModal);
  } else {
    emptyAddButton.style.display = 'none';
    visibleTasks.forEach((task, index) => {
      const date = new Date(task.deadline);
      const status = task.completed ? { label: '已完成', className: '', meta: completionMeta(task) } : taskStatus(date);
      const row = document.createElement('article');
      row.dataset.taskId = String(task.id);
      row.className = `task-row${isUrgent(task) ? ' is-urgent' : ''}${task.completed ? ' is-completed' : ''}`;
      
      row.innerHTML = `<span class="task-marker" aria-hidden="true"></span><div class="task-main"><p class="task-name" title="${escapeHtml(task.name)}">${escapeHtml(task.name)}</p><span class="task-meta">${formatShortDate(date)} · ${date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })} · ${status.meta}</span></div><span class="task-badge ${status.className}">${status.label}</span><button class="task-delete" type="button" data-delete="${escapeHtml(task.id)}" aria-label="删除 ${escapeHtml(task.name)}" title="删除任务">×</button>${completionControl(task)}${isCompletionView() ? `<button class="archive-button" type="button" data-archive="${escapeHtml(task.id)}">归档</button>` : ''}`;
      taskList.appendChild(row);
    });
    taskList.querySelectorAll('[data-delete]').forEach((button) => button.addEventListener('click', () => removeTask(button.dataset.delete)));
  }

  taskList.querySelectorAll('[data-archive]').forEach(button=>button.onclick=()=>archiveTask(button.dataset.archive));
  bindCompletion(taskList);
  updateStats();
  renderFloatingTasks();
}

function updateStats() {
  document.getElementById('taskUpdated').textContent = `${getFilteredTasks().length} 项任务`;
}

function countdown(task, now = Date.now()) {
  if (task.completed) return '已完成';
  const diff = new Date(task.deadline).getTime() - now;
  const total = Math.floor(Math.abs(diff) / 60000);
  const duration = `${total >= 1440 ? Math.floor(total / 1440) + "天" : ""}${Math.floor(total % 1440 / 60)}小时${total % 60}分钟`;
  if (Math.abs(diff) < 60000) return diff > 0 ? '不足1分钟截止' : '已逾期不足1分钟';
  return (diff > 0 ? '剩余 ' : '已逾期 ') + duration;
}
function completionControl(task) {
  return `<span class="completion-group"><span class="task-countdown${!task.completed && new Date(task.deadline) <= new Date() ? ' is-overdue' : ''}" data-countdown="${escapeHtml(task.id)}">${countdown(task)}</span><input class="task-complete" type="checkbox" data-complete="${escapeHtml(task.id)}" aria-label="${task.completed ? '标为未完成 ' : '完成 '}${escapeHtml(task.name)}" ${task.completed ? 'checked' : ''}></span>`;
}
function bindCompletion(container) {
  container.querySelectorAll('[data-complete]').forEach(input => input.addEventListener('change', async () => {
    const task = tasks.find(task => String(task.id) === input.dataset.complete);
    if (!task || completing) { input.checked = Boolean(task?.completed); return; }
    const id = String(task.id);
    task.completed = input.checked;
    if (task.completed) task.completedAt = new Date().toISOString(); else delete task.completedAt;
    persistTasks();
    completing = true;
    document.querySelectorAll('[data-complete]').forEach(control => {
      control.disabled = true;
      if (control.dataset.complete === id) control.checked = task.completed;
    });
    const rows = [...document.querySelectorAll('[data-task-id]')].filter(row => row.dataset.taskId === id && row.getClientRects().length);
    try {
      if (motionEnabled()) {
        const animations = rows.map(row => row.animate([
          { opacity: 1, transform: 'translateX(0)' },
          { opacity: .6, transform: 'translateX(8px)' },
          { opacity: 0, transform: 'translateX(18px)' }
        ], { duration: 260, easing: 'ease-in', fill: 'forwards' }));
        await Promise.race([
          Promise.allSettled(animations.map(animation => animation.finished)),
          new Promise(resolve => setTimeout(resolve, 400))
        ]);
        animations.forEach(animation => animation.cancel());
      }
    } finally {
      const positions = new Map([...document.querySelectorAll('[data-task-id]')].map(row => [row.parentElement.id + ':' + row.dataset.taskId, row.getBoundingClientRect().top]));
      completing = false;
      renderTasks();
      if (motionEnabled()) document.querySelectorAll('[data-task-id]').forEach(row => {
        const previous = positions.get(row.parentElement.id + ':' + row.dataset.taskId);
        if (row.dataset.taskId === id) row.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 230 });
        else if (previous !== undefined) row.animate([{ transform: `translateY(${previous - row.getBoundingClientRect().top}px)` }, { transform: 'translateY(0)' }], { duration: 280, easing: 'ease-out' });
      });
      const replacement = [...container.querySelectorAll('[data-complete]')].find(control => control.dataset.complete === id) || container.querySelector('[data-complete]');
      replacement?.focus({ preventScroll: true });
    }
  }));
}
function floatingRow(task, index, compact = false) {
  const date = new Date(task.deadline);
  return `<div data-task-id="${escapeHtml(task.id)}" class="${compact ? 'preview-task' : 'strip-task'}${isUrgent(task) ? ' is-urgent' : ''}${task.completed ? ' is-completed' : index === 0 ? ' is-current' : ''}"><div class="strip-task-copy"><div class="strip-task-name" title="${escapeHtml(task.name)}">${escapeHtml(task.name)}</div><div class="strip-task-time" title="${escapeHtml(date.toLocaleString('zh-CN'))}">截止 ${date.getFullYear()}/${date.getMonth()+1}/${date.getDate()} ${date.toLocaleTimeString('zh-CN', {hour:'2-digit',minute:'2-digit'})}</div></div>${completionControl(task)}</div>`;
}
function renderFloatingTasks() {
  const ordered = tasks.filter(task=>!task.archivedAt).sort((a,b) => Number(Boolean(a.completed)) - Number(Boolean(b.completed)) || new Date(a.deadline) - new Date(b.deadline));
  const unfinished = ordered.filter(task => !task.completed);
  document.getElementById('edgeBadge').textContent = unfinished.length > 999 ? '999+' : unfinished.length;
  document.getElementById('edgeBadge').title = unfinished.length + ' 项待完成';
  document.getElementById('stripCount').textContent = unfinished.length + ' 项待完成';
  const preview = document.getElementById('stripPreview');
  document.getElementById('miniTotal').textContent = unfinished.length;
  document.getElementById('miniTotal').setAttribute('aria-label', `未完成 DDL 总数：${unfinished.length}`);
  preview.innerHTML = unfinished.length ? unfinished.slice(0, 2).map((task, i) => floatingRow(task, i, true)).join('') : '<div class="preview-empty">' + (tasks.length ? '全部完成，休息一下吧' : '暂无任务，点击 + 添加') + '</div>';
  const visible = ordered.filter(task => settings.showCompleted || !task.completed);
  stripTasks.innerHTML = visible.length ? visible.map((task, i) => floatingRow(task, i)).join('') : '<div class="strip-empty">暂无待办任务</div>';
  bindCompletion(preview);
  bindCompletion(stripTasks);
}
function setExpanded(value, animate = true, notify = true) {
  expanded = value;
  const details = document.getElementById('stripDetails');
  const moving = animate && motionEnabled() && appShell.classList.contains('is-floating');
  details.hidden = !expanded && !moving;
  details.inert = !expanded;
  floatingStrip.classList.toggle('is-expanded', expanded);
  const button = document.getElementById('stripExpandButton');
  button.setAttribute('aria-expanded', String(expanded));
  button.setAttribute('aria-label', expanded ? '收起清单' : '展开清单');
  button.title = expanded ? '收起清单' : '展开清单';
  button.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${expanded ? 'M6 15l6-6 6 6' : 'M6 9l6 6 6-6'}"/></svg>`;
  if (notify) window.desktop?.setExpanded(expanded, moving);
  if (!window.desktop) details.hidden = !expanded;
}
window.desktop?.onExpandedSettled(value => { if (value === expanded) document.getElementById('stripDetails').hidden = !value; });
document.getElementById('stripExpandButton').addEventListener('click', () => setExpanded(!expanded));

function openModal() {
  if (appShell.classList.contains('is-floating') && window.desktop) { window.desktop.openEditor(); return; }
  modalBackdrop.hidden = false;
  formError.textContent = '';
  taskNameInput.focus();
  const defaultDeadline = new Date();
  defaultDeadline.setDate(defaultDeadline.getDate() + 1);
  defaultDeadline.setHours(15, 0, 0, 0);
  taskDeadlineInput.value = toDateTimeLocal(defaultDeadline);
}

function closeModal() {
  modalBackdrop.hidden = true;
  taskForm.reset();
  formError.textContent = '';
}

function toDateTimeLocal(date) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60 * 1000).toISOString().slice(0, 16);
}

function removeTask(id) {
  tasks = tasks.filter((task) => task.id !== id);
  persistTasks();
  renderTasks();
}

function setView(view, label) {
  document.getElementById('settingsPage').hidden = true;
  document.getElementById('content').hidden = false;
  document.getElementById('settingsButton').classList.remove('is-active');
  currentView = view;
  document.getElementById('completionTabs').hidden = !isCompletionView();
  document.getElementById('trashControls').hidden = view !== 'trash';
  document.getElementById('addButton').hidden = isCompletionView() || view === 'trash';
  document.querySelectorAll('[data-completion-period]').forEach(button=>button.setAttribute('aria-pressed', String(view === 'completed-'+button.dataset.completionPeriod)));
  if(view==='trash') syncRetention();
  monthFilter.hidden = view !== 'month';
  document.getElementById('completionPeriod').hidden = !isCompletionView() || view === 'completed-all';
  updatePeriodLabel();
  document.querySelectorAll('.nav-item, .workspace-row').forEach((item) => item.classList.toggle('is-active', item.dataset.view === (isCompletionView() ? 'completed-all' : view)));
  document.getElementById('viewHeading').textContent = label;
  document.getElementById('listHeading').textContent = view === 'all' ? '总截止清单' : label;
  renderTasks();
}

function setFloatingMode(enabled) {
  setExpanded(false, false);
  appShell.classList.toggle('is-floating', enabled);
  floatingToggle.classList.toggle('is-on', enabled);
  floatingToggle.setAttribute('aria-pressed', String(enabled));
  localStorage.setItem(MODE_KEY, enabled ? '1' : '0');
  if (window.desktop && typeof window.desktop.setFloatingMode === 'function') window.desktop.setFloatingMode(enabled);
  if (!enabled) document.getElementById(document.getElementById('settingsPage').hidden ? 'addButton' : 'settingsClose').focus();
}

document.getElementById('addButton').addEventListener('click', openModal);
emptyAddButton.addEventListener('click', openModal);
document.getElementById('stripAddButton').addEventListener('click', openModal);
document.getElementById('stripCloseButton').addEventListener('click', () => setFloatingMode(false));
document.getElementById('modalClose').addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', (event) => { if (event.target === modalBackdrop) closeModal(); });
document.addEventListener('keydown', (event) => { if (!event.defaultPrevented && event.key === 'Escape' && !modalBackdrop.hidden) closeModal(); });
floatingToggle.addEventListener('click', () => setFloatingMode(!appShell.classList.contains('is-floating')));
document.getElementById('sortButton').addEventListener('click', () => { sortAscending = !sortAscending; renderTasks(); });
document.querySelectorAll('[data-view]').forEach((item) => item.addEventListener('click', () => setView(item.dataset.view, item.querySelector('span:nth-child(2)')?.textContent || '我的清单')));

taskForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const name = taskNameInput.value.trim();
  const deadline = taskDeadlineInput.value;
  if (!name || !deadline) return;
  if (new Date(deadline) < new Date()) {
    formError.textContent = '截止时间需要晚于当前时间';
    return;
  }
  tasks.push({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, name, deadline });
  persistTasks();
  closeModal();
  setView('all', '总截止清单');
});

document.getElementById('todayLabel').textContent = `${formatDate(new Date(), { month: 'long', day: 'numeric', weekday: 'long' })}`;
setFloatingMode(localStorage.getItem(MODE_KEY) === '1');
renderTasks();
document.getElementById('windowMinimize').addEventListener('click', () => window.desktop?.windowAction('minimize'));
document.getElementById('windowClose').addEventListener('click', () => window.desktop?.windowAction('close'));
setInterval(() => {
  // Update labels in place: never interrupt focus, dragging or a completion animation.
  document.querySelectorAll('[data-countdown]').forEach(label => {
    const task = tasks.find(task => String(task.id) === label.dataset.countdown);
    if (task) {
      label.textContent = countdown(task);
      label.closest('[data-task-id]')?.classList.toggle('is-urgent', isUrgent(task));
      label.classList.toggle('is-overdue', !task.completed && new Date(task.deadline) <= new Date());
    }
  });
}, 1000);
setInterval(renderTasks, 60000);
const lockButton = document.getElementById('stripLockButton');
let locked = localStorage.getItem('deadline-desk.locked') === '1';
function renderLock() {
  floatingStrip.classList.toggle('is-locked', locked);
  lockButton.setAttribute('aria-pressed', String(locked));
  lockButton.title = locked ? '解锁位置并启用贴边隐藏' : '锁定位置并关闭贴边隐藏';
  lockButton.setAttribute('aria-label', lockButton.title);
  lockButton.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="${locked ? 'M8 10V6a4 4 0 0 1 8 0v4' : 'M8 10V6a4 4 0 0 1 8 0'}"/><path d="M12 14v3"/></svg>`;
  window.desktop?.setLocked(locked);
}
lockButton.onclick = () => { locked = !locked; localStorage.setItem('deadline-desk.locked', locked ? '1' : '0'); renderLock(); };
renderLock();
function refreshSavedTasks() { tasks = readTasks(); renderTasks(); }
window.desktop?.onTasksChanged(refreshSavedTasks);
window.addEventListener('storage', event => { if (event.key === STORAGE_KEY) refreshSavedTasks(); });

const settingsPage = document.getElementById('settingsPage');
document.getElementById('settingsButton').addEventListener('click', () => {
  document.getElementById('settingTheme').value = document.documentElement.dataset.theme;
  document.getElementById('settingSort').value = settings.sort;
  document.getElementById('settingCompleted').checked = settings.showCompleted;
  document.getElementById('settingMotion').checked = settings.motion;
  document.getElementById('settingUrgent').checked = settings.highlightUrgent;
  document.getElementById('content').hidden = true;
  settingsPage.hidden = false;
  document.querySelectorAll('[data-view]').forEach(item => item.classList.remove('is-active'));
  document.getElementById('settingsButton').classList.add('is-active');
  document.getElementById('viewHeading').textContent = '设置';
  document.getElementById('settingsClose').focus();
});
document.getElementById('settingsClose').onclick = () => {
  const nav = document.querySelector(`[data-view="${isCompletionView() ? 'completed-all' : currentView}"]`);
  setView(currentView, isCompletionView() ? '完成清单' : nav.querySelector('span:nth-child(2)').textContent); nav.focus();
};
settingsPage.addEventListener('change', event => {
  if (!event.target.closest('[data-settings-panel=general]')) return;
  const theme = document.getElementById('settingTheme').value;
  window.setDeskTheme(theme);
  settings = { ...settings, highlightUrgent: document.getElementById('settingUrgent').checked, sort: document.getElementById('settingSort').value, showCompleted: document.getElementById('settingCompleted').checked, motion: document.getElementById('settingMotion').checked };
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  sortAscending = settings.sort === 'asc';
  renderTasks();
});

window.desktop?.onMiniResized(value => setExpanded(value, false, false));
const icon = path => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
const icons = {
  windowMinimize: '<path d="M5 12h14"/>', windowClose: '<path d="m6 6 12 12M18 6 6 18"/>',
  stripExitButton: '<path d="M12 3v9M7 5.5a8 8 0 1 0 10 0"/>',
  stripAddButton: '<path d="M12 5v14M5 12h14"/>',
  stripCloseButton: '<path d="M14 4h6v6M20 4 10 14M10 4H4v16h16v-6"/>',
  modalClose: '<path d="m6 6 12 12M18 6 6 18"/>'
};
Object.entries(icons).forEach(([id, path]) => document.getElementById(id).innerHTML = icon(path));
const maximizeButton = document.getElementById('windowMaximize');
function renderMaximized(value) {
  maximizeButton.innerHTML = icon(value ? '<path d="M8 8V4h12v12h-4"/><rect x="4" y="8" width="12" height="12" rx="1"/>' : '<rect x="5" y="5" width="14" height="14" rx="1"/>');
  maximizeButton.title = value ? '还原窗口' : '最大化';
  maximizeButton.setAttribute('aria-label', maximizeButton.title);
}
renderMaximized(false);
window.desktop?.onMaximized(renderMaximized);
maximizeButton.onclick = () => window.desktop?.windowAction('maximize');
document.getElementById('stripExitButton').onclick = () => window.desktop?.windowAction('close');
for (const edge of ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw']) {
  const handle = document.createElement('div');
  handle.className = 'resize-edge edge-' + edge;
  handle.setAttribute('aria-hidden', 'true');
  floatingStrip.append(handle);
  handle.addEventListener('pointerdown', event => {
    if (event.button !== 0 || locked) return;
    event.preventDefault(); event.stopPropagation();
    handle.setPointerCapture(event.pointerId);
    window.desktop?.miniResize(edge);
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) handle.addEventListener(type, event => {
    event.stopPropagation(); window.desktop?.miniResize(null);
  });
}

// Native preferences are shared by the context menu and settings pages.
function selectSettingsTab(name) {
  document.querySelectorAll('[data-settings-panel]').forEach(panel => panel.hidden = panel.dataset.settingsPanel !== name);
  document.querySelectorAll('[data-settings-tab]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.settingsTab === name)));
}
document.querySelectorAll('[data-settings-tab]').forEach(button => button.onclick = () => selectSettingsTab(button.dataset.settingsTab));
const shortcutInput = document.getElementById('settingShortcut');
function showFloatingSettings(value) {
  if (!value) return;
  document.getElementById('settingLayer').value = value.layer;
  document.getElementById('settingEdgeCount').checked = value.edgeCount !== false;
  shortcutInput.value = value.shortcut || '';
  document.getElementById('floatingSettingsStatus').textContent = value.error || '';
}
async function saveFloatingSettings(patch) {
  try { showFloatingSettings(await window.desktop?.saveFloatingSettings(patch)); }
  catch { document.getElementById('floatingSettingsStatus').textContent = '设置保存失败，请重试。'; }
}
window.desktop?.getFloatingSettings().then(showFloatingSettings);
window.desktop?.onFloatingSettings(showFloatingSettings);
document.getElementById('settingLayer').onchange = event => saveFloatingSettings({ layer: event.target.value });
document.getElementById('clearShortcut').onclick = () => saveFloatingSettings({ shortcut: '' });
shortcutInput.onkeydown = event => {
  if (event.key === 'Tab') return;
  event.preventDefault(); event.stopPropagation();
  if (event.key === 'Escape') { shortcutInput.blur(); return; }
  if (['Control','Alt','Shift','Meta'].includes(event.key) || event.repeat) return;
  const modifiers = [event.ctrlKey && 'Ctrl', event.altKey && 'Alt', event.shiftKey && 'Shift'].filter(Boolean);
  let key = event.code.replace(/^Key/, '').replace(/^Digit/, '');
  if (event.metaKey || !modifiers.length || !/^([A-Z0-9]|F([1-9]|1[0-9]|2[0-4]))$/.test(key)) {
    document.getElementById('floatingSettingsStatus').textContent = '请使用 Ctrl、Alt 或 Shift 加字母、数字或功能键。'; return;
  }
  saveFloatingSettings({ shortcut: [...modifiers,key].join('+') });
};
window.desktop?.onToggleFloating(() => {
  document.querySelector('.date-picker[open]')?.close(); closeModal();
  setFloatingMode(!appShell.classList.contains('is-floating'));
});
window.desktop?.onOpenFloatingSettings(() => {
  setFloatingMode(false); document.getElementById('settingsButton').click(); selectSettingsTab('floating');
});

document.getElementById('settingEdgeCount').onchange = event => saveFloatingSettings({edgeCount:event.target.checked});
window.desktop?.onEdgeState(value => {
  document.body.dataset.edge = value.edge || '';
  document.getElementById('edgeBadge').hidden = !value.edge || !value.count;
});
const syncEdgeMotion = () => window.desktop?.setEdgeMotion(motionEnabled());
syncEdgeMotion();
document.getElementById('settingMotion').addEventListener('change', syncEdgeMotion);
matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', syncEdgeMotion);

// Archive timestamps share the task store, so restoring retains completion history.
function purgeExpired(now = Date.now()) {
  const kept = tasks.filter(task => {
    const archived = task.archivedAt && new Date(task.archivedAt).getTime();
    return !Number.isFinite(archived) || now < archived + settings.retentionDays*86400000;
  });
  if(kept.length===tasks.length) return;
  const previous=tasks; tasks=kept;
  try { persistTasks(); } catch { tasks=previous; document.getElementById('retentionStatus').textContent='自动清理保存失败，请检查磁盘空间后重试。'; }
}
function archiveTask(id) {
  if(completing) return;
  const task=tasks.find(task=>String(task.id)===id);
  if(!task?.completed || task.archivedAt) return;
  task.archivedAt=new Date().toISOString();
  try { persistTasks(); } catch { delete task.archivedAt; window.alert('归档保存失败，请重试。'); return; }
  renderTasks();
}
function restoreArchived(id) {
  const task=tasks.find(task=>String(task.id)===id);
  if(!task?.archivedAt) return;
  const archivedAt=task.archivedAt; delete task.archivedAt;
  try { persistTasks(); } catch { task.archivedAt=archivedAt; window.alert('还原保存失败，请重试。'); return; }
  renderTasks();
}
function deleteArchived(id) {
  if(!window.confirm('永久删除这条归档记录？此操作无法撤销。')) return;
  const previous=tasks; tasks=tasks.filter(task=>String(task.id)!==id || !task.archivedAt);
  try { persistTasks(); } catch { tasks=previous; window.alert('删除失败，请重试。'); return; }
  renderTasks();
}
function renderTrash(records) {
  if(!records.length) { taskList.innerHTML='<div class="empty-state"><p>回收站为空</p><span>在完成清单中点击“归档”，记录会移到这里。</span></div>'; return; }
  let previousMonth='';
  for(const task of records) {
    const date=new Date(task.archivedAt), valid=Number.isFinite(date.getTime());
    const month=valid?date.getFullYear()+'年'+(date.getMonth()+1)+'月':'归档时间未记录';
    if(month!==previousMonth) { const heading=document.createElement('h3');heading.className='trash-month';heading.textContent=month;taskList.append(heading);previousMonth=month; }
    const row=document.createElement('article'); row.className='trash-row'; row.dataset.taskId=task.id;
    const expiry=valid?new Date(date.getTime()+settings.retentionDays*86400000).toLocaleString('zh-CN',{hour12:false}):'待核实';
    row.innerHTML='<div class="task-main"><p class="task-name">'+escapeHtml(task.name)+'</p><div class="task-meta">'+escapeHtml(completionMeta(task))+'</div><div class="task-meta">归档：'+(valid?date.toLocaleString('zh-CN',{hour12:false}):'未知')+' · 自动删除：'+expiry+'</div></div><div class="trash-actions"><button type="button" data-restore>还原</button><button type="button" data-purge>永久删除</button></div>';
    row.querySelector('[data-restore]').onclick=()=>restoreArchived(String(task.id));
    row.querySelector('[data-purge]').onclick=()=>deleteArchived(String(task.id));taskList.append(row);
  }
}
function syncRetention() {
  const days=settings.retentionDays, preset=[7,30,90].includes(days);
  document.getElementById('trashRetention').value=preset?String(days):'custom';
  document.getElementById('customRetention').value=days;
  document.getElementById('customRetentionLabel').hidden=preset;
}
document.getElementById('trashRetention').onchange=event=>document.getElementById('customRetentionLabel').hidden=event.target.value!=='custom';
document.getElementById('saveRetention').onclick=()=>{
  const preset=document.getElementById('trashRetention').value;
  const raw=preset==='custom'?document.getElementById('customRetention').value:preset;
  const days=Number(raw), status=document.getElementById('retentionStatus');
  if(!/^\d+$/.test(raw) || !Number.isInteger(days) || days<1 || days>1825) { status.textContent='请输入 1–1825 的整数天数（最长 5 年）。'; return; }
  const expires=tasks.filter(task=>task.archivedAt && new Date(task.archivedAt).getTime()+days*86400000<=Date.now()).length;
  if(expires && !window.confirm('此保留期限将立即永久删除 '+expires+' 条到期归档记录，是否继续？')) return;
  try { localStorage.setItem(SETTINGS_KEY,JSON.stringify({...settings,retentionDays:days})); }
  catch { status.textContent='设置保存失败，请重试。'; return; }
  settings.retentionDays=days;status.textContent='已保存：归档后 '+days+' 天自动删除。';renderTasks();
};
document.querySelectorAll('[data-completion-period]').forEach(button=>button.onclick=()=>setView('completed-'+button.dataset.completionPeriod,'完成清单'));
async function showDesktopMenuStatus(repair=false) {
  const button=document.getElementById('repairDesktopMenu'), status=document.getElementById('desktopMenuStatus');
  button.disabled=true;
  try { const result=await window.desktop?.desktopMenu(repair); status.textContent=result?.ok?'已启用：桌面右键 → 显示更多选项 → 添加任务':result?.error || '未启用，请点击修复菜单'; }
  catch { status.textContent='菜单检查失败，请点击修复菜单重试。'; }
  finally { button.disabled=false; }
}
document.getElementById('repairDesktopMenu').onclick=()=>showDesktopMenuStatus(true);
showDesktopMenuStatus();

window.addEventListener('focus', () => { if(!completing) refreshSavedTasks(); });
