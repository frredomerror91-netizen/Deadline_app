# v2.1.9 GitHub 发布指南

发布目标：`frredomerror91-netizen/Deadline_app`。沿用历史范围：仓库更新 README 与本版源码 ZIP，正式 Release 提供 EXE、SHA-256 和源码 ZIP 三个附件。线上发布须获得用户授权；本轮用户已明确要求推送。

## 发布前核验

本次为 2026-10-15 的同版本显示修复，包内版本和附件文件名继续使用 `2.1.9`；版本比较不会向已运行的 2.1.9 提示更新，需要用户退出旧程序后手动运行修复版。发布后通过 GitHub API 核验分支提交、Release 状态和三个附件摘要。

1. 在 Windows x64 上按 `SOURCE-README.md` 安装依赖并运行 `pnpm run test:unit`、`pnpm run test:v219`、`pnpm run test:display` 与 `pnpm run test:edit`。
2. 在版本目录执行 `pnpm run dist`，再运行 `pnpm run release`，检查 EXE 产品信息、文件版本、SHA-256、ASAR 与源码 ZIP 内容。
3. 核对 `dist/github-v2.1.9/` 仅有三个附件，文件名均为 `2.1.9`，不要混用历史附件。
4. 重点确认：
   - 中英日切换后的语言按钮、窗口控制始终可见，关闭行为等下拉选项完整显示；截止时间字号变大，悬浮窗任务数无反色底块；
   - 界面逻辑布局：顶部 Header 工具栏整合设置、主题、语言与更新，左侧边栏专注于清单导航与悬浮窗入口；
   - 色彩体系与对比度：深色模式告别“一团黑”，卡片抬升与边框轮廓分明；灰色与浅色模式质感纯正；
   - 动画流畅度：任务卡片滑入、悬停浮起、弹窗命令面板缩放均流畅无卡顿；
   - 连续截止色彩：未完成的远期任务在三种主题的悬浮预览、展开列表和主清单中均显示白色文字，绿色只允许出现在已完成任务上；红、黄、白色时间阈值连续；任务编辑功能与窗口交互均正常。

## 手动发布

1. 在项目 GitHub 仓库创建正式 Release：标签 `v2.1.9`，标题 `Deadline Desk v2.1.9`。
2. 将本目录的 `RELEASE-NOTES.md` 作为发布正文。
3. 上传 `Deadline-Desk-2.1.9.exe`、`Deadline-Desk-2.1.9.exe.sha256`、`Deadline-Desk-2.1.9-source.zip`。
4. 确认附件可下载且 SHA-256 一致，再发布为正式最新版；不要只上传仓库文件或使用预发布标签。

应用通过仓库 `frredomerror91-netizen/Deadline_app` 的正式最新版检测更新；标签、EXE 文件名、文件元数据和校验值必须一致。
