# Deadline Desk v2.1.9

## 中文

这次主要调整了界面的显示效果，让任务和时间信息更容易看清。

- 调整了浅色、灰色和深色主题，让卡片和文字更容易分辨。
- 把主题、设置、语言切换和检查更新放到顶部，侧栏留给任务清单。
- 修复切换语言后顶部按钮和设置选项显示不全的问题。
- 放大截止时间和倒计时文字，调整了窄悬浮窗里的排版。
- 悬浮窗的剩余任务数不再使用反色底块，显示更协调。
- 调整了列表、按钮和弹窗的过渡效果。

## English

This update focuses on making tasks and deadlines easier to read.

- Refined the light, gray, and dark themes so cards and text are easier to distinguish.
- Moved theme, settings, language, and update controls to the top, leaving the sidebar for task lists.
- Fixed clipped toolbar buttons and settings options after switching languages.
- Made deadline and countdown text larger and improved the layout in narrow floating windows.
- Removed the contrasting background from the floating window’s task count for a more consistent look.
- Refined transitions for lists, buttons, and dialogs.
