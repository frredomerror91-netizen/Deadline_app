const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = file => fs.readFileSync(path.join(__dirname, file), 'utf8');
test('v2.1.6 guards native animation coordinates and recovers a timer failure', () => {
  const mini = source('mini-window.js');
  const pkg = JSON.parse(source('package.json'));
  assert.equal(pkg.version, '2.1.9');
  assert.match(mini, /Number\.isSafeInteger\(x\) \|\| !Number\.isSafeInteger\(y\)/);
  assert.match(mini, /catch \(error\) \{\s*stopSlide\(\)/);
  assert.match(mini, /validBounds\(candidate\) \? candidate : bounds/);
  assert.match(pkg.scripts['test:v216'], /v216-smoke\.cjs/);
});
