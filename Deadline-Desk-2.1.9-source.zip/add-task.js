const nameInput = document.getElementById('name');
const deadlineInput = document.getElementById('deadline');
const form = document.getElementById('quickForm');
const errorLabel = document.getElementById('error');
const saveButton = form.querySelector('[type="submit"]');
const taskId = new URLSearchParams(location.search).get('taskId');
let editBaseline = null, saving = false;
try {
  if (taskId) {
    const task = TaskEditor.readRecords(localStorage).find(task => task && String(task.id) === taskId && !task.archivedAt && !task.deletedAt);
    if (!task) throw Object.assign(new Error('missing'), { code: 'missing' });
    editBaseline = { name: task.name, deadline: task.deadline };
    nameInput.value = task.name;
    deadlineInput.value = TaskEditor.localValue(task.deadline);
    document.getElementById('editorTitle').textContent = t('编辑任务');
    document.title = t('编辑任务');
    saveButton.textContent = t('保存修改');
  } else {
    const date = new Date();
    date.setDate(date.getDate() + 1);
    date.setHours(15, 0, 0, 0);
    deadlineInput.value = TaskEditor.localValue(date);
  }
  deadlineInput.dispatchEvent(new Event('change', { bubbles: true }));
} catch (error) { errorLabel.textContent = t(TaskEditor.errorText(error)); saveButton.disabled = true; }
document.getElementById('cancel').onclick = () => window.desktop.closeEditor();
document.addEventListener('keydown', event => { if (!event.defaultPrevented && event.key === 'Escape') window.desktop.closeEditor(); });
form.onsubmit = event => {
  event.preventDefault();
  if (saving || saveButton.disabled) return;
  try {
    const input = { name: nameInput.value, deadline: deadlineInput.value };
    const records = TaskEditor.readRecords(localStorage);
    const next = taskId ? TaskEditor.update(records, taskId, input, editBaseline)
      : [...records, { id: crypto.randomUUID(), ...TaskEditor.validate(input) }];
    localStorage.setItem('deadline-desk.tasks', JSON.stringify(next));
    saving = true; saveButton.disabled = true;
    window.desktop.tasksChanged();
    window.desktop.closeEditor();
  } catch (error) { errorLabel.textContent = t(TaskEditor.errorText(error)); }
};
