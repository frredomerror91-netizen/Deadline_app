const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-task-edit-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({ tag_name: 'v' + require('./package.json').version }));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('task edit timeout'); app.exit(1); }, 60000).unref();
app.whenReady().then(async () => {
  try {
    const win = BrowserWindow.getAllWindows()[0];
    const js = code => win.webContents.executeJavaScript(code);
    const capture = async (window, name) => {
      if (!process.env.DDL_EDIT_SHOTS) return;
      await delay(100);
      fs.mkdirSync(process.env.DDL_EDIT_SHOTS, { recursive:true });
      fs.writeFileSync(path.join(process.env.DDL_EDIT_SHOTS,name+'.png'), (await window.webContents.capturePage()).toPNG());
    };
    while (win.webContents.isLoading()) await delay(40);
    await delay(150);
    const now = Date.now();
    const overdue = { id: 'overdue', name: 'Overdue name', deadline: new Date(now - 86400000 + 27345).toISOString(), completed: false, custom: 'keep' };
    const pending = { id: 'pending', name: '待编辑 <b>不解析</b>', deadline: new Date(now + 14 * 86400000).toISOString(), completed: false, createdAt: 'keep-created-time' };
    const done = { id: 'done', name: 'Completed', deadline: new Date(now + 86400000).toISOString(), completed: true, completedAt: new Date(now).toISOString(), custom: 'completion-history' };
    await js(`localStorage.setItem(STORAGE_KEY, ${JSON.stringify(JSON.stringify([overdue, pending, done]))}); settings.motion=false; syncMotionState(); refreshSavedTasks();`);
    const records = () => js('JSON.parse(localStorage.getItem(STORAGE_KEY))');
    const openMain = async id => {
      await js(`(() => { const button = document.querySelector('#taskList [data-edit="${id}"]'); const section = button.closest('.deadline-month'); if(section?.querySelector('.deadline-month-items').hidden) section.querySelector('.deadline-month-toggle').click(); button.click(); })()`);
      assert.equal(await js('modalBackdrop.hidden'), false);
      assert.equal(await js('document.getElementById("modalTitle").textContent'), '编辑任务');
    };
    // Cancel leaves both fields untouched, including a past deadline.
    await openMain('overdue');
    assert.equal(await js('taskDeadlineInput.value'), await js(`TaskEditor.localValue(${JSON.stringify(overdue.deadline)})`));
    await js('taskNameInput.value="Discarded edit"; document.getElementById("modalClose").click()');
    assert.deepEqual(await records(), [overdue, pending, done]);
    // Errors leave the editor open and stored task intact; a name-only past edit keeps seconds.
    await openMain('overdue');
    await js('taskNameInput.value="   "; taskForm.dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}))');
    assert.equal(await js('formError.textContent'), '请输入 1–80 个字符的任务名');
    assert.deepEqual(await records(), [overdue, pending, done]);
    await js('taskNameInput.value="保存失败测试"; window.originalSetItem=Storage.prototype.setItem; Storage.prototype.setItem=function(key,value){if(key===STORAGE_KEY)throw new Error("disk full"); return window.originalSetItem.call(this,key,value)}; taskForm.requestSubmit(); Storage.prototype.setItem=window.originalSetItem; void 0;');
    assert.equal(await js('formError.textContent'), '保存失败，请重试');
    assert.equal(await js('modalBackdrop.hidden'), false);
    assert.deepEqual(await records(), [overdue, pending, done]);
    await js('document.getElementById("taskDeadlineTrigger").click()');
    assert.equal(await js('document.querySelector(".date-picker").open'),true);
    await js('document.querySelector(".picker-confirm").click()');
    await js('taskNameInput.value="Renamed overdue"; taskForm.requestSubmit()');
    assert.deepEqual((await records())[0], { ...overdue, name: 'Renamed overdue' });
    assert.equal(await js('modalBackdrop.hidden'), true);
    // Main completed-task edit retains ID, completion timestamp and arbitrary metadata.
    await openMain('done');
    await capture(win,'main-edit');
    const changedDeadline = '2026-12-12T13:45';
    await js(`taskNameInput.value="Renamed completion"; taskDeadlineInput.value=${JSON.stringify(changedDeadline)}; taskDeadlineInput.dispatchEvent(new Event('change')); taskForm.requestSubmit()`);
    assert.deepEqual((await records())[2], { ...done, name: 'Renamed completion', deadline: changedDeadline });
    // The floating preview and expanded list expose keyboard-accessible pencil buttons.
    await js('setFloatingMode(true)'); await delay(240);
    assert.equal(await js('document.querySelector("#stripPreview [data-edit=pending]").getAttribute("type")'), 'button');
    await js('document.getElementById("stripExpandButton").click()'); await delay(50);
    await capture(win,'floating-list');
    await js('document.querySelector("#stripTasks [data-edit=pending]").click()');
    let editor;
    for (let i=0; i<100; i++) { editor=BrowserWindow.getAllWindows().find(w=>w!==win); if(editor && !editor.webContents.isLoading()) break; await delay(30); }
    assert.ok(editor, 'Floating edit window exists'); await delay(100);
    let ejs = code => editor.webContents.executeJavaScript(code);
    assert.equal(await ejs('document.getElementById("name").value'), pending.name);
    assert.equal(await ejs('document.getElementById("editorTitle").textContent'), '编辑任务');
    assert.equal(await ejs('document.querySelector("#nameTrigger") === null'), true);
    await capture(editor,'floating-editor');
    const floatDeadline='2027-01-10T18:00';
    await ejs(`nameInput.value="Floating updated"; deadlineInput.value=${JSON.stringify(floatDeadline)}; deadlineInput.dispatchEvent(new Event('change')); form.requestSubmit()`);
    await delay(180);
    const floatTask=(await records()).find(task=>task.id==='pending');
    assert.deepEqual(floatTask, { ...pending, name:'Floating updated', deadline:floatDeadline });
    assert.equal(await js('document.querySelector("#stripTasks [data-task-id=pending]").closest(".deadline-month").dataset.month'), '2027-01');
    assert.equal(await js('document.querySelector("#stripTasks [data-task-id=pending] .task-title-text").textContent'), 'Floating updated');
    assert.equal((await records()).length, 3, 'Edits update tasks rather than append duplicates');
    // A task removed while the floating editor is open cannot be silently resurrected.
    await js('document.querySelector("#stripPreview [data-edit=pending]").click()');
    for(let i=0;i<100;i++){ editor=BrowserWindow.getAllWindows().find(w=>w!==win); if(editor && !editor.webContents.isLoading()) break; await delay(30); }
    await delay(100); ejs=code=>editor.webContents.executeJavaScript(code);
    await js('tasks=tasks.map(task=>task.id==="pending"?{...task,archivedAt:new Date().toISOString()}:task);persistTasks();renderTasks()');
    await ejs('nameInput.value="Cannot resurrect";form.requestSubmit()');
    assert.equal(await ejs('errorLabel.textContent'), '任务已删除或归档，无法编辑');
    assert.equal((await records()).find(task=>task.id==='pending').name,'Floating updated');
    await ejs('document.getElementById("cancel").click()'); await delay(100);
    // Quick-add still creates a new future task after editing sessions.
    await js('document.getElementById("stripAddButton").click()');
    for(let i=0;i<100;i++){ editor=BrowserWindow.getAllWindows().find(w=>w!==win); if(editor && !editor.webContents.isLoading()) break; await delay(30); }
    await delay(100); ejs=code=>editor.webContents.executeJavaScript(code);
    assert.equal(await ejs('taskId'),null);
    await ejs('nameInput.value="New after edits";form.requestSubmit()');await delay(160);
    assert.equal((await records()).length,4);
    // Completion-list tasks beyond the 24-hour grace period remain editable, too.
    const readyCompletedAt=new Date(now-25*3600000).toISOString();
    await js('setFloatingMode(false)'); await delay(80);
    await js(`tasks=readTasks(); tasks.find(task=>task.id==='done').completedAt=${JSON.stringify(readyCompletedAt)}; persistTasks(); setView('completed-all', t('完成清单'))`);
    await openMain('done');
    await js('taskNameInput.value="Edited from completion list"; taskForm.requestSubmit()');
    assert.equal(await js('currentView'),'completed-all');
    assert.equal((await records()).find(task=>task.id==='done').completedAt,readyCompletedAt);
    assert.equal((await records()).find(task=>task.id==='done').completed,true);
    win.reload(); while(win.webContents.isLoading()) await delay(40); await delay(200);
    assert.equal((await records()).find(task=>task.id==='done').completedAt,readyCompletedAt);
    assert.equal((await records()).find(task=>task.id==='pending').name,'Floating updated');
    assert.equal(await js('tasks.find(task=>task.id==="overdue").name'), 'Renamed overdue');
    console.log('PASS task-edit: main and floating edit, overdue/name-only precision, completion history, cancellation, validation, storage rollback, cross-month refresh, no resurrection and quick-add');
    app.exit(0);
  } catch(error) { console.error(error); app.exit(1); }
});
