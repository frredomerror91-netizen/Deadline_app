const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = file => fs.readFileSync(path.join(__dirname, file), 'utf8');

test('v2.1.9 refines dark/gray/light palettes, boosts animation smoothness, and modernizes layout', () => {
  const app = source('app.js');
  const html = source('index.html');
  const css = source('styles.css');
  const pkg = JSON.parse(source('package.json'));

  assert.equal(pkg.version, '2.1.9');
  assert.equal(pkg.scripts['test:v219'], 'electron v219-smoke.cjs');

  // Verify v2.1.9 layout restructuring: utility controls moved to topbar-tools, sidebar uncluttered
  assert.match(html, /<div class="topbar-tools">/);
  assert.match(html, /<aside class="sidebar"/);
  assert.match(html, /id="floatingToggle"/);
  assert.match(html, /id="themeToggle"/);
  assert.match(html, /id="settingsButton"/);
  assert.match(html, /id="languageToggle"/);

  // Verify v2.1.9 CSS enhancements: layered elevations, GPU cubic-bezier, smooth animations
  assert.match(css, /v2\.1\.9 Layout Optimization & Visual Elevation/);
  assert.match(css, /--card-bg/);
  assert.match(css, /--ease-out-expo/);
  assert.match(css, /\.topbar-tools/);
  assert.match(css, /\.task-row/);
  assert.match(css, /\.task-row:hover/);

  // Verify deadline color tones and contrast specifications remain intact
  assert.match(css, /\.task-row\.is-urgent/);
  assert.match(css, /\.task-row\.is-warning/);
  assert.match(css, /\.task-row\.is-distant/);
  assert.match(css, /\.task-row\.is-completed/);
  assert.match(css, /:root \.is-distant \.task-name/);
});
