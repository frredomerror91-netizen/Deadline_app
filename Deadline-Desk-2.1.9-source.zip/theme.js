(() => {
  const key = 'deadline-desk.theme';
  function apply(theme) {
    theme = ['light','dark','gray'].includes(theme) ? theme : 'light';
    const dark = theme === 'dark';
    const themeColor = theme === 'dark' ? '#0b0d10' : theme === 'gray' ? '#111b2b' : '#f4f7fb';
    document.documentElement.dataset.theme = theme;
    const setting = document.getElementById('settingTheme');
    if (setting) setting.value = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', themeColor);
    const button = document.getElementById('themeToggle');
    if (button) {
      button.textContent = theme === 'light' ? t('☾ 深色模式') : theme === 'dark' ? t('◐ 灰色模式') : t('☀ 浅色模式');
      button.setAttribute('aria-pressed', String(dark));
    }
  }
  window.setDeskTheme = theme => { localStorage.setItem(key, theme); apply(theme); };
  function read() { try { return localStorage.getItem(key) || 'light'; } catch { return 'light'; } }
  apply(read());
  document.addEventListener('DOMContentLoaded', () => {
    apply(read());
    document.getElementById('themeToggle')?.addEventListener('click', () => {
      const theme = ({ light: 'dark', dark: 'gray', gray: 'light' })[document.documentElement.dataset.theme];
      try { localStorage.setItem(key, theme); } catch { /* Keep the current session usable. */ }
      apply(theme);
    });
  });
  window.addEventListener('storage', event => { if (event.key === key || event.key === null) apply(read()); });
})();

