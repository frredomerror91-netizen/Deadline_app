# Deadline Desk v2.1.9 源码说明

本源码包对应 Windows x64 免安装版 v2.1.9，包含应用源码、`package.json`、`pnpm-lock.yaml`、测试与构建脚本、发布说明；不含用户数据、依赖目录、缓存、旧版本或构建产物。需要 Node.js、pnpm 和可交互的 Windows 桌面。

## 安装、测试与构建

在源码目录运行：

~~~powershell
pnpm install --frozen-lockfile
pnpm run test:unit
pnpm run test:v219
pnpm run test:display
pnpm run test:edit
pnpm dist
pnpm run release
~~~

`test:v219` 验证顶部工具栏分流、侧栏聚焦导航、深/灰/浅三套主题色彩层级（解决深色一团黑）与平滑动画；`test:unit` 覆盖 36 项测试，包括更新完整性、国际化、任务生命周期、任务编辑与 v2.1.9 规则。

`test:edit` 在独立用户数据目录中验证主界面/悬浮窗编辑、取消、空白字段、逾期任务、仅改名称时的时间精度、完成记录保留、写入失败、跨月刷新、删除期间拒绝保存、重启持久化及继续新建任务。不会读取或修改本机真实任务数据。

`test:display` 使用隔离的临时用户数据，验证中英日语言切换与设置页保留，760–1440px 窗口中的顶栏及下拉选项完整性，截止时间字号和 360–620px 三主题悬浮窗的无反色任务数。设置 `DDL_RELEASE_ASAR` 可对构建包运行相同回归。

2026-10-15 修复保持版本 2.1.9：调整 `index.html` 的窗口控制位置，`styles.css` 中的顶栏换行、下拉框宽度、时间字号及悬浮数字样式；新增 `v219-display-smoke.cjs`。

## 布局与色彩动效重塑

v2.1.9 深度优化交互与视觉层级：
1. **色彩层级重塑**：深色模式重构卡片表面抬升（`#1a2232`）与清晰细线边框（`#28364b`），配高对比白灰文字，彻底告别“一团黑”；灰色与浅色模式同步优化。
2. **逻辑布局优化**：主题、设置、语言与版本检测分流至顶部 Header 工具栏，左侧边栏专注于核心视图导航与悬浮窗模式，空间更通透舒展。
3. **流畅动效引擎**：采用 `cubic-bezier(0.16, 1, 0.3, 1)` 与 GPU 硬件加速，提升卡片入场、悬停浮起、弹窗缩放与按钮交互流畅度。
4. **功能完备继承**：保留红黄白绿连续截止分级、跨月分组、悬浮胶囊 HUD 与任务编辑能力。

打包后可进一步验证包内源码与空白配置启动：

~~~powershell
$env:DDL_RELEASE_ASAR = Join-Path $PWD 'dist/win-unpacked/resources/app.asar'
pnpm exec electron v219-smoke.cjs
pnpm exec electron task-edit-smoke.cjs
pnpm exec electron release-clean-smoke.cjs
Remove-Item Env:DDL_RELEASE_ASAR
~~~

`pnpm run release` 将三个附件集中在 `dist/github-v2.1.9/`，核对 ASAR 与本版源码、EXE 产品和文件版本、EXE SHA-256、源码 ZIP 的逐文件哈希。

实际免安装 EXE 也可在不加载任务数据的模式下核验包内全部应用文件，并检查并发启动的解压目录互不干扰：

~~~powershell
$env:DDL_PORTABLE_EXE = Join-Path $PWD 'dist/github-v2.1.9/Deadline-Desk-2.1.9.exe'
node portable-smoke.cjs
Remove-Item Env:DDL_PORTABLE_EXE
~~~

## 输出文件被正在运行的旧程序占用时

可使用独立输出目录打包，不强制退出正在使用的应用。发布整理脚本接受 `DDL_BUILD_DIR`，仍将三个附件核验后放到标准发布目录。

~~~powershell
pnpm exec electron-builder --win --config.directories.output=dist/edit-build
$env:DDL_BUILD_DIR = 'dist/edit-build'
pnpm run release
Remove-Item Env:DDL_BUILD_DIR
~~~
