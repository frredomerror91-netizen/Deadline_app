const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = name => fs.readFileSync(path.join(__dirname, name), 'utf8');
test('v2.1.4 delays settings persistence until Save Settings and scopes resize sessions', () => {
  const app = source('app.js');
  const mini = source('mini-window.js');
  const html = source('index.html');
  const css = source('styles.css');
  assert.match(html, /id="saveSettings"/);
  assert.match(html, /修改设置后点击“保存设置”才会生效/);
  assert.match(app, /async function saveAllSettings/);
  // Save snapshots and serialization are exercised by the delayed IPC cases in v220-smoke.cjs.
  assert.match(mini, /resizeSession/);
  assert.match(css, /settings-save-button/);
  assert.match(css, /data-view="completed-all"/i);
});
