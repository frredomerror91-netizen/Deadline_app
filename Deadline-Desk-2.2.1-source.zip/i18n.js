(() => {
  const storedLanguage = window.desktop?.language;
  window.deskLocale = ['en', 'ja'].includes(storedLanguage) ? storedLanguage : 'zh-CN';
  window.deskLanguage = window.deskLocale;
  window.t = window.DeskI18n.createTranslator(window.deskLanguage);
  document.documentElement.lang = window.deskLocale;
  // Only initial, authored markup is translated. Never translate user task data.
  window.translateStaticPage = () => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    for(const node of nodes) if(!node.parentElement.closest('script,style')) node.textContent=t(node.textContent);
    document.querySelectorAll('[title],[placeholder],[aria-label]').forEach(el=>{
      for(const attr of ['title','placeholder','aria-label']) if(el.hasAttribute(attr)) el.setAttribute(attr,t(el.getAttribute(attr)));
    });
    document.title=t(document.title);
  };
  let animation, motionSequence = 0;
  window.desktop?.onWindowMotion(async kind => {
    const sequence = ++motionSequence;
    animation?.cancel();
    const element = document.querySelector('.app-shell') || document.body;
    animation = kind === 'open' ? DeskMotion.enter(element) : DeskMotion.leave(element);
    await DeskMotion.finished(animation);
    if (sequence !== motionSequence) return;
    if (kind === 'minimize') window.desktop.finishMinimize();
    if (kind === 'hide') window.desktop.finishHide();
    if (kind !== 'open') animation?.cancel();
  });
  // Keep the compact sidebar control backward-compatible as a Chinese/English switch; Japanese is selected in Settings.
  function nextLanguage(value) { return value === 'zh-CN' ? 'en' : 'zh-CN'; }
  function languageToggleCopy(value) {
    return value === 'zh-CN' ? ['EN', '切换为 English'] : value === 'en' ? ['中', 'Switch to Chinese'] : ['中', '中文に切り替え'];
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const toggle=document.getElementById('languageToggle');
    if(toggle) {
      const [label,title]=languageToggleCopy(window.deskLanguage);
      toggle.textContent=label;
      toggle.title=title; toggle.setAttribute('aria-label',title);
      toggle.addEventListener('click',async()=>{
        toggle.disabled=true;
        try { await window.desktop.saveLanguage(nextLanguage(window.deskLanguage)); window.saveLanguageNavigation?.(); location.reload(); }
        catch { toggle.disabled=false; alert(t('保存失败，请重试')); }
      });
    }
    const select=document.getElementById('settingLanguage'); if(!select)return;
    select.value=window.deskLanguage;
    window.restoreLanguageNavigation?.();
  });
})();
