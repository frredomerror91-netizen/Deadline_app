const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v213-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({tag_name:'v'+require('./package.json').version}));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('v213 timeout'); app.exit(1); }, 45000).unref();
app.whenReady().then(async () => { try {
  const win = BrowserWindow.getAllWindows()[0];
  const js = code => win.webContents.executeJavaScript(code);
  while (win.webContents.isLoading()) await delay(40);
  await delay(120);
  const result = await js(`(() => {
    const now = Date.now(), local = date => toDateTimeLocal(date);
    const task = (id, name, offset, completed = false, completedOffset = 0) => ({
      id, name, deadline: local(new Date(now + offset)), completed,
      ...(completed ? { completedAt: new Date(now - completedOffset).toISOString() } : {})
    });
    tasks = [
      task('near', 'unfinished-near', 2 * 86400000),
      task('far', 'unfinished-far', 5 * 86400000),
      task('recent', 'completed-recent', 3 * 86400000, true, 2 * 3600000),
      task('old', 'completed-old', 4 * 86400000, true, 25 * 3600000)
    ];
    persistTasks(); setView('all', t('总截止清单'));
    return { names: [...document.querySelectorAll('.task-row .task-name')].map(el => el.textContent), count: document.getElementById('taskCount').textContent };
  })()`);
  assert.deepEqual(result.names, ['unfinished-near', 'unfinished-far', 'completed-recent']);
  assert.equal(result.count, '3');
  const completed = await js("setView('completed-all', t('完成清单')); ({names:[...document.querySelectorAll('.task-row .task-name')].map(el=>el.textContent),count:document.getElementById('taskUpdated').textContent})");
  assert.deepEqual(completed.names, ['completed-old']);
  assert.match(completed.count, /1/);
  await js("setFloatingMode(true).then(() => setExpanded(true, false))");
  await delay(160);
  const floating = await js("[...document.querySelectorAll('#stripTasks .strip-task-name')].map(el=>el.textContent)");
  assert.deepEqual(floating, ['unfinished-near', 'unfinished-far', 'completed-recent']);
  await js("setFloatingMode(false)");
  await delay(80);
  await js("desktop.saveLanguage('ja')");
  const reloaded = new Promise(resolve => win.webContents.once('did-finish-load', resolve));
  win.webContents.reload(); await reloaded; await delay(120);
  const ja = await js("({lang:document.documentElement.lang, heading:document.getElementById('viewHeading').textContent, option:Boolean(document.querySelector('#settingLanguage option[value=\\\"ja\\\"]'))})");
  assert.equal(ja.lang, 'ja');
  assert.equal(ja.heading, 'すべての期限');
  assert.equal(ja.option, true);
  await js("setFloatingMode(true).then(() => desktop.openEditor())");
  let editor;
  for (let attempt = 0; attempt < 30 && !editor; attempt++) {
    await delay(100);
    editor = BrowserWindow.getAllWindows().find(item => item !== win);
  }
  assert.ok(editor);
  while (editor.webContents.isLoading()) await delay(30);
  await delay(360);
  const editorStyle = await editor.webContents.executeJavaScript("({radius:getComputedStyle(document.body).borderRadius,background:getComputedStyle(document.documentElement).backgroundColor})");
  assert.notEqual(editorStyle.radius, '0px');
  if (process.env.DDL_QA_DIR) {
    fs.mkdirSync(process.env.DDL_QA_DIR, {recursive:true});
    fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v213-japanese-floating.png'), (await win.webContents.capturePage()).toPNG());
    fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v213-quick-editor.png'), (await editor.webContents.capturePage()).toPNG());
  }
  console.log('PASS v213: pending-first ordering, 24-hour completion rollover, Japanese UI, rounded quick editor, floating list parity');
  app.exit(0);
} catch(error) { console.error(error); app.exit(1); } });
