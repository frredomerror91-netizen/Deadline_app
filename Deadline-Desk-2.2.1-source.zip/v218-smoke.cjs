const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v218-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({ tag_name: 'v' + require('./package.json').version }));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');

setTimeout(() => { console.error('v218 timeout'); app.exit(1); }, 60000).unref();

app.whenReady().then(async () => {
  try {
    const win = BrowserWindow.getAllWindows()[0];
    const js = code => win.webContents.executeJavaScript(code);
    while (win.webContents.isLoading()) await delay(40);
    await delay(150);

    const now = Date.now();
    const iso = hours => new Date(now + hours * 3600000).toISOString();
    const tasks = [
      { id: 'near', name: 'Urgent Task', deadline: iso(24) },
      { id: 'middle', name: 'Warning Task', deadline: iso(72) },
      { id: 'far', name: 'Distant Task', deadline: iso(168) },
      { id: 'done', name: 'Completed Task', deadline: iso(240), completed: true, completedAt: new Date(now).toISOString() }
    ];

    await js(`localStorage.setItem('deadline-desk.tasks', ${JSON.stringify(JSON.stringify(tasks))}); localStorage.setItem('deadline-desk.settings', ${JSON.stringify(JSON.stringify({ showCompleted: true, motion: false, highlightUrgent: true, urgentHours: 48, distantHours: 120 }))}); location.reload()`);
    while (win.webContents.isLoading()) await delay(40);
    await delay(220);

    // Verify main window rendering
    const mainCards = await js(`({
      count: document.querySelectorAll('#taskList [data-task-id]').length,
      near: document.querySelector('#taskList [data-task-id="near"]')?.className,
      middle: document.querySelector('#taskList [data-task-id="middle"]')?.className,
      far: document.querySelector('#taskList [data-task-id="far"]')?.className,
      done: document.querySelector('#taskList [data-task-id="done"]')?.className
    })`);

    assert.equal(mainCards.count, 4);
    assert.match(mainCards.near, /is-urgent/);
    assert.match(mainCards.middle, /is-warning/);
    assert.match(mainCards.far, /is-distant/);
    assert.match(mainCards.done, /is-completed/);

    // Switch to floating mode
    await js('setFloatingMode(true)');
    await delay(260);

    const floatingState = await js(`({
      floating: document.getElementById('appShell').classList.contains('is-floating'),
      count: document.querySelectorAll('#stripTasks [data-task-id]').length,
      pending: document.getElementById('miniTotal').textContent,
      near: document.querySelector('#stripTasks [data-task-id="near"]')?.className,
      middle: document.querySelector('#stripTasks [data-task-id="middle"]')?.className,
      far: document.querySelector('#stripTasks [data-task-id="far"]')?.className,
      done: document.querySelector('#stripTasks [data-task-id="done"]')?.className
    })`);

    assert.equal(floatingState.floating, true);
    assert.equal(floatingState.count, 4);
    assert.equal(floatingState.pending, '3');
    assert.match(floatingState.near, /is-urgent/);
    assert.match(floatingState.middle, /is-warning/);
    assert.match(floatingState.far, /is-distant/);
    assert.match(floatingState.done, /is-completed/);

    // Filter to distant and completed tasks to verify color contrast in compact and full views
    await js("tasks = tasks.filter(task => task.id === 'far' || task.id === 'done'); renderTasks()");

    for (const theme of ['light', 'gray', 'dark']) {
      const colors = await js(`(() => {
        window.setDeskTheme('${theme}');
        const color = selector => getComputedStyle(document.querySelector(selector)).color;
        const background = selector => getComputedStyle(document.querySelector(selector)).backgroundColor;
        return {
          previewName: color('.preview-task[data-task-id="far"] .strip-task-name'),
          previewCountdown: color('.preview-task[data-task-id="far"] .task-countdown'),
          listName: color('.strip-task[data-task-id="far"] .strip-task-name'),
          listCountdown: color('.strip-task[data-task-id="far"] .task-countdown'),
          mainName: color('.task-row[data-task-id="far"] .task-name'),
          mainCountdown: color('.task-row[data-task-id="far"] .task-countdown'),
          listBackground: background('.strip-task[data-task-id="far"]'),
          completedName: color('.strip-task[data-task-id="done"] .strip-task-name')
        };
      })()`);

      for (const key of ['previewName', 'previewCountdown', 'listName', 'listCountdown', 'mainName', 'mainCountdown']) {
        assert.equal(colors[key], 'rgb(255, 255, 255)', theme + ' ' + key);
      }
      assert.notEqual(colors.listBackground, 'rgb(255, 255, 255)', theme + ' background contrast');
      assert.notEqual(colors.completedName, 'rgb(255, 255, 255)', theme + ' completed green');
    }

    console.log('PASS v218: UI beautification verified across themes, cards and floating strip');
    app.exit(0);
  } catch (error) {
    console.error(error);
    app.exit(1);
  }
});
