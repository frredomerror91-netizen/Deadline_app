const nameInput = document.getElementById('name');
const deadlineInput = document.getElementById('deadline');
const form = document.getElementById('quickForm');
const errorLabel = document.getElementById('error');
const saveButton = form.querySelector('[type="submit"]');
const taskId = new URLSearchParams(location.search).get('taskId');
let editBaseline = null, saving = false, closing = false;
let exitAnimation;
const motionQuery = matchMedia('(prefers-reduced-motion: reduce)');
function editorMotionEnabled() {
  try { return JSON.parse(localStorage.getItem('deadline-desk.settings') || '{}').motion !== false && !motionQuery.matches; }
  catch { return !motionQuery.matches; }
}
function syncEditorMotion() {
  const enabled = editorMotionEnabled();
  document.documentElement.classList.toggle('motion-off', !enabled);
  if (!enabled) document.getAnimations().forEach(animation => animation.cancel());
}
syncEditorMotion();
motionQuery.addEventListener('change', syncEditorMotion);
window.addEventListener('storage', event => { if (event.key === 'deadline-desk.settings' || event.key === null) syncEditorMotion(); });
async function closeEditorAnimated() {
  if (closing) return;
  closing = true;
  window.desktop.beginEditorClose();
  saveButton.disabled = true;
  document.body.classList.add('is-closing');
  if (editorMotionEnabled()) {
    // The renderer must stay alive until the visible exit finishes.
    const style = getComputedStyle(document.body);
    exitAnimation = document.body.animate([
      { opacity: style.opacity, transform: style.transform },
      { opacity: 0, transform: 'translateY(8px) scale(.98)' }
    ], { duration: 160, easing: 'ease-in', fill: 'forwards' });
    let timer;
    try { await Promise.race([exitAnimation.finished, new Promise(resolve => { timer = setTimeout(resolve, 260); })]); }
    catch { /* A preference change can cancel motion; closing still completes. */ }
    finally { clearTimeout(timer); }
  }
  if (saving) window.desktop.tasksChanged();
  window.desktop.closeEditor();
}
try {
  if (taskId) {
    const task = TaskEditor.readRecords(localStorage).find(task => task && String(task.id) === taskId && !task.archivedAt && !task.deletedAt);
    if (!task) throw Object.assign(new Error('missing'), { code: 'missing' });
    editBaseline = { name: task.name, deadline: task.deadline };
    nameInput.value = task.name;
    deadlineInput.value = TaskEditor.localValue(task.deadline);
    document.getElementById('editorTitle').textContent = t('编辑任务');
    document.title = t('编辑任务');
    saveButton.textContent = t('保存修改');
  } else {
    const date = new Date();
    date.setDate(date.getDate() + 1);
    date.setHours(15, 0, 0, 0);
    deadlineInput.value = TaskEditor.localValue(date);
  }
  deadlineInput.dispatchEvent(new Event('change', { bubbles: true }));
} catch (error) { errorLabel.textContent = t(TaskEditor.errorText(error)); saveButton.disabled = true; }
document.getElementById('cancel').onclick = () => { void closeEditorAnimated(); };
document.addEventListener('keydown', event => { if (!event.defaultPrevented && event.key === 'Escape') void closeEditorAnimated(); });
form.onsubmit = event => {
  event.preventDefault();
  if (saving || closing || saveButton.disabled) return;
  try {
    const input = { name: nameInput.value, deadline: deadlineInput.value };
    const records = TaskEditor.readRecords(localStorage);
    const next = taskId ? TaskEditor.update(records, taskId, input, editBaseline)
      : [...records, { id: crypto.randomUUID(), ...TaskEditor.validate(input) }];
    localStorage.setItem('deadline-desk.tasks', JSON.stringify(next));
    saving = true; saveButton.disabled = true;
    void closeEditorAnimated();
  } catch (error) { errorLabel.textContent = t(TaskEditor.errorText(error)); }
};
