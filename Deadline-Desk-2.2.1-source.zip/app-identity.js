const fs = require('node:fs');
const path = require('node:path');
const VERSION = require('./package.json').version;
function identity(app) {
  const executable = app.isPackaged ? (process.env.PORTABLE_EXECUTABLE_FILE || process.execPath) : process.execPath;
  // Explorer must not cache an icon inside the portable launcher's disposable directory.
  let icon = path.join(__dirname, 'app-icon.ico');
  try {
    const directory = path.join(app.getPath('userData'), 'shell');
    fs.mkdirSync(directory, {recursive:true});
    const persistent = path.join(directory, 'deadline-desk.ico');
    fs.copyFileSync(icon, persistent); icon = persistent;
  } catch (error) { console.error('Persistent icon unavailable:', error.message); }
  return { version: VERSION, executable, icon };
}
function acknowledgeUpdate(app) {
  if (!process.env.DDL_UPDATE_JOB) return;
  const job = path.resolve(process.env.DDL_UPDATE_JOB);
  const relative = path.relative(path.join(app.getPath('userData'), 'updates'), job);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) return;
  try {
    const config = JSON.parse(fs.readFileSync(path.join(job, 'update.json'), 'utf8'));
    if (config.version !== VERSION || path.resolve(config.target).toLowerCase() !== path.resolve(process.env.PORTABLE_EXECUTABLE_FILE || process.execPath).toLowerCase()) return;
    fs.writeFileSync(path.join(job, 'started.json'), JSON.stringify({version:VERSION,pid:process.pid}));
    delete process.env.DDL_UPDATE_JOB;
  } catch (error) { console.error('Update acknowledgement failed:', error.message); }
}
module.exports = { VERSION, identity, acknowledgeUpdate };
