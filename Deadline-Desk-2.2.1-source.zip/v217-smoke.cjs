const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v217-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({tag_name: 'v' + require('./package.json').version}));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('v217 timeout'); app.exit(1); }, 60000).unref();
app.whenReady().then(async () => {
  try {
    const win = BrowserWindow.getAllWindows()[0];
    const js = code => win.webContents.executeJavaScript(code);
    while (win.webContents.isLoading()) await delay(40);
    await delay(150);
    const now = Date.now();
    const iso = hours => new Date(now + hours * 3600000).toISOString();
    const tasks = [
      { id: 'near', name: 'Near deadline', deadline: iso(24) },
      { id: 'middle', name: 'Middle deadline', deadline: iso(72) },
      { id: 'far', name: 'Far deadline', deadline: iso(168) },
      { id: 'done', name: 'Completed deadline', deadline: iso(240), completed: true, completedAt: new Date(now).toISOString() }
    ];
    await js(`localStorage.setItem('deadline-desk.tasks', ${JSON.stringify(JSON.stringify(tasks))}); localStorage.setItem('deadline-desk.settings', ${JSON.stringify(JSON.stringify({showCompleted:true,motion:false,highlightUrgent:true,urgentHours:48,distantHours:120}))}); location.reload()`);
    while (win.webContents.isLoading()) await delay(40);
    await delay(220);
    await js('setFloatingMode(true)');
    await delay(260);
    const state = await js(`({
      floating: document.getElementById('appShell').classList.contains('is-floating'),
      count: document.querySelectorAll('#stripTasks [data-task-id]').length,
      collapsedMonths: document.querySelectorAll('#stripTasks .deadline-month-items[hidden]').length,
      range: document.getElementById('stripRangeLabel').textContent,
      pending: document.getElementById('miniTotal').textContent,
      near: document.querySelector('[data-task-id="near"]')?.className,
      middle: document.querySelector('[data-task-id="middle"]')?.className,
      far: document.querySelector('[data-task-id="far"]')?.className,
      done: document.querySelector('[data-task-id="done"]')?.className
    })`);
    assert.equal(state.floating, true);
    assert.equal(state.count, 4);
    assert.equal(state.collapsedMonths, 0);
    assert.equal(state.range, '截止清单');
    assert.equal(state.pending, '3');
    assert.match(state.near, /is-urgent/);
    assert.match(state.middle, /is-warning/);
    assert.match(state.far, /is-distant/);
    assert.match(state.done, /is-completed/);
    assert.doesNotMatch(state.near, /is-completed/);
    assert.doesNotMatch(state.middle, /is-completed/);
    assert.doesNotMatch(state.far, /is-completed/);
    // Keep the distant pending task in the compact preview while inspecting actual colors.
    await js("tasks = tasks.filter(task => task.id === 'far' || task.id === 'done'); renderTasks()");
    // Verify rendered colors, not just class names: the old five-day CSS painted distant pending text green.
    for (const theme of ['light', 'gray', 'dark']) {
      const colors = await js(`(() => {
        window.setDeskTheme('${theme}');
        const color = selector => getComputedStyle(document.querySelector(selector)).color;
        const background = selector => getComputedStyle(document.querySelector(selector)).backgroundColor;
        return {
          previewName: color('.preview-task[data-task-id="far"] .strip-task-name'),
          previewCountdown: color('.preview-task[data-task-id="far"] .task-countdown'),
          listName: color('.strip-task[data-task-id="far"] .strip-task-name'),
          listCountdown: color('.strip-task[data-task-id="far"] .task-countdown'),
          mainName: color('.task-row[data-task-id="far"] .task-name'),
          mainCountdown: color('.task-row[data-task-id="far"] .task-countdown'),
          listBackground: background('.strip-task[data-task-id="far"]'),
          completedName: color('.strip-task[data-task-id="done"] .strip-task-name')
        };
      })()`);
      for (const key of ['previewName', 'previewCountdown', 'listName', 'listCountdown', 'mainName', 'mainCountdown']) {
        assert.equal(colors[key], 'rgb(255, 255, 255)', theme + ' ' + key);
      }
      assert.notEqual(colors.listBackground, 'rgb(255, 255, 255)', theme + ' background contrast');
      assert.notEqual(colors.completedName, 'rgb(255, 255, 255)', theme + ' completed green');
    }
    console.log('PASS v217: floating view includes every month and applies red/yellow/white/green deadline tones');
    app.exit(0);
  } catch (error) { console.error(error); app.exit(1); }
});
