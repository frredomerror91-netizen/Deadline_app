const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const {badgeBounds,overBadge}=require('./edge-hit-test');const {VERSION}=require('./app-identity');const {selectRelease,createUpdater,REPOSITORY}=require('./updater');
test('v209 identity and icon agree with build inputs',()=>{
 const pkg=require('./package.json');assert.equal(VERSION,pkg.version);
 assert.equal(pkg.build.win.icon,'app-icon.ico');assert.equal(pkg.build.appId,'com.deadlinedesk.app');const main=fs.readFileSync(path.join(__dirname,'main.js'),'utf8');assert.match(main,/app\.setAppUserModelId\('com\.deadlinedesk\.app'\)/);assert.match(main,/icon: shellIdentity\.icon/);assert.equal(pkg.build.portable.unpackDirName,true);const ico=fs.readFileSync(path.join(__dirname,'app-icon.ico'));assert.equal(ico.readUInt16LE(2),1);const count=ico.readUInt16LE(4);assert.ok(count>=6,'Windows ICO must contain multiple sizes');for(let i=0;i<count;i++){const e=6+i*16;const width=ico[e]||256,height=ico[e+1]||256,size=ico.readUInt32LE(e+8),offset=ico.readUInt32LE(e+12);assert.ok([16,24,32,48,64,128,256].includes(width)&&height===width);assert.equal(ico.subarray(offset,offset+8).compare(Buffer.from([137,80,78,71,13,10,26,10])),0);assert.ok(size>100);}
});
test('all four edges hit only the badge rectangle, including multi-monitor negative origins',()=>{
 for(const count of [true,false])for(const scale of [1,1.25,1.5,2])for(const edge of ['left','right','top','bottom']) {
 const bounds={x:-1920/scale,y:-1200/scale,width:480,height:360},b=badgeBounds(bounds,edge,count);
 assert.equal(overBadge({x:b.x+b.width/2,y:b.y+b.height/2},bounds,edge,count),true);
 for(const p of [{x:b.x-1,y:b.y+1},{x:b.x+b.width,y:b.y+1},{x:b.x+1,y:b.y-1},{x:b.x+1,y:b.y+b.height}])assert.equal(overBadge(p,bounds,edge,count),false,edge+JSON.stringify(p));
 }
});
test('same/older releases never offer update; mismatched tag asset is rejected',()=>{
 const release={tag_name:'v2.0.10',assets:[{name:'Deadline-Desk-2.0.10.exe',size:100,digest:'sha256:'+'a'.repeat(64),browser_download_url:`https://github.com/${REPOSITORY}/releases/download/v2.0.10/Deadline-Desk-2.0.10.exe`}]};
 assert.equal(selectRelease(release,'2.0.10'),null);assert.equal(selectRelease(release,'2.0.11'),null);assert.equal(selectRelease(release,'2.0.9').version,'2.0.10');release.assets[0].browser_download_url=release.assets[0].browser_download_url.replace('/v2.0.10/','/v2.0.7/');assert.throws(()=>selectRelease(release,'2.0.9'));
});
test('update state uses running source version and does not announce stale success',async()=>{
 const dir=fs.mkdtempSync(path.join(require('os').tmpdir(),'ddl-version-unit-'));fs.writeFileSync(path.join(dir,'last-result.json'),JSON.stringify({ok:true,version:'2.0.10'}));
 let request;const update=createUpdater({version:VERSION,directory:dir,fetch:async(url,options)=>{request=options;return new Response(JSON.stringify({tag_name:'v2.0.9'}));}});
 assert.match((await update.status()).message,/失败/);assert.equal((await update.check()).phase,'current');assert.equal((await update.status()).version,VERSION);assert.equal(request.cache,'no-store');
});

test('startup acknowledgement requires expected version, executable and isolated update directory',()=>{
 const {acknowledgeUpdate}=require('./app-identity'),profile=fs.mkdtempSync(path.join(require('os').tmpdir(),'ddl-ack-')),job=path.join(profile,'updates/job-test');fs.mkdirSync(job,{recursive:true});
 const app={getPath:()=>profile},previousJob=process.env.DDL_UPDATE_JOB,previousExe=process.env.PORTABLE_EXECUTABLE_FILE,target=path.join(profile,'Deadline.exe');process.env.PORTABLE_EXECUTABLE_FILE=target;
 try{
   for(const config of [{version:'2.0.8',target},{version:VERSION,target:path.join(profile,'other.exe')}]) {process.env.DDL_UPDATE_JOB=job;fs.writeFileSync(path.join(job,'update.json'),JSON.stringify(config));acknowledgeUpdate(app);assert.equal(fs.existsSync(path.join(job,'started.json')),false);}
   fs.writeFileSync(path.join(job,'update.json'),JSON.stringify({version:VERSION,target}));process.env.DDL_UPDATE_JOB=job;acknowledgeUpdate(app);assert.deepEqual(JSON.parse(fs.readFileSync(path.join(job,'started.json'),'utf8')),{version:VERSION,pid:process.pid});assert.equal(process.env.DDL_UPDATE_JOB,undefined);
   process.env.DDL_UPDATE_JOB=profile;fs.writeFileSync(path.join(profile,'update.json'),JSON.stringify({version:VERSION,target}));acknowledgeUpdate(app);assert.equal(fs.existsSync(path.join(profile,'started.json')),false);
 }finally{if(previousJob===undefined)delete process.env.DDL_UPDATE_JOB;else process.env.DDL_UPDATE_JOB=previousJob;if(previousExe===undefined)delete process.env.PORTABLE_EXECUTABLE_FILE;else process.env.PORTABLE_EXECUTABLE_FILE=previousExe;}
});
