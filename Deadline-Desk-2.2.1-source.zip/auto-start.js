const fs = require('node:fs');
const path = require('node:path');

function createAutoStart(app, executable, options = {}) {
  const file = path.join(app.getPath('userData'), 'auto-start.json');
  const supported = options.platform === 'win32' && options.packaged && !options.test;
  let enabled = false;
  try { enabled = JSON.parse(fs.readFileSync(file, 'utf8')).enabled === true; } catch {}
  const launch = { path: executable, args: [] };
  function sync() {
    if (!supported) return;
    const current = app.getLoginItemSettings(launch);
    if (current.openAtLogin !== enabled) {
      app.setLoginItemSettings({ ...launch, openAtLogin: enabled });
    }
  }
  function save(value) {
    if (typeof value !== 'boolean') throw new Error('Invalid auto-start value');
    if (!supported) throw new Error('Auto-start requires the packaged Windows application');
    app.setLoginItemSettings({ ...launch, openAtLogin: value });
    if (app.getLoginItemSettings(launch).openAtLogin !== value) throw new Error('Windows did not apply the startup setting');
    try { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify({ enabled: value })); }
    catch (error) { app.setLoginItemSettings({ ...launch, openAtLogin: enabled }); throw error; }
    enabled = value;
    return enabled;
  }
  return { get: () => ({ enabled, supported }), save, sync };
}
module.exports = { createAutoStart };
