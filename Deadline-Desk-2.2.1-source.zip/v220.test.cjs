const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createTranslator } = require('./i18n-core');
const { isNewer, selectRelease } = require('./updater');
const pkg = require('./package.json');
test('v2.2 release remains compatible with the existing updater version and attachment rules', () => {
  assert.match(pkg.version, /^2\.2\.\d+$/);
  assert.equal(isNewer('v'+pkg.version, '2.1.9'), true);
  assert.equal(isNewer('v2.2.1', '2.2.0'), true);
  const name='Deadline-Desk-'+pkg.version+'.exe';
  const base='https://github.com/frredomerror91-netizen/Deadline_app/releases/download/v'+pkg.version+'/';
  const release=selectRelease({tag_name:'v'+pkg.version,assets:[{name,size:100,browser_download_url:base+name},{name:name+'.sha256',browser_download_url:base+name+'.sha256'}]},'2.1.9');
  assert.equal(release.name,name);assert.equal(release.version,pkg.version);
});
test('short navigation names have English and Japanese equivalents',()=>{
  const names=['总清单','今日','本周','本月','已完成'];
  assert.deepEqual(names.map(createTranslator('en')),['All tasks','Today','This week','This month','Completed']);
  assert.deepEqual(names.map(createTranslator('ja')),['すべて','今日','今週','今月','完了済み']);
});
test('translated delete copy preserves user-supplied task names',()=>{
  const name='总清单 本周 <script>task</script>';
  const t=createTranslator('en');
  assert.equal(t('移入回收站'),'Move to recycle bin');
  assert.equal(t(['删除 ',''],name),'Delete '+name);
});
