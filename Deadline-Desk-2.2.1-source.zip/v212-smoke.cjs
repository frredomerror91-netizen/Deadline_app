const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v212-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({tag_name:'v'+require('./package.json').version}));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('v212 timeout'); app.exit(1); }, 45000).unref();
app.whenReady().then(async () => { try {
  const win = BrowserWindow.getAllWindows()[0];
  const js = code => win.webContents.executeJavaScript(code);
  while (win.webContents.isLoading()) await delay(40);
  await delay(100);
  await js("setDeskTheme('dark')");
  await js("(() => { const now=new Date(); const local=(date)=>toDateTimeLocal(date); const current=new Date(now.getFullYear(),now.getMonth(),15,12,0,0); const next=new Date(now.getFullYear(),now.getMonth()+1,15,12,0,0); tasks=[{id:'current',name:'current-month',deadline:local(current),completed:false},{id:'next',name:'next-month',deadline:local(next),completed:false}]; persistTasks(); renderTasks(); })()");
  await js("setFloatingMode(true).then(() => setExpanded(true, false))");
  await delay(120);
  const result = await js("({label:document.getElementById('stripRangeLabel').textContent,names:[...document.querySelectorAll('#stripTasks .strip-task-name')].map(el=>el.textContent),groups:[...document.querySelectorAll('#stripTasks > .deadline-month')].map(el=>({month:el.dataset.month,open:el.querySelector('button').getAttribute('aria-expanded')})),hasRangeSetting:Boolean(document.getElementById('settingFloatingRange')),radius:getComputedStyle(document.querySelector('.floating-strip')).borderRadius,theme:document.documentElement.dataset.theme,canvas:getComputedStyle(document.documentElement).getPropertyValue('--canvas').trim(),teal:getComputedStyle(document.documentElement).getPropertyValue('--teal').trim()})");
  const now = new Date();
  assert.ok(result.label.includes(String(now.getMonth()+1)), JSON.stringify(result));
  assert.ok(!result.label.includes('7 日内'), JSON.stringify(result));
  assert.deepEqual(result.names, ['current-month']);
  assert.deepEqual(result.groups.map(group => group.open), ['true']);
  assert.equal(result.hasRangeSetting, false);
  assert.notEqual(result.radius, '0px');
  assert.equal(result.theme, 'dark');
  assert.equal(result.canvas, '#0b0d10');
  assert.equal(result.teal, '#429ff0');
  if (process.env.DDL_QA_DIR) {
    fs.mkdirSync(process.env.DDL_QA_DIR, {recursive:true});
    await js("setFloatingMode(false).then(() => setView('completed-month', t('完成清单'))) "); await delay(120);
    fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v212-completed.png'), (await win.webContents.capturePage()).toPNG());
    await js("setFloatingMode(true).then(() => setExpanded(true, false))"); await delay(180);
    fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v212-floating-month.png'), (await win.webContents.capturePage()).toPNG());
  }
  console.log('PASS v212: current-month floating list, default-open month, seven-day setting removed, blue-hour layout');
  app.exit(0);
} catch(error) { console.error(error); app.exit(1); } });

