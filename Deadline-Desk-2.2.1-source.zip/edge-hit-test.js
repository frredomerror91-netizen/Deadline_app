function badgeBounds(b, edge, count = true) {
  const vertical = edge === 'left' || edge === 'right';
  const width = count ? 40 : vertical ? 6 : 40, height = count ? 28 : vertical ? 28 : 6;
  return { x: edge === 'left' ? b.x+b.width-width : edge === 'right' ? b.x : b.x+(b.width-width)/2,
    y: edge === 'top' ? b.y+b.height-height : edge === 'bottom' ? b.y : b.y+(b.height-height)/2, width, height };
}
function overBadge(cursor, bounds, edge, count) {
  const b=badgeBounds(bounds,edge,count);
  return cursor.x>=b.x && cursor.x<b.x+b.width && cursor.y>=b.y && cursor.y<b.y+b.height;
}
module.exports={badgeBounds,overBadge};
