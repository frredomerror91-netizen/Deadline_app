const { app, BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');
const fs = require('node:fs');
const { VERSION, identity, acknowledgeUpdate } = require('./app-identity');
let shellIdentity;
const instanceFile = path.join(app.getPath('userData'), 'running-instance.json');

const language = require('./native-language');
const { t } = language;
let mainWindow, lifecycle, rendererReady = false;
let desktopEditorActive = false, revealFloatingPending = false, startupChecked = false;
app.setAppUserModelId('com.deadlinedesk.app');
let updater, autoStart;
ipcMain.handle('get-auto-start', event => {
  if (!mainWindow || event.sender !== mainWindow.webContents) throw new Error(t('无效请求'));
  return autoStart.get();
});
ipcMain.handle('save-auto-start', (event, value) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) throw new Error(t('无效请求'));
  return autoStart.save(value);
});
for (const [channel, method] of [['update-status', 'status'], ['update-check', 'check'], ['update-install', 'install']]) {
  ipcMain.handle(channel, (event) => {
    if (!mainWindow || event.sender !== mainWindow.webContents || !updater) throw new Error(t('无效的更新请求'));
    return updater[method]();
  });
}
const primaryInstance = app.requestSingleInstanceLock({version: VERSION});
let pendingAction = process.argv.includes('--settings') ? 'settings' : process.argv.includes('--layer-menu') ? 'layer' : '';
let pendingAdd = process.argv.includes('--add-task');
function openDesktopEditor() {
  if (!mainWindow || !rendererReady) { pendingAdd = true; return; }
  desktopEditorActive = true;
  mainWindow.hide();
  mini.openEditor(true);
  pendingAdd = false;
}
function showFloating() {
  if (!mainWindow || !rendererReady) return;
  revealFloatingPending = true;
  mainWindow.webContents.send('show-floating');
}
app.on('second-instance', (_event, argv, _cwd, data) => {
  if (data?.version && data.version !== VERSION) return; // Secondary explains the version conflict.
  if (argv.includes('--add-task')) openDesktopEditor();
  else if (argv.includes('--settings') || argv.includes('--layer-menu')) {
    if (!lifecycle || !rendererReady) { pendingAction = argv.includes('--settings') ? 'settings' : 'layer'; return; }
    lifecycle.dispatch(argv.includes('--settings') ? 'settings' : 'layer');
  }
  else if (mainWindow) { mainWindow.restore(); mini.reveal(); mainWindow.show(); mainWindow.focus(); }
});
let desktopMenu, menuReady, quitting = false;
let menuError = '';
ipcMain.handle('desktop-menu', async (event, repair) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) return {ok:false,error:t('无效请求')};
  if (process.env.DDL_TEST) return {ok:true};
  try {
    await Promise.resolve(menuReady).catch(() => {});
    if (repair) { menuReady=desktopMenu.install(); await menuReady; menuError=''; }
    return await desktopMenu.status();
  } catch(error) { return {ok:false,error:menuError || error.message}; }
});
app.on('before-quit', event => {
  lifecycle?.allowQuit();
  if (!desktopMenu || quitting) return;
  event.preventDefault(); quitting = true;
  Promise.resolve(menuReady).then(() => desktopMenu.remove()).catch(error => console.error(t('桌面菜单清理失败:'), error.message)).finally(() => app.quit());
});
let normalBounds;
let floating = false;
let wasMaximized = false;
let mini, floatingSettings;
let maximized = false, restoreBounds;
function setMaximized(value) {
  if (value === maximized) return;
  if (value) {
    restoreBounds = mainWindow.getBounds();
    mainWindow.setBounds(screen.getDisplayMatching(restoreBounds).workArea, true);
  } else if (restoreBounds) mainWindow.setBounds(restoreBounds, true);
  maximized = value;
  mainWindow.webContents.send('window-maximized', value);
}

ipcMain.on('get-language-sync', event => { event.returnValue = language.get(); });
ipcMain.handle('save-language', async (event, value) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) throw new Error('Invalid sender');
  language.save(value);
  lifecycle?.refreshLanguage();
  if (desktopMenu) { menuReady = Promise.resolve(menuReady).then(() => desktopMenu.install()); await menuReady.catch(error => { menuError = error.message; }); }
  const editor = mini?.getEditor(); if (editor) editor.reload();
  return language.get();
});
function createWindow() {
  mainWindow = new BrowserWindow({
    show: false,
    width: 940,
    height: 660,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#00000000',
    transparent: true,
    icon: shellIdentity.icon,
    frame: false,
    thickFrame: false,
    hasShadow: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false
    }
  });

  require('./window-motion')(mainWindow, () => floating && lifecycle?.ensureTray());
  mainWindow.once('ready-to-show', () => { if (!pendingAdd && !desktopEditorActive) mainWindow.show(); });
  mini = require('./mini-window')(mainWindow, () => floating, () => {
    if (desktopEditorActive) { desktopEditorActive = false; showFloating(); }
  }, () => { desktopEditorActive = false; });
  floatingSettings = require('./floating-settings')(app, mainWindow, () => floating, mini);
  lifecycle = require('./window-lifecycle')({ app, win: mainWindow, mini, floatingSettings, openDesktopEditor, showFloating, shellIdentity, isFloating: () => floating });
  if (process.platform === 'win32' && app.isPackaged) {
    mainWindow.setAppDetails({ appId: 'com.deadlinedesk.app', appIconPath: process.execPath, appIconIndex: 0,
      relaunchCommand: `"${process.env.PORTABLE_EXECUTABLE_FILE || process.execPath}"`, relaunchDisplayName: 'Deadline Desk' });
  }
  if (!updater) updater = require('./updater').createUpdater({
    version: VERSION,
    target: process.env.PORTABLE_EXECUTABLE_FILE,
    enabled: app.isPackaged && process.platform === 'win32' && !process.env.DDL_TEST,
    directory: path.join(app.getPath('userData'), 'updates'),
    fetch: (...args) => require('electron').net.fetch(...args),
    quit: () => app.quit(),
    notify: state => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('update-state', state); }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  const sendState = () => mainWindow.webContents.send('window-maximized', maximized);
  mainWindow.webContents.on('did-start-loading', () => { rendererReady = false; });
  mainWindow.webContents.on('did-finish-load', () => {
    rendererReady = true; sendState();
    acknowledgeUpdate(app);
    if (!startupChecked) { startupChecked = true; void updater.check(); }
    if (pendingAdd) openDesktopEditor();
    if (pendingAction) { lifecycle.dispatch(pendingAction); pendingAction = ''; }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
}

ipcMain.handle('set-floating-mode', (event, enabled) => {
  if (!mainWindow || event.sender !== mainWindow.webContents || typeof enabled !== 'boolean') return;
  if (enabled !== floating) setNativeFloating(enabled);
  if (enabled && revealFloatingPending) {
    revealFloatingPending = false;
    floatingSettings.activate(); mini.reveal(); mainWindow.restore(); mainWindow.show(); mainWindow.focus();
  }
});
function setNativeFloating(enabled) {
  mini.reveal();
  if (enabled && !lifecycle.ensureTray()) return;
  floating = enabled;
  mainWindow.setSkipTaskbar(enabled);
  if (enabled) {
    wasMaximized = maximized;
    if (wasMaximized) setMaximized(false);
    normalBounds = mainWindow.getBounds();
    mainWindow.setAlwaysOnTop(true, 'floating');
    mainWindow.setMinimumSize(360, 72);
    mainWindow.setMaximumSize(0, 0);
    mainWindow.setSize(360, 72);
    mainWindow.setResizable(false);
    const area = screen.getDisplayMatching(normalBounds).workArea;
    mainWindow.setPosition(area.x + area.width - 360, area.y);
  } else {
    mainWindow.setAlwaysOnTop(false);
    mainWindow.setResizable(true);
    mainWindow.setMaximumSize(0, 0);
    mainWindow.setMinimumSize(760, 520);
    if (normalBounds) mainWindow.setBounds(normalBounds, true);
    if (wasMaximized) setMaximized(true);
  }
  mini.modeChanged();
  floatingSettings.apply();
}

ipcMain.on('window-action', (event, action) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) return;
  if (action === 'close') mainWindow.close();
  if (action === 'minimize') mainWindow.webContents.send('window-minimizing');
  if (action === 'maximize' && !floating) {
    setMaximized(!maximized);
  }
});

app.whenReady().then(async () => {
  if (!primaryInstance) {
    let running;
    try { running = JSON.parse(fs.readFileSync(instanceFile, 'utf8')); process.kill(running.pid, 0); } catch { running = null; }
    if ((!running || running.version !== VERSION) && !pendingAction && !pendingAdd) {
      await require('electron').dialog.showMessageBox({type:'info', title:'Deadline Desk',
        message:t('旧版仍在运行，新版尚未启动'),
        detail:t('本次启动版本：') + VERSION + '\n' + (running ? t('正在运行版本：') + running.version + '\n' : '') + t('请从系统托盘退出旧版，再重新打开新版 EXE。任务数据会保留；显示旧版本时，并不代表新文件已成功启动。'), buttons:[t('知道了')]});
    }
    app.quit(); return;
  }
  shellIdentity = identity(app);
  autoStart = require('./auto-start').createAutoStart(app, shellIdentity.executable, { platform: process.platform, packaged: app.isPackaged, test: Boolean(process.env.DDL_TEST) });
  try { autoStart.sync(); } catch (error) { console.error('Auto-start synchronization failed:', error); }
  fs.writeFileSync(instanceFile, JSON.stringify({version:VERSION,pid:process.pid}));
  app.on('will-quit', () => { try { if (JSON.parse(fs.readFileSync(instanceFile,'utf8')).pid === process.pid) fs.unlinkSync(instanceFile); } catch {} });
  createWindow();
  if (!process.env.DDL_TEST) {
    desktopMenu = require('./desktop-menu')(app);
    menuReady = desktopMenu.install().catch(error => {
      menuError=error.message; console.error(error);
      require('electron').dialog.showMessageBox(mainWindow, { type:'warning', message:t('桌面右键添加任务菜单未能启用'), detail:t('请检查当前用户的注册表访问权限。应用内仍可正常添加任务。') });
    });
  }
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
