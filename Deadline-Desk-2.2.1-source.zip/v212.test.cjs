const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { groupByMonth, monthKey } = require('./deadline-groups');

const source = name => fs.readFileSync(path.join(__dirname, name), 'utf8');

test('floating deadlines remain grouped by local calendar month without filtering to the current month', () => {
  const now = new Date('2026-09-25T12:00:00');
  const groups = groupByMonth([{ deadline:'2026-09-01T12:00:00' }, { deadline:'2026-10-01T12:00:00' }]);
  assert.deepEqual(groups.map(group => group.key), ['2026-09', '2026-10']);
  assert.equal(monthKey({ deadline:now.toISOString() }), '2026-09');
});

test('v2.1.2 removes the seven-day setting and uses the blue-hour visual system', () => {
  const app = source('app.js');
  const html = source('index.html');
  const css = source('styles.css');
  const theme = source('theme.js');
  assert.match(app, /global deadline view/);
  assert.doesNotMatch(app.slice(app.indexOf('function renderFloatingTasks'), app.indexOf('function setExpanded')), /inFloatingMonth/);
  assert.doesNotMatch(html, /id="settingFloatingRange"/);
  assert.match(html, /全部截止清单/);
  assert.doesNotMatch(css, /minimal line-based visual system/);
  assert.match(css, /--canvas: #0b0d10/);
  assert.match(css, /:root\[data-theme="dark"\]/);
  assert.match(css, /blue-hour layout/);
  assert.match(theme, /#0b0d10/);
});

