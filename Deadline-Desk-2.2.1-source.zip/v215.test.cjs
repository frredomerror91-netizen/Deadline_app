const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = name => fs.readFileSync(path.join(__dirname, name), 'utf8');
test('v2.1.5 hardens reveal geometry and uses black-blue dark theme', () => {
  const mini = source('mini-window.js');
  const css = source('styles.css');
  const theme = source('theme.js');
  const pkg = JSON.parse(source('package.json'));

  assert.match(mini, /function setFloatingBounds/);
  assert.match(mini, /mainWindow\.setResizable\(true\)/);
  assert.match(mini, /if \(t === 1\).*setFloatingBounds\(target\)/s);
  assert.match(css, /--canvas: #0b0d10/);
  assert.match(css, /--surface: #181b20/);
  assert.doesNotMatch(css, /--canvas: #0d1627/);
  assert.match(theme, /theme === 'dark' \? '#0b0d10'/);
});

