const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const issues = [];
const snapshots = [];
const output = process.env.DDL_DISPLAY_OUTPUT;
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-display-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({ tag_name: 'v2.1.9' }));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('display regression timeout'); app.exit(1); }, 60000).unref();
app.whenReady().then(async () => {
  try {
    const win = BrowserWindow.getAllWindows()[0];
    const js = code => win.webContents.executeJavaScript(code);
    const settled = async () => { while (win.webContents.isLoading()) await delay(30); await delay(180); };
    await settled();
    const tasks = [{ id: 'display-task', name: '大物第二章作业 / Deadline task', deadline: new Date(Date.now() + 72 * 3600000).toISOString() }];
    await js(`localStorage.setItem('deadline-desk.tasks', ${JSON.stringify(JSON.stringify(tasks))}); localStorage.setItem('deadline-desk.settings', '{"motion":false,"showCompleted":true}'); location.reload()`);
    await settled();
    for (const locale of ['zh-CN', 'en', 'ja']) {
      await js(`window.desktop.saveLanguage('${locale}').then(() => location.reload())`);
      await settled();
      assert.equal(await js('document.documentElement.lang'), locale);
      for (const width of [760, 940, 1180, 1440]) {
        win.setSize(width, 780); await delay(100);
        const result = await js(`(() => {
          const rect = el => {const r=el.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height};};
          const topbar=document.querySelector('.topbar');
          const controls=[...topbar.querySelectorAll('button')].filter(el=>el.getBoundingClientRect().width>0);
          const clipped=controls.filter(el=>{const r=el.getBoundingClientRect(),p=topbar.getBoundingClientRect();return r.left<p.left-1||r.right>p.right+1||r.top<p.top-1||r.bottom>p.bottom+1||el.scrollWidth>el.clientWidth+1;}).map(el=>el.id);
          const meta=getComputedStyle(document.querySelector('.task-meta'));
          const countdown=getComputedStyle(document.querySelector('.task-row .task-countdown'));
          return {width:innerWidth,clipped,metaSize:parseFloat(meta.fontSize),countdownSize:parseFloat(countdown.fontSize),header:rect(topbar)};
        })()`);
        snapshots.push({locale,...result});
        if(result.clipped.length) issues.push(`${locale}/${width} clipped controls: ${result.clipped.join(', ')}`);
        if(result.metaSize<12||result.countdownSize<12) issues.push(`${locale}/${width} deadline/countdown text too small`);
        await js("document.getElementById('settingsButton').click()");
        const selects = await js(`(() => {
          const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
          return [...document.querySelectorAll('[data-settings-panel="general"] select')].map(el=>{
            const s=getComputedStyle(el);ctx.font=s.font;
            const text=[...el.options].map(option=>option.textContent).sort((a,b)=>ctx.measureText(b).width-ctx.measureText(a).width)[0]||'';
            return {id:el.id,text,available:el.clientWidth-parseFloat(s.paddingLeft)-parseFloat(s.paddingRight),needed:ctx.measureText(text).width,right:el.getBoundingClientRect().right};
          });
        })()`);
        for(const select of selects) if(select.available+1<select.needed||select.right>width) issues.push(`${locale}/${width} clipped select: ${select.id} (${select.text})`);
        if(output&&(width===760||width===940)) { fs.mkdirSync(output,{recursive:true});fs.writeFileSync(path.join(output,`settings-${locale}-${width}.png`),(await win.webContents.capturePage()).toPNG());}
        await js("document.querySelector('[data-view=all]').click()");await delay(100);
        if(output&&(width===760||width===940)) fs.writeFileSync(path.join(output,`main-${locale}-${width}.png`),(await win.webContents.capturePage()).toPNG());
      }
    }
    // Exercise the actual round switch, including navigation preservation.
    await js("window.desktop.saveLanguage('zh-CN').then(() => location.reload())");await settled();
    await js("document.getElementById('settingsButton').click(); document.getElementById('languageToggle').click()");await settled();
    assert.equal(await js('document.documentElement.lang'), 'en');
    assert.equal(await js("document.getElementById('settingsPage').hidden"), false);
    await js("document.querySelector('[data-view=all]').click(); setFloatingMode(true)");await delay(300);
    for (const width of [360, 450, 620]) {
      win.setSize(width, 80);await delay(120);
      for(const theme of ['light','gray','dark']) {
        const result=await js(`(() => {window.setDeskTheme('${theme}'); const n=getComputedStyle(document.getElementById('miniTotal'));const time=getComputedStyle(document.querySelector('.preview-task .strip-task-time'));const countdown=getComputedStyle(document.querySelector('.preview-task .task-countdown'));return {background:n.backgroundColor,color:n.color,timeSize:parseFloat(time.fontSize),countdownSize:parseFloat(countdown.fontSize),count:document.getElementById('miniTotal').textContent};})()`);
        assert.equal(result.count,'1');
        if(result.background!=='rgba(0, 0, 0, 0)') issues.push(`${theme}/${width} count has filled background ${result.background}`);
        if(result.timeSize<11||result.countdownSize<11) issues.push(`${theme}/${width} floating time/countdown too small`);
        if(output&&width===450) fs.writeFileSync(path.join(output,`floating-${theme}.png`),(await win.webContents.capturePage()).toPNG());
      }
    }
    if(output)fs.writeFileSync(path.join(output,'report.json'),JSON.stringify({snapshots,issues},null,2));
    assert.equal(await js("tasks[0].name"),'大物第二章作业 / Deadline task','language changes preserve user task text');
    console.log(JSON.stringify({cases:snapshots.length,issues},null,2));
    assert.deepEqual(issues,[]);
    console.log('PASS display regression: locale switching, 760–1440px headers/selects, deadline fonts, 360–620px floating counts in three themes');
    app.exit(0);
  } catch(error) {console.error(error);app.exit(1);}
});
