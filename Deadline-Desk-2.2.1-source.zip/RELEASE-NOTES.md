# Deadline Desk v2.2.1

- 补齐悬浮清单展开、收起和新增任务时的淡入与位移动画，快速切换也能正确停在最终状态。
  Added fade and slide transitions for expanding, collapsing, and adding tasks in the floating list, including rapid toggles.
- 添加任务小窗在取消、按 Esc 或保存后平滑退出，重复点击只保存一次。
  The task editor now closes smoothly after cancel, Escape, or save, and repeated clicks save only once.
- 修复跨窗口重复通知打断任务动画的问题，定时刷新不重复播放任务入场动画。
  Fixed duplicate window notifications interrupting task animations; periodic refreshes do not replay task entry transitions.
- 动态效果设置同时覆盖主窗口和添加任务小窗，并遵循系统减少动态效果偏好。
  Motion preferences now cover both windows and respect the system reduced motion setting.
- 包含 v2.2 的改进：悬浮清单解锁时可用滚轮，任务文字更大，设置菜单与标签切换更平滑。
  Includes v2.2 improvements: scrolling while the floating window is unlocked, larger task text, and smoother settings menus and tabs.
- 导航简化为“总清单、今日、本周、本月、已完成”，灰色主题使用中性灰；删除任务改用应用内确认。
  Shorter navigation labels, a neutral gray theme, and in-app confirmations for task deletion.

Windows x64 · 免安装 / Portable · v2.2.1
