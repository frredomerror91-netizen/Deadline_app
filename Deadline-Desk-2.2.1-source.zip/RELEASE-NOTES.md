# Deadline Desk v2.2.1

- 按 v2.1.9 的节奏恢复任务入场、悬浮窗切换和添加任务动画，统一过渡时长与缓动，避免多个动画互相覆盖。
  Restored task entry, floating window transitions, and task editor motion using the v2.1.9 rhythm, with consistent timing and no competing animations.
- 悬浮清单展开时，任务依次淡入；收起、贴边隐藏与还原保持平滑，顶部仍可拖动，解锁后仍可滚动。
  Tasks fade in as the floating list expands. Collapse, edge hiding, and restore stay smooth, with header dragging and unlocked scrolling preserved.
- 添加任务、删除确认和日期选择器都有打开与关闭过渡，补充日历翻页、主题切换及按钮反馈。
  Added opening and closing transitions for task entry, confirmations, and the date picker, plus calendar paging, theme switching, and button feedback.
- 快速重复点击不会重复保存，退场期间重新打开可正确衔接；关闭动态效果时即时完成操作。
  Repeated clicks do not duplicate saves, reopening during exit works correctly, and disabling motion makes interactions immediate.
- 保留较大任务文字、简洁导航、中性灰主题和应用内删除确认。
  Keeps larger task text, shorter navigation labels, a neutral gray theme, and in-app deletion confirmations.

Windows x64 · 免安装 / Portable · v2.2.1

本次更新保持版本号不变，已安装 v2.2.1 的用户请重新下载本页 EXE 并替换旧文件；替换前从托盘退出旧程序，原任务保留。
This revision keeps version 2.2.1. If you already have v2.2.1, download this EXE again and replace the old file after quitting from the tray. Your tasks are preserved.
