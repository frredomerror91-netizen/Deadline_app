# Deadline Desk v2.2.1

- 任务删除、完成、归档和还原时，在原位置平滑收缩；列表连续补位，新增任务再展开，不整表闪现。
  Tasks contract in place when deleted, completed, archived, or restored. The list closes the gap smoothly, and new tasks expand into place.
- 月份分组与设置菜单都采用收缩、展开，快速反向点击接着当前高度过渡。
  Month groups and settings menus expand and contract from their current height, even when toggled rapidly.
- 排序时卡片连续移动；清单、设置页与标签切换保留简短交接，减少直接跳变。
  Cards move smoothly when sorted, and brief handoffs connect lists, settings pages, and tabs.
- 添加任务弹窗关闭后，新任务再展开；独立小窗打开和关闭日期选择器时，窗口尺寸也平滑变化。
  Newly saved tasks expand after the task dialog closes. The compact editor resizes smoothly when the date picker opens or closes.
- 保留悬浮窗展开、贴边、弹窗进退场与按钮反馈；动画简洁，关闭动态效果时即时完成操作。
  Keeps smooth floating window disclosure, edge hiding, dialog transitions, and button feedback. Motion stays restrained and becomes immediate when disabled.

Windows x64 · 免安装 / Portable · v2.2.1

本次修订保持版本号不变。已安装 v2.2.1 时，请重新下载本页 EXE，先从系统托盘退出旧程序，再替换文件。原任务保留。
This revision keeps version 2.2.1. If you already have v2.2.1, download this EXE again, quit the old app from the tray, and replace the file. Your tasks are preserved.
