const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = file => fs.readFileSync(path.join(__dirname, file), 'utf8');

test('v2.1.8 beautifies the user interface with modern glassmorphism, refined cards and polished typography', () => {
  const app = source('app.js');
  const html = source('index.html');
  const css = source('styles.css');
  const pkg = JSON.parse(source('package.json'));

  assert.equal(pkg.scripts['test:v218'], 'electron v218-smoke.cjs');

  // Verify UI beautification enhancements in styles.css
  assert.match(css, /v2\.1\.8 UI Beautification & Aesthetic Polish/);
  assert.match(css, /::-webkit-scrollbar/);
  assert.match(css, /backdrop-filter:\s*blur/);
  assert.match(css, /status-pulse/);
  assert.match(css, /\.task-row:hover/);
  assert.match(css, /\.task-edit:hover/);

  // Verify that required tone and contrast specifications remain intact
  assert.match(css, /\.task-row\.is-urgent/);
  assert.match(css, /\.task-row\.is-warning/);
  assert.match(css, /\.task-row\.is-distant/);
  assert.match(css, /\.task-row\.is-completed/);
  assert.match(css, /:root \.is-distant \.task-name/);

  // Verify HTML structure and scripts remain robust
  assert.match(html, /<div class="app-shell" id="appShell">/);
  assert.match(html, /<button class="add-button" id="addButton"/);
  assert.match(html, /<div class="floating-strip" id="floatingStrip"/);
});
