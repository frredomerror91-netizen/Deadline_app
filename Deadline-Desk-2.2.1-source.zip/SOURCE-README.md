# Deadline Desk v2.2.1 源码说明

本源码包对应 Windows x64 免安装版 v2.2.1，内部标准版本号为 `2.2.1`。包含应用源码、依赖清单及锁文件、测试、构建脚本和发布说明；不包含个人任务、用户配置、依赖目录、缓存、历史版本或打包输出。开发需要 Node.js、pnpm 和可交互的 Windows 桌面。

## 安装与运行

在解压后的源码目录运行：

~~~powershell
pnpm install --frozen-lockfile
pnpm start
~~~

应用沿用既有本地存储格式。升级时先从托盘退出旧版本，再运行新版；不要删除应用的用户数据目录。测试使用独立临时数据，不加载日常任务。

## 本次动画修订的定点检查

~~~powershell
pnpm run test:smooth-motion
~~~

- `test:unit` 覆盖更新器完整性及回滚、国际化、任务生命周期和编辑，包括 v2.2.1 与既有更新器的版本兼容。
- `test:v221` 验证任务入场、悬浮展开和收起、快速切换、跨窗口重复通知、独立编辑器打开和取消/保存退场、减少动态效果、窗口最小化和隐藏。
- `test:v220` 验证解锁及锁定状态下的真实滚轮输入、字体、导航、中性灰配色、设置下拉框和标签动画、键盘交互、延迟保存、应用内删除与保留期清理确认；包含延迟读取、保存期间冻结输入和防重复提交场景。
- `test:display` 验证中英日三种语言、760–1440px 主窗口、较长设置选项及 360–620px 三主题悬浮窗。
- `test:edit` 验证任务编辑、取消、写入失败、跨月刷新、并发变更及重启后的任务持久化。

需要截图时，为 `test:v220` 设置 `DDL_UI_OUTPUT`，为 `test:display` 设置 `DDL_DISPLAY_OUTPUT`。这些测试输出不加入源码 ZIP。

## 构建与整理附件

~~~powershell
pnpm dist
pnpm run release
~~~

构建固定使用 Electron 31.7.7；依赖由 `pnpm-lock.yaml` 锁定。构建命令禁用自动上传。发布整理脚本核对打包源码、EXE 版本与产品信息、SHA-256，以及源码 ZIP 中每个文件与当前源码的一致性。

标准附件目录为 `dist/github-v2.2.1/`，包含 `Deadline-Desk-2.2.1.exe`、同名 `.exe.sha256` 和 `Deadline-Desk-2.2.1-source.zip`。本地整理不会创建 GitHub Release。

若输出文件被占用，可使用独立构建目录：

~~~powershell
pnpm exec electron-builder --win --publish never --config.directories.output=dist/rebuild
$env:DDL_BUILD_DIR = 'dist/rebuild'
pnpm run release
Remove-Item Env:DDL_BUILD_DIR
~~~

## 验证构建包和实际便携程序

~~~powershell
$env:DDL_RELEASE_ASAR = Join-Path $PWD 'dist/win-unpacked/resources/app.asar'
pnpm exec electron smooth-motion-smoke.cjs
Remove-Item Env:DDL_RELEASE_ASAR
$env:DDL_PORTABLE_EXE = Join-Path $PWD 'dist/github-v2.2.1/Deadline-Desk-2.2.1.exe'
node portable-smoke.cjs
Remove-Item Env:DDL_PORTABLE_EXE
~~~

包内 UI 回归使用隔离配置；便携程序检查以 Node 模式启动真实 EXE，核验包内文件及并发启动时的独立解压目录，不加载真实任务。

## 本版实现位置

- `styles.css`：悬浮窗交互区域、任务字号、中性灰配色、下拉框和确认弹窗样式。
- `settings-controls.js`：保留表单值的应用内下拉框、键盘操作和遵循减少动态效果偏好的过渡。
- `app-dialog.js`：异步确认、焦点约束、Esc 取消和任务名称纯文本显示。
- `app.js`：设置同步、保存逻辑、标签动画及确认后的删除操作。
- `i18n-core.js`、`index.html`、`theme.js`、`update-ui.js`：文案、界面接入、灰色主题和 v2.2 显示。

- `app.js`：按任务内容变化播放清单过渡，重复通知不重建列表，悬浮内容与窗口尺寸动画配合。
- `add-task.js`：独立编辑器退出时先完成动画，阻止重复保存并同步动态效果偏好。
- `v221-smoke.cjs`：使用真实 Electron 窗口验证动画和任务保存行为。

## 同版本连续动效修订

版本仍为 `2.2.1`。`interaction-motion.js` 统一收缩/展开、列表布局补位和页面交接；`app.js` 为任务完成、删除、归档、还原及编辑接入过渡，并保留持久化失败恢复。`settings-controls.js` 的菜单在进退场和反向操作期间连续变高；`mini-window.js` 平滑改变日期选择器所需的原生编辑器尺寸。

`smooth-motion-smoke.cjs` 用临时配置验证11项真实交互：月份反向、菜单两端、任务删除补位、完成、归档还原、排序、悬浮快速开合、原生窗口缩放、新增任务展开、页面/标签交接，以及减少动态效果。采样中间帧的高度与位置，不仅检查动画对象存在。本轮没有重复运行全部历史回归。

## 交互动效约定

- 内容增减采用约260–300ms的高度过渡，保留当前位置，快速反向时从当前高度接续。
- 任务数据先安全保存，再播放出场；排序使用位置变化，倒计时与后台刷新不重播入场。
- 弹层用轻微位移和淡入淡出；页面交接保留约160ms的旧内容，单个动作的总体等待保持短暂。
- 输入、键盘焦点、滚动和拖动保持直接响应；应用或系统减少动态效果时使用最终状态。
