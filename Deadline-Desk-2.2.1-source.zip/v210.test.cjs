const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { groupByMonth, inFloatingRange, rangeDays } = require('./deadline-groups');
const { createAutoStart } = require('./auto-start');

test('deadline groups use local months and preserve the supplied deadline order', () => {
  const ordered = [
    { id:'dec', deadline:'2026-12-31T23:00' },
    { id:'jan1', deadline:'2027-01-01T00:00' },
    { id:'jan2', deadline:'2027-01-27T12:00' }
  ];
  assert.deepEqual(groupByMonth(ordered).map(group => [group.key, group.tasks.map(task => task.id)]), [
    ['2026-12', ['dec']], ['2027-01', ['jan1', 'jan2']]
  ]);
  assert.deepEqual(groupByMonth([]), []);
});

test('range defaults to 7 days, caps custom setting, includes overdue unfinished only', () => {
  assert.equal(rangeDays(undefined), 7); assert.equal(rangeDays(0), 7);
  assert.equal(rangeDays(1000), 7); assert.equal(rangeDays(999), 999);
  const now = new Date('2026-09-25T12:00:00');
  const task = (deadline, completed = false) => ({ deadline, completed });
  assert.equal(inFloatingRange(task('2026-10-02T12:00:00'), 7, now), true);
  assert.equal(inFloatingRange(task('2026-10-02T12:00:01'), 7, now), false);
  assert.equal(inFloatingRange(task('2026-09-24T23:00:00'), 1, now), true);
  assert.equal(inFloatingRange(task('2026-09-24T23:00:00', true), 1, now), false);
  assert.equal(inFloatingRange(task('2026-09-25T08:00:00', true), 1, now), true);
});

test('Windows auto-start defaults off, persists consent and refreshes the portable executable path', t => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'ddl-auto-'));
  t.after(() => fs.rmSync(profile, { recursive:true, force:true }));
  let entry = null;
  const app = {
    getPath: () => profile,
    getLoginItemSettings: ({ path: executable }) => ({ openAtLogin: Boolean(entry && entry.path === executable && entry.openAtLogin) }),
    setLoginItemSettings: settings => { entry = {...settings}; }
  };
  const opts = { platform:'win32', packaged:true, test:false };
  const startup = createAutoStart(app, 'C:\\Downloads\\Deadline-Desk-2.1.0.exe', opts);
  assert.deepEqual(startup.get(), { enabled:false, supported:true });
  assert.equal(entry, null, 'Default off must not create a registry entry');
  startup.sync(); assert.equal(entry, null);
  assert.equal(startup.save(true), true);
  assert.equal(entry.path, 'C:\\Downloads\\Deadline-Desk-2.1.0.exe');
  assert.equal(entry.openAtLogin, true);
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(profile, 'auto-start.json'))), { enabled:true });
  const upgraded = createAutoStart(app, 'C:\\Downloads\\Deadline-Desk-2.1.1.exe', opts);
  upgraded.sync(); assert.equal(entry.path, 'C:\\Downloads\\Deadline-Desk-2.1.1.exe');
  assert.equal(upgraded.save(false), false); assert.equal(entry.openAtLogin, false);
  assert.throws(() => upgraded.save('true'), /Invalid/);
  const dev = createAutoStart(app, 'C:\\Desktop\\electron.exe', {...opts, packaged:false});
  assert.equal(dev.get().supported, false);
  assert.throws(() => dev.save(true), /packaged Windows/);
});
