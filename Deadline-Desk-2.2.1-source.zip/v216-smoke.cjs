const { app, BrowserWindow, screen } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v216-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({tag_name: 'v' + require('./package.json').version}));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('v216 timeout'); app.exit(1); }, 60000).unref();
app.whenReady().then(async () => {
  try {
    const win = BrowserWindow.getAllWindows()[0];
    const js = code => win.webContents.executeJavaScript(code);
    while (win.webContents.isLoading()) await delay(40);
    await delay(150);
    await js('settings.motion=true;syncEdgeMotion();setFloatingMode(true)');
    await delay(200);
    await js('locked=false;renderLock()');
    const display = screen.getPrimaryDisplay(), area = display.workArea;
    const originalCursor = screen.getCursorScreenPoint;
    const originalBounds = win.setBounds;
    let cursor = {x: area.x + area.width / 2, y: area.y + area.height / 2};
    let injected = false;
    screen.getCursorScreenPoint = () => cursor;
    try {
      win.setBounds({x: area.x + area.width - 360, y: area.y + 100, width: 360, height: 72});
      await delay(1300);
      assert.equal(await js('document.body.dataset.edge'), 'right');
      const hidden = win.getBounds();
      win.setBounds = function (bounds, animate) {
        if (!injected && animate === false && bounds.x < hidden.x && bounds.x > area.x) {
          injected = true;
          throw new TypeError('Error processing argument at index 1, conversion failure');
        }
        return originalBounds.call(this, bounds, animate);
      };
      cursor = {x: hidden.x + 3, y: hidden.y + hidden.height / 2};
      await delay(400);
      assert.equal(injected, true, 'The native error must be injected in the timer callback');
      assert.equal(await js('document.body.dataset.edge'), '');
      assert.equal(win.getBounds().x, area.x + area.width - 360);
      assert.equal(win.getBounds().width, 360);
      assert.equal(win.isDestroyed(), false);
      await js('document.getElementById("stripExpandButton").click()');
      await delay(340);
      assert.equal(win.getBounds().height, 360);
    } finally {
      screen.getCursorScreenPoint = originalCursor;
      win.setBounds = originalBounds;
    }
    console.log('PASS v216: native animation error recovers without main-process crash; floating controls remain usable');
    app.exit(0);
  } catch (error) { console.error(error); app.exit(1); }
});
