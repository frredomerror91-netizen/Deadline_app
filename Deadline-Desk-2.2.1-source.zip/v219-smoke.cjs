const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v219-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({ tag_name: 'v' + require('./package.json').version }));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');

setTimeout(() => { console.error('v219 timeout'); app.exit(1); }, 60000).unref();

app.whenReady().then(async () => {
  try {
    const win = BrowserWindow.getAllWindows()[0];
    const js = code => win.webContents.executeJavaScript(code);
    while (win.webContents.isLoading()) await delay(40);
    await delay(150);

    const now = Date.now();
    const iso = hours => new Date(now + hours * 3600000).toISOString();
    const tasks = [
      { id: 'near', name: 'Urgent Task', deadline: iso(24) },
      { id: 'middle', name: 'Warning Task', deadline: iso(72) },
      { id: 'far', name: 'Distant Task', deadline: iso(168) },
      { id: 'done', name: 'Completed Task', deadline: iso(240), completed: true, completedAt: new Date(now).toISOString() }
    ];

    await js(`localStorage.setItem('deadline-desk.tasks', ${JSON.stringify(JSON.stringify(tasks))}); localStorage.setItem('deadline-desk.settings', ${JSON.stringify(JSON.stringify({ showCompleted: true, motion: true, highlightUrgent: true, urgentHours: 48, distantHours: 120 }))}); location.reload()`);
    while (win.webContents.isLoading()) await delay(40);
    await delay(220);

    // Verify restructured layout: topbar tools present and sidebar uncluttered
    const layout = await js(`({
      hasTopbarTools: Boolean(document.querySelector('.topbar-tools')),
      themeToggleInTopbar: Boolean(document.querySelector('.topbar #themeToggle')),
      settingsInTopbar: Boolean(document.querySelector('.topbar #settingsButton')),
      langInTopbar: Boolean(document.querySelector('.topbar #languageToggle')),
      floatingInSidebar: Boolean(document.querySelector('.sidebar #floatingToggle')),
      count: document.querySelectorAll('#taskList [data-task-id]').length
    })`);

    assert.equal(layout.hasTopbarTools, true, 'topbar tools container present');
    assert.equal(layout.themeToggleInTopbar, true, 'theme toggle in topbar');
    assert.equal(layout.settingsInTopbar, true, 'settings button in topbar');
    assert.equal(layout.langInTopbar, true, 'language toggle in topbar');
    assert.equal(layout.floatingInSidebar, true, 'floating toggle in sidebar');
    assert.equal(layout.count, 4, 'all 4 sample tasks rendered');

    // Switch to floating mode
    await js('setFloatingMode(true)');
    await delay(260);

    const floatingState = await js(`({
      floating: document.getElementById('appShell').classList.contains('is-floating'),
      count: document.querySelectorAll('#stripTasks [data-task-id]').length,
      pending: document.getElementById('miniTotal').textContent
    })`);

    assert.equal(floatingState.floating, true);
    assert.equal(floatingState.count, 4);
    assert.equal(floatingState.pending, '3');

    // Filter to distant and completed tasks to verify color contrast in compact and full views
    await js("tasks = tasks.filter(task => task.id === 'far' || task.id === 'done'); renderTasks()");

    for (const theme of ['light', 'gray', 'dark']) {
      const colors = await js(`(() => {
        window.setDeskTheme('${theme}');
        const color = selector => getComputedStyle(document.querySelector(selector)).color;
        const background = selector => getComputedStyle(document.querySelector(selector)).backgroundColor;
        return {
          previewName: color('.preview-task[data-task-id="far"] .strip-task-name'),
          previewCountdown: color('.preview-task[data-task-id="far"] .task-countdown'),
          listName: color('.strip-task[data-task-id="far"] .strip-task-name'),
          listCountdown: color('.strip-task[data-task-id="far"] .task-countdown'),
          mainName: color('.task-row[data-task-id="far"] .task-name'),
          mainCountdown: color('.task-row[data-task-id="far"] .task-countdown'),
          listBackground: background('.strip-task[data-task-id="far"]'),
          completedName: color('.strip-task[data-task-id="done"] .strip-task-name')
        };
      })()`);

      for (const key of ['previewName', 'previewCountdown', 'listName', 'listCountdown', 'mainName', 'mainCountdown']) {
        assert.equal(colors[key], 'rgb(255, 255, 255)', theme + ' ' + key);
      }
      assert.notEqual(colors.listBackground, 'rgb(255, 255, 255)', theme + ' background contrast');
      assert.notEqual(colors.completedName, 'rgb(255, 255, 255)', theme + ' completed green');
    }

    console.log('PASS v219: layout optimization, enhanced color palettes and smooth animations verified');
    app.exit(0);
  } catch (error) { console.error(error); app.exit(1); }
});
