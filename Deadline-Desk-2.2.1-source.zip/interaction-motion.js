// Continuous motion for disclosure, list layout and surface changes.
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const active = new Set(), byElement = new WeakMap(), disclosures = new WeakMap(), changes = new WeakMap();
  const easing = 'cubic-bezier(.22,.8,.25,1)';
  function enabled(preference) {
    if (preference === undefined) { try { preference = JSON.parse(localStorage.getItem('deadline-desk.settings') || '{}').motion; } catch {} }
    return preference !== false && !reduced.matches;
  }
  function sync(preference) {
    const on = enabled(preference);
    document.documentElement.classList.toggle('motion-off', !on);
    if (!on) for (const animation of active) animation.cancel();
    return on;
  }
  function stop(element) { byElement.get(element)?.cancel(); }
  function play(element, frames, options = {}) {
    if (!element) return null;
    stop(element);
    if (!enabled()) return null;
    const animation = element.animate(frames, { duration: 280, easing, fill: 'backwards', ...options });
    byElement.set(element, animation); active.add(animation);
    animation.finished.then(() => { if (['none', 'backwards'].includes(animation.effect.getTiming().fill)) active.delete(animation); }, () => active.delete(animation));
    return animation;
  }
  function enter(element, options = {}) {
    return play(element, [{ opacity: 0, transform: 'translateY(6px) scale(.985)' }, { opacity: 1, transform: 'none' }], options);
  }
  function leave(element, options = {}) {
    if (!element) return null;
    const style = getComputedStyle(element);
    return play(element, [{ opacity: style.opacity, transform: style.transform }, { opacity: 0, transform: 'translateY(4px) scale(.985)' }], { duration: 200, easing: 'cubic-bezier(.4,0,.2,1)', fill: 'forwards', ...options });
  }
  async function finished(animation) {
    if (!animation) return;
    let timer;
    try { await Promise.race([animation.finished, new Promise(resolve => { timer = setTimeout(resolve, 520); })]); }
    catch { /* Cancellation completes or hands off the current interaction. */ }
    finally { clearTimeout(timer); }
  }
  function disclose(element, open, options = {}) {
    if (!element) return Promise.resolve();
    const previous = disclosures.get(element);
    const visible = !element.hidden;
    const startHeight = options.from ?? (visible ? element.getBoundingClientRect().height : 0);
    const startStyle = getComputedStyle(element), startOpacity = visible ? startStyle.opacity : '0';
    const revision = (previous?.revision || 0) + 1;
    const state = { revision }; disclosures.set(element, state);
    stop(element);
    element.hidden = false; element.inert = !open;
    const style = getComputedStyle(element), fullHeight = element.getBoundingClientRect().height;
    const savedOverflow = previous?.overflow ?? element.style.overflow;
    state.overflow = savedOverflow;
    if (!enabled()) { element.hidden = !open; element.style.overflow = savedOverflow; disclosures.delete(element); return Promise.resolve(); }
    element.style.overflow = 'hidden';
    const full = { height: fullHeight + 'px', minHeight: '0px', paddingTop: style.paddingTop, paddingBottom: style.paddingBottom, marginTop: style.marginTop, marginBottom: style.marginBottom, borderTopWidth: style.borderTopWidth, borderBottomWidth: style.borderBottomWidth };
    const zero = { height: '0px', minHeight: '0px', paddingTop: '0px', paddingBottom: '0px', marginTop: '0px', marginBottom: '0px', borderTopWidth: '0px', borderBottomWidth: '0px' };
    const first = startHeight > 0 ? { ...full, height: startHeight + 'px', opacity: startOpacity, paddingTop: startStyle.paddingTop, paddingBottom: startStyle.paddingBottom, marginTop: startStyle.marginTop, marginBottom: startStyle.marginBottom, borderTopWidth: startStyle.borderTopWidth, borderBottomWidth: startStyle.borderBottomWidth } : { ...zero, opacity: 0 };
    const last = open ? { ...full, opacity: 1 } : { ...zero, opacity: .6 };
    const animation = play(element, [first, last], { duration: open ? 300 : 260, easing: 'cubic-bezier(.4,0,.2,1)', fill: 'both', ...options });
    return finished(animation).then(() => {
      if (disclosures.get(element) !== state) return;
      element.hidden = !open; element.inert = !open;
      stop(element); element.style.overflow = savedOverflow;
      disclosures.delete(element);
    });
  }
  function snapshot(container) {
    const rows = new Map(), groups = new Map();
    for (const row of container.querySelectorAll('[data-task-id]')) { const rect = row.getBoundingClientRect(); if (rect.height > 1) rows.set(row.dataset.taskId, { top: rect.top, left: rect.left }); }
    for (const group of container.querySelectorAll('.deadline-month')) { if (group.getBoundingClientRect().height > 1) groups.set(group.dataset.month, true); }
    return { rows, groups };
  }
  function layout(container, before = { rows: new Map(), groups: new Map() }) {
    if (!enabled() || !container.getClientRects().length) return;
    const newGroups = new Set();
    for (const group of container.querySelectorAll('.deadline-month')) if (!before.groups.has(group.dataset.month) && group.getBoundingClientRect().height > 1) { newGroups.add(group); void disclose(group, true, { from: 0 }); }
    const rows = [...container.querySelectorAll('[data-task-id]')];
    for (const row of rows) if (!before.rows.has(row.dataset.taskId) && !newGroups.has(row.closest('.deadline-month')) && row.getClientRects().length) void disclose(row, true, { from: 0 });
    // Measure after inserted rows have height zero, then move surviving rows continuously.
    const moves = rows.map(row => ({ row, previous: before.rows.get(row.dataset.taskId), rect: row.getBoundingClientRect() }));
    for (const { row, previous, rect } of moves) {
      if (!previous || !rect.height || newGroups.has(row.closest('.deadline-month'))) continue;
      const x = previous.left - rect.left, y = previous.top - rect.top;
      if (Math.abs(x) + Math.abs(y) > .5) play(row, [{ transform: 'translate(' + x + 'px,' + y + 'px)' }, { transform: 'none' }], { duration: 300 });
    }
    const empty = container.querySelector('.empty-state,.strip-empty,.preview-empty');
    if (empty && before.rows.size) void disclose(empty, true, { from: 0 });
  }
  function change(previous, next, update) {
    if (typeof next === 'function') { update = next; next = previous; }
    const parent = next.parentElement;
    const existing = changes.get(parent); if (existing) { stop(existing.ghost); existing.ghost.remove(); }
    let ghost;
    if (enabled() && previous && !previous.hidden && previous.getClientRects().length) {
      const rect = previous.getBoundingClientRect(), host = parent.getBoundingClientRect();
      ghost = previous.cloneNode(true); ghost.hidden = false; ghost.inert = true;
      for (const node of [ghost, ...ghost.querySelectorAll('*')]) for (const attribute of [...node.attributes]) if (attribute.name === 'id' || attribute.name === 'name' || attribute.name.startsWith('data-')) node.removeAttribute(attribute.name);
      ghost.classList.add('motion-outgoing'); ghost.setAttribute('aria-hidden', 'true');
      Object.assign(ghost.style, { position: 'absolute', left: (rect.left - host.left + parent.scrollLeft) + 'px', top: (rect.top - host.top + parent.scrollTop) + 'px', width: rect.width + 'px', height: rect.height + 'px', margin: '0', pointerEvents: 'none', zIndex: '20', overflow: 'hidden' });
      if (getComputedStyle(parent).position === 'static') parent.style.position = 'relative';
    }
    update();
    if (!ghost) return;
    parent.append(ghost); const state = { ghost }; changes.set(parent, state);
    const outgoing = play(ghost, [{ opacity: 1 }, { opacity: 0 }], { duration: 160, fill: 'forwards' });
    play(next, [{ opacity: 0, transform: 'translateY(4px)' }, { opacity: 1, transform: 'none' }], { duration: 240 });
    void finished(outgoing).then(() => { ghost.remove(); stop(ghost); if (changes.get(parent) === state) changes.delete(parent); });
  }
  window.DeskMotion = { enabled, sync, play, enter, leave, finished, stop, disclose, snapshot, layout, change, easing };
  reduced.addEventListener('change', () => sync());
  window.addEventListener('storage', event => { if (!event.key || event.key === 'deadline-desk.settings') sync(); });
  document.addEventListener('DOMContentLoaded', () => {
    for (const element of document.querySelectorAll('#error,#formError,#retentionStatus,#settingsSaveStatus,#autoStartStatus,#floatingSettingsStatus,#desktopMenuStatus,#updateStatus')) {
      const observer = new MutationObserver(() => {
        if (element.textContent.trim() && element.getClientRects().length) play(element, [{ opacity: .3 }, { opacity: 1 }], { duration: 180 });
      });
      observer.observe(element, { childList: true, characterData: true, subtree: true });
    }
  });
  sync();
})();
