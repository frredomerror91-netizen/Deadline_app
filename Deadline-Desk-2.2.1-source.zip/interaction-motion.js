// Shared renderer motion. Timing follows the v2.1.9 card and modal rhythm.
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const active = new Set(), byElement = new WeakMap();
  const easing = 'cubic-bezier(.16,1,.3,1)';
  function enabled(preference) {
    if (preference === undefined) {
      try { preference = JSON.parse(localStorage.getItem('deadline-desk.settings') || '{}').motion; } catch {}
    }
    return preference !== false && !reduced.matches;
  }
  function sync(preference) {
    const on = enabled(preference);
    document.documentElement.classList.toggle('motion-off', !on);
    if (!on) for (const animation of active) animation.cancel();
    return on;
  }
  function play(element, frames, options = {}) {
    if (!element) return null;
    byElement.get(element)?.cancel();
    if (!enabled()) return null;
    const animation = element.animate(frames, { duration: 280, easing, fill: 'backwards', ...options });
    byElement.set(element, animation);
    active.add(animation);
    animation.finished.then(() => { if (animation.effect.getTiming().fill !== 'forwards') active.delete(animation); }, () => active.delete(animation));
    return animation;
  }
  function enter(element, options = {}) {
    return play(element, [{ opacity: 0, transform: 'translateY(12px) scale(.96)' }, { opacity: 1, transform: 'none' }], options);
  }
  function leave(element, options = {}) {
    if (!element) return null;
    const style = getComputedStyle(element);
    return play(element, [{ opacity: style.opacity, transform: style.transform }, { opacity: 0, transform: 'translateY(8px) scale(.96)' }], { duration: 190, easing: 'cubic-bezier(.4,0,1,1)', fill: 'forwards', ...options });
  }
  async function finished(animation) {
    if (!animation) return;
    let timer;
    try { await Promise.race([animation.finished, new Promise(resolve => { timer = setTimeout(resolve, 420); })]); }
    catch { /* Disabling motion still completes the interaction. */ }
    finally { clearTimeout(timer); }
  }
  function stop(element) { byElement.get(element)?.cancel(); }
  window.DeskMotion = { enabled, sync, play, enter, leave, finished, stop, easing };
  reduced.addEventListener('change', () => sync());
  window.addEventListener('storage', event => { if (!event.key || event.key === 'deadline-desk.settings') sync(); });
  sync();
})();
