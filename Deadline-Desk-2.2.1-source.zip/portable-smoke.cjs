// Exercise the actual portable launcher without starting the app or touching user data.
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict');
const {execFile}=require('node:child_process'),{promisify}=require('node:util');const run=promisify(execFile),delay=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{const dir=await fs.mkdtemp(path.join(os.tmpdir(),'ddl-portable-')),probe=path.join(dir,'probe.cjs'),exe=process.env.DDL_PORTABLE_EXE || path.join(__dirname,'dist',`Deadline-Desk-${require('./package.json').version}.exe`);
 await fs.writeFile(probe,`const fs=require('fs'),path=require('path');const output=process.argv[2],runtime=path.dirname(process.execPath);fs.writeFileSync(output,JSON.stringify({runtime,exe:process.execPath,portable:process.env.PORTABLE_EXECUTABLE_FILE}));const until=Date.now()+Number(process.argv[3]);const timer=setInterval(()=>{if(!fs.existsSync(path.join(runtime,'resources/app.asar'))){console.error('Runtime removed while alive');process.exit(2)}if(Date.now()>until){clearInterval(timer);process.exit(0)}},100);`);
 const options={windowsHide:true,timeout:45000,env:{...process.env,ELECTRON_RUN_AS_NODE:'1'}};
 const a=path.join(dir,'first.json'),b=path.join(dir,'second.json');
 const first=run(exe,[probe,a,'10000'],options);const ready=async f=>{for(let i=0;i<200;i++){try{return JSON.parse(await fs.readFile(f,'utf8'))}catch{}await delay(100)}throw Error('Portable probe did not start')};
 const one=await ready(a);
 const pkg=require('./package.json'),{createRequire}=require('node:module'),crypto=require('node:crypto');
 const builder=createRequire(require.resolve('electron-builder')),asar=createRequire(builder.resolve('app-builder-lib'))('@electron/asar');
 const packed=path.join(one.runtime,'resources/app.asar');
 assert.equal(JSON.parse(asar.extractFile(packed,'package.json')).version,pkg.version);
 for(const file of pkg.build.files.filter(file=>file!=='package.json')) {
   const digest=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
   assert.equal(digest(asar.extractFile(packed,file)),digest(await fs.readFile(path.join(__dirname,file))),file+' in actual portable EXE');
 }
 const second=run(exe,[probe,b,'1500'],options);const two=await ready(b);assert.notEqual(one.runtime,two.runtime,'Each launch needs a unique extraction directory');assert.equal(one.portable,exe);await second;await fs.stat(path.join(one.runtime,'resources/app.asar'));await first;
 console.log('PASS actual portable EXE: all packed application files match current source; concurrent launches use independent runtime directories; exiting one keeps the other intact; no task data loaded');
})().catch(e=>{console.error(e);process.exitCode=1});
