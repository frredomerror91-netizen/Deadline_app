(() => {
  const controls = [];
  let opened;
  function close(control, restoreFocus = false) {
    if (!control) return Promise.resolve();
    if (restoreFocus) control.trigger.focus({ preventScroll: true });
    if (control.phase === 'closing') return control.pending;
    const token = control.transition = (control.transition || 0) + 1;
    control.phase = 'closing';
    control.trigger.setAttribute('aria-expanded', 'false');
    control.trigger.removeAttribute('aria-activedescendant');
    if (opened === control) opened = undefined;
    control.pending = DeskMotion.disclose(control.menu, false, { duration: 200 }).then(() => {
      if (control.transition !== token) return;
      control.wrapper.classList.remove('is-open'); control.phase = 'closed';
    });
    return control.pending;
  }
  function refresh(control) {
    const { select, trigger, menu } = control;
    trigger.querySelector('.setting-select-value').textContent = select.selectedOptions[0]?.textContent || '';
    trigger.disabled = select.disabled;
    menu.querySelectorAll('[role="option"]').forEach((option, index) => {
      const selected = index === select.selectedIndex;
      option.setAttribute('aria-selected', String(selected));
      option.disabled = select.options[index].disabled;
    });
  }
  function highlight(control, index) {
    const options = [...control.menu.querySelectorAll('[role="option"]')];
    control.index = index;
    options.forEach((option, i) => option.classList.toggle('is-highlighted', i === index));
    const option = options[index];
    if (option) {
      control.trigger.setAttribute('aria-activedescendant', option.id);
      option.scrollIntoView({ block: 'nearest' });
    }
  }
  function open(control) {
    if (opened !== control) void close(opened);
    control.transition = (control.transition || 0) + 1; control.phase = 'open';
    refresh(control);
    const { wrapper, trigger, menu, select } = control;
    wrapper.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    const rect = trigger.getBoundingClientRect();
    const below = innerHeight - rect.bottom - 14;
    const above = rect.top - 14;
    const up = below < Math.min(select.options.length * 40 + 12, 190) && above > below;
    wrapper.classList.toggle('opens-up', up);
    menu.style.maxHeight = Math.max(72, Math.min(240, up ? above : below)) + 'px';
    opened = control;
    void DeskMotion.disclose(menu, true, { duration: 240 });
    highlight(control, Math.max(0, select.selectedIndex));
    trigger.focus({ preventScroll: true });
  }
  function choose(control, index) {
    if (control.phase !== 'open') return;
    const option = control.select.options[index];
    if (!option || option.disabled) return;
    const changed = control.select.selectedIndex !== index;
    control.select.selectedIndex = index;
    refresh(control);
    close(control, true);
    if (changed) {
      control.select.dispatchEvent(new Event('input', { bubbles: true }));
      control.select.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }
  document.querySelectorAll('#settingsPage select').forEach(select => {
    const wrapper = document.createElement('div');
    wrapper.className = 'setting-select';
    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'setting-select-trigger';
    trigger.dataset.selectFor = select.id;
    trigger.setAttribute('role', 'combobox');
    trigger.setAttribute('aria-haspopup', 'listbox');
    trigger.setAttribute('aria-expanded', 'false');
    const label = select.closest('label')?.querySelector('span');
    if (label) { label.id ||= select.id + '-label'; trigger.setAttribute('aria-labelledby', label.id); }
    const value = document.createElement('span');
    value.className = 'setting-select-value';
    const chevron = document.createElement('span');
    chevron.className = 'setting-select-chevron';
    chevron.setAttribute('aria-hidden', 'true');
    trigger.append(value, chevron);
    const menu = document.createElement('div');
    menu.className = 'setting-select-menu';
    menu.id = select.id + '-listbox';
    menu.hidden = true;
    menu.setAttribute('role', 'listbox');
    if (label) menu.setAttribute('aria-labelledby', label.id);
    trigger.setAttribute('aria-controls', menu.id);
    select.before(wrapper);
    wrapper.append(select, trigger, menu);
    select.classList.add('setting-native-select');
    select.tabIndex = -1;
    select.setAttribute('aria-hidden', 'true');
    const control = { select, wrapper, trigger, menu, index: select.selectedIndex };
    [...select.options].forEach((option, index) => {
      const item = document.createElement('button');
      item.type = 'button'; item.tabIndex = -1;
      item.setAttribute('role', 'option'); item.id = select.id + '-option-' + index;
      item.textContent = option.textContent;
      item.addEventListener('click', event => { event.preventDefault(); choose(control, index); });
      item.addEventListener('pointermove', () => highlight(control, index));
      menu.append(item);
    });
    trigger.addEventListener('click', event => { event.preventDefault(); opened === control ? close(control) : open(control); });
    trigger.addEventListener('keydown', event => {
      const { key } = event;
      if (key === 'Escape') { if (opened === control) { event.preventDefault(); event.stopPropagation(); close(control, true); } return; }
      if (key === 'Tab') { close(control); return; }
      if (!['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '].includes(key)) return;
      event.preventDefault();
      if (opened !== control) { open(control); return; }
      if (key === 'Enter' || key === ' ') { choose(control, control.index); return; }
      const direction = key === 'ArrowUp' || key === 'End' ? -1 : 1;
      let index = key === 'Home' ? 0 : key === 'End' ? select.options.length - 1 : (control.index + direction + select.options.length) % select.options.length;
      for (let count = 0; count < select.options.length && select.options[index].disabled; count++) index = (index + direction + select.options.length) % select.options.length;
      highlight(control, index);
    });
    wrapper.addEventListener('focusout', event => { if (!wrapper.contains(event.relatedTarget)) close(control); });
    select.addEventListener('change', () => refresh(control));
    controls.push(control); refresh(control);
  });
  document.addEventListener('pointerdown', event => { if (opened && !opened.wrapper.contains(event.target)) close(opened); });
  window.addEventListener('resize', () => close(opened));
  window.closeSettingsSelects = () => close(opened);
  window.refreshSettingsSelects = () => controls.forEach(refresh);
})();
