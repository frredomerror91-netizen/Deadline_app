const {app,BrowserWindow,screen,ipcMain}=require('electron');const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const delay=ms=>new Promise(r=>setTimeout(r,ms));app.commandLine.appendSwitch('disable-renderer-backgrounding');app.commandLine.appendSwitch('disable-features','CalculateNativeWinOcclusion');
app.setPath('userData',fs.mkdtempSync(path.join(app.getPath('temp'),'ddl-v209-')));process.env.DDL_TEST='1';
const skipCalls=[],originalSkip=BrowserWindow.prototype.setSkipTaskbar;BrowserWindow.prototype.setSkipTaskbar=function(value){skipCalls.push(value);return originalSkip.call(this,value)};
require('electron').net.fetch = async () => new Response(JSON.stringify({tag_name:'v'+require('./package.json').version}));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR,'main.js') : './main');
setTimeout(()=>{console.error('v209 timeout');app.exit(1)},90000).unref();
app.whenReady().then(async()=>{try{
 const win=BrowserWindow.getAllWindows()[0],js=async s=>{try{return await win.webContents.executeJavaScript(s)}catch(e){console.error("Failed renderer script:",s);throw e}};
 while(win.webContents.isLoading())await delay(50);await delay(250);
 const errors=[];win.webContents.on('console-message',(_e,level,message)=>{if(level===3)errors.push(message)});
 assert.equal(await js('desktop.updateStatus().then(s=>s.version)'),require('./package.json').version);assert.match(await js('appVersion.textContent'),new RegExp(require('./package.json').version.replaceAll('.', '\\.')));
 assert.equal(fs.existsSync(path.join(app.getPath('userData'),'shell/deadline-desk.ico')),true);
 await js(`settings.motion=false;tasks=[{id:'todo',name:'待删除任务 <b>原样保留</b>',deadline:'2030-01-01T12:00'},{id:'done',name:'已完成后删除',deadline:'2030-02-01T12:00',completed:true,completedAt:new Date().toISOString()},{id:'archived',name:'旧完成归档',deadline:'2030-01-01T12:00',completed:true,completedAt:new Date().toISOString(),archivedAt:new Date().toISOString()}];persistTasks();renderTasks();window.realConfirm=window.confirm;window.confirm=()=>false;document.querySelector('[data-delete=todo]').click()`);
 assert.equal(await js('tasks[0].deletedAt'),undefined);
 await js(`window.confirm=()=>true;document.querySelector('[data-delete=todo]').click()`);
 assert.equal(await js('!!tasks[0].deletedAt && !!tasks[0].archivedAt && !tasks[0].completed'),true);
 assert.equal(await js("getFilteredTasks().some(t=>t.id==='todo')"),false);
 await js(`removeTask('done');setView('completed-all',t('完成清单'))`);assert.equal(await js('getFilteredTasks().length'),0);
 await js(`setView('trash',t('回收站'))`);assert.deepEqual(await js('[getFilteredTasks().length,taskList.querySelectorAll(".is-deleted").length]'),[3,2]);
 assert.match(await js('taskList.textContent'),/已删除/);assert.match(await js('taskList.textContent'),/已归档/);assert.equal(await js('!!taskList.querySelector("b")'),false);
 if(process.env.DDL_QA_DIR){fs.mkdirSync(process.env.DDL_QA_DIR,{recursive:true});fs.writeFileSync(path.join(process.env.DDL_QA_DIR,'v209-trash.png'),(await win.webContents.capturePage()).toPNG())}
 await js(`restoreArchived('todo');restoreArchived('done')`);assert.deepEqual(await js('[!!tasks[0].deletedAt,!!tasks[0].archivedAt,!!tasks[0].completed,!!tasks[1].completed,!!tasks[1].completedAt]'),[false,false,false,true,true]);
 // Transaction rollback when localStorage cannot be written.
 await js(`window.realSet=Storage.prototype.setItem;window.realAlert=window.alert;window.alert=()=>{};Storage.prototype.setItem=function(){throw Error('full')};removeTask('todo');Storage.prototype.setItem=window.realSet;window.alert=window.realAlert;void 0`);assert.equal(await js('!!tasks[0].deletedAt || !!tasks[0].archivedAt'),false);
 await js(`removeTask('todo');window.confirm=()=>false;deleteArchived('todo')`);assert.equal(await js("tasks.some(t=>t.id==='todo')"),true);
 await js(`window.confirm=()=>true;deleteArchived('todo');window.confirm=window.realConfirm;void 0`);assert.equal(await js("tasks.some(t=>t.id==='todo')"),false);
 await js('setFloatingMode(true)');assert.equal(skipCalls.at(-1),true);assert.equal(win.isVisible(),true);
 ipcMain.emit('finish-minimize',{sender:win.webContents});await delay(100);assert.equal(win.isVisible(),false);assert.equal(win.isMinimized(),false);
 win.webContents.send('show-floating');win.show();await delay(150);assert.equal(skipCalls.at(-1),true);
 await js('setFloatingMode(false)');assert.equal(skipCalls.at(-1),false);
 await js('settings.motion=true;setFloatingMode(true)');await delay(250);
 // Interrupted transitions settle on the latest intent.
 await js('setFloatingMode(false);setFloatingMode(true);setFloatingMode(false)');await delay(400);assert.equal(skipCalls.at(-1),false);assert.equal(await js('appShell.classList.contains("is-floating")'),false);
 await js('settings.motion=false;syncEdgeMotion();setFloatingMode(true)');await delay(100);
 const originalCursor=screen.getCursorScreenPoint,originalDisplays=screen.getAllDisplays,display=screen.getPrimaryDisplay(),a=display.workArea;let cursor={x:a.x+a.width/2,y:a.y+a.height/2};screen.getCursorScreenPoint=()=>cursor;screen.getAllDisplays=()=>[display];
 try{for(const side of ['left','right','top','bottom']){
 await js('locked=true;renderLock()');await delay(50);const b={x:side==='left'?a.x:side==='right'?a.x+a.width-360:a.x+100,y:side==='top'?a.y:side==='bottom'?a.y+a.height-72:a.y+100,width:360,height:72};win.setBounds(b);await js('locked=false;renderLock()');await delay(1300);assert.equal(await js('document.body.dataset.edge'),side);
 const hidden=win.getBounds(),{badgeBounds}=require('./edge-hit-test'),badge=badgeBounds(hidden,side);
 for(const point of [{x:badge.x-4,y:badge.y+14},{x:badge.x+44,y:badge.y+14},{x:badge.x+20,y:badge.y-4},{x:badge.x+20,y:badge.y+32}]) {cursor=point;await delay(100);assert.equal(await js('document.body.dataset.edge'),side,side+JSON.stringify(point));}
 cursor={x:badge.x+20,y:badge.y+14};await delay(150);assert.equal(await js('document.body.dataset.edge'),'');cursor={x:a.x+a.width/2,y:a.y+a.height/2};
 }}finally{screen.getCursorScreenPoint=originalCursor;screen.getAllDisplays=originalDisplays}
 await js('locked=true;renderLock();setFloatingMode(false)');assert.deepEqual(errors,[]);
 const loaded=new Promise(r=>win.webContents.once('did-finish-load',r));win.reload();await loaded;await delay(200);assert.equal(await js('tasks.length'),2);
 console.log('PASS v209: runtime version, persistent icon, cancel/soft-delete/restore/permanent-delete/storage rollback, tray/taskbar transitions, rapid switching, four-edge precise hover, persistence');app.exit(0);
}catch(error){console.error(error);app.exit(1)}});


