const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = file => fs.readFileSync(path.join(__dirname, file), 'utf8');
test('v2.1.7 shows all unfinished floating deadlines with continuous tones and resize motion', () => {
  const app = source('app.js');
  const html = source('index.html');
  const css = source('styles.css');
  const main = source('main.js');
  const pkg = JSON.parse(source('package.json'));

  assert.match(app, /global deadline view/);
  assert.doesNotMatch(app.slice(app.indexOf('function renderFloatingTasks'), app.indexOf('function setExpanded')), /inFloatingMonth/);
  assert.match(app, /function toneClass/);
  assert.match(app, /row\.classList\.remove\('is-urgent', 'is-warning', 'is-distant', 'is-completed'\)/);
  assert.match(app, /is-warning/);
  assert.match(html, /标白时间（小时）/);
  assert.match(html, /所有未完成任务/);
  assert.match(css, /\.task-row\.is-completed/);
  assert.match(css, /\.task-row\.is-warning/);
  assert.match(css, /\.task-row\.is-distant/);
  assert.doesNotMatch(css, /\.is-distant[^\n]*color:\s*#(?:176236|83d6a0)/);
  assert.match(css, /:root \.is-distant \.task-name[^\n]*color: #ffffff/);
  assert.match(app, /animateWindowResize/);
  assert.match(main, /setBounds\(screen\.getDisplayMatching\(restoreBounds\)\.workArea, true\)/);
});
