/* Shared deadline grouping and current-month floating-list rules (local calendar months). */
(function(root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.DeadlineGroups = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, () => {
  const validDays = value => Number.isInteger(value) && value >= 1 && value <= 999;
  const rangeDays = value => validDays(value) ? value : 7;
  function monthKey(task) {
    const date = new Date(task.deadline);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  }
  function groupByMonth(ordered) {
    const groups = [], byKey = new Map();
    for (const task of ordered) {
      const key = monthKey(task);
      if (!byKey.has(key)) {
        const group = { key, tasks: [] };
        byKey.set(key, group); groups.push(group);
      }
      byKey.get(key).tasks.push(task);
    }
    return groups;
  }
  function inFloatingRange(task, days, now = new Date()) {
    const deadline = new Date(task.deadline).getTime();
    const start = new Date(now); start.setHours(0, 0, 0, 0);
    // Keep overdue unfinished tasks actionable, but avoid resurfacing old completed tasks.
    return deadline <= now.getTime() + rangeDays(days) * 86400000 && (!task.completed || deadline >= start.getTime());
  }
  function inFloatingMonth(task, now = new Date()) {
    const deadline = new Date(task.deadline);
    return Number.isFinite(deadline.getTime()) && deadline.getFullYear() === now.getFullYear() && deadline.getMonth() === now.getMonth();
  }
  return { rangeDays, monthKey, groupByMonth, inFloatingRange, inFloatingMonth };
});
