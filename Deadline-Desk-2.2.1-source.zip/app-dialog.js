(() => {
  const backdrop = document.getElementById('confirmBackdrop');
  const panel = backdrop.querySelector('[role="alertdialog"]');
  const cancel = document.getElementById('confirmCancel');
  const accept = document.getElementById('confirmAccept');
  const shell = document.getElementById('appShell');
  let pending, previousFocus, previousInert, animation;
  function finish(accepted) {
    if (!pending) return;
    const resolve = pending; pending = undefined;
    animation?.cancel(); backdrop.hidden = true;
    shell.inert = previousInert;
    if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    resolve(accepted);
  }
  cancel.addEventListener('click', () => finish(false));
  accept.addEventListener('click', () => finish(true));
  backdrop.addEventListener('click', event => { if (event.target === backdrop) finish(false); });
  document.addEventListener('keydown', event => {
    if (!pending) return;
    if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); finish(false); }
    else if (event.key === 'Tab') {
      const buttons = [cancel, accept];
      const index = buttons.indexOf(document.activeElement);
      event.preventDefault();
      buttons[(index + (event.shiftKey ? -1 : 1) + buttons.length) % buttons.length].focus();
    }
  }, true);
  window.DeskDialog = { confirm({ title, message, taskName = '', confirmLabel }) {
    if (pending) return Promise.resolve(false);
    window.closeSettingsSelects?.();
    previousFocus = document.activeElement; previousInert = shell.inert;
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMessage').textContent = message;
    const name = document.getElementById('confirmTaskName'); name.textContent = taskName; name.hidden = !taskName;
    accept.textContent = confirmLabel;
    shell.inert = true; backdrop.hidden = false;
    const result = new Promise(resolve => { pending = resolve; });
    cancel.focus({ preventScroll: true });
    if (!document.documentElement.classList.contains('motion-off') && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
      animation = panel.animate([{ opacity: 0, transform: 'translateY(8px) scale(.98)' },{ opacity: 1, transform: 'none' }],{ duration: 170, easing: 'cubic-bezier(.2,.7,.2,1)' });
    }
    return result;
  } };
})();
