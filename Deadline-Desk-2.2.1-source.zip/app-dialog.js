(() => {
  const backdrop = document.getElementById('confirmBackdrop');
  const panel = backdrop.querySelector('[role="alertdialog"]');
  const cancel = document.getElementById('confirmCancel');
  const accept = document.getElementById('confirmAccept');
  const shell = document.getElementById('appShell');
  let pending, previousFocus, previousInert, animation, closing = false;
  async function finish(accepted) {
    if (!pending || closing) return;
    closing = true;
    animation?.cancel();
    animation = DeskMotion.leave(panel);
    DeskMotion.play(backdrop, [{ opacity: 1 }, { opacity: 0 }], { duration: 190, fill: 'forwards' });
    await DeskMotion.finished(animation);
    const resolve = pending; pending = undefined;
    backdrop.hidden = true;
    DeskMotion.stop(panel); DeskMotion.stop(backdrop);
    shell.inert = previousInert;
    closing = false;
    if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    resolve(accepted);
  }
  cancel.addEventListener('click', () => finish(false));
  accept.addEventListener('click', () => finish(true));
  backdrop.addEventListener('click', event => { if (event.target === backdrop) finish(false); });
  document.addEventListener('keydown', event => {
    if (!pending) return;
    if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); finish(false); }
    else if (event.key === 'Tab') {
      const buttons = [cancel, accept];
      const index = buttons.indexOf(document.activeElement);
      event.preventDefault();
      buttons[(index + (event.shiftKey ? -1 : 1) + buttons.length) % buttons.length].focus();
    }
  }, true);
  window.DeskDialog = { confirm({ title, message, taskName = '', confirmLabel }) {
    if (pending) return Promise.resolve(false);
    window.closeSettingsSelects?.();
    previousFocus = document.activeElement; previousInert = shell.inert;
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMessage').textContent = message;
    const name = document.getElementById('confirmTaskName'); name.textContent = taskName; name.hidden = !taskName;
    accept.textContent = confirmLabel;
    shell.inert = true; backdrop.hidden = false;
    const result = new Promise(resolve => { pending = resolve; });
    cancel.focus({ preventScroll: true });
    animation = DeskMotion.enter(panel);
    DeskMotion.play(backdrop, [{ opacity: 0 }, { opacity: 1 }], { duration: 220 });
    return result;
  } };
})();
