param([Parameter(Mandatory=$true)][string]$ConfigPath)
$ErrorActionPreference = 'Stop'
$job = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($ConfigPath))
$moved = $false
$stage = $null
$config = $null
try {
$config = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
$target = [IO.Path]::GetFullPath($config.target)
$stage = $target + '.new-' + [Guid]::NewGuid().ToString('N')
$backup = $target + '.previous-' + [Guid]::NewGuid().ToString('N') + '.exe'
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Original executable not found' }
    Copy-Item -LiteralPath $config.source -Destination $stage
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($stage)
    try { $digest = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
    if ($digest -ne $config.digest) { throw 'Checksum mismatch' }
    if ($config.version) {
        if ($config.version -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid expected version' }
        $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($stage)
        if ($version.FileVersion -ne $config.version -or $version.ProductName -ne 'Deadline Desk') { throw 'Downloaded EXE version or product mismatch' }
    }
    if (Test-Path -LiteralPath (Join-Path $job 'cancelled')) { throw 'Update cancelled' }
    [IO.File]::WriteAllText((Join-Path $job 'ready'), 'ready')
    $deadline = (Get-Date).AddSeconds(90)
    while (-not (Test-Path -LiteralPath (Join-Path $job 'commit'))) {
        if ((Test-Path -LiteralPath (Join-Path $job 'cancelled')) -or (Get-Date) -gt $deadline) { throw 'Update cancelled' }
        Start-Sleep -Milliseconds 100
    }
    if (Test-Path -LiteralPath (Join-Path $job 'cancelled')) { throw 'Update cancelled' }
    # Do not touch the running executable until Electron has exited and cleaned up its desktop menu.
    $deadline = (Get-Date).AddSeconds(90)
    while (Get-Process -Id $config.pid -ErrorAction SilentlyContinue) {
        if ((Get-Date) -gt $deadline) { throw 'Timed out waiting for app exit' }
        Start-Sleep -Milliseconds 250
    }
    # The portable launcher can hold the executable briefly after Electron exits.
    for ($attempt = 0; $attempt -lt 120; $attempt++) {
        try { Move-Item -LiteralPath $target -Destination $backup; $moved = $true; break }
        catch { if ($attempt -eq 119) { throw }; Start-Sleep -Milliseconds 500 }
    }
    Move-Item -LiteralPath $stage -Destination $target
    if ($config.version) { $env:DDL_UPDATE_JOB = $job }
    $started = Start-Process -FilePath $target -WorkingDirectory ([IO.Path]::GetDirectoryName($target)) -WindowStyle Hidden -PassThru
    if ($config.version) {
        $deadline = (Get-Date).AddSeconds(45)
        $acknowledged = $false
        while ((Get-Date) -lt $deadline) {
            $ackFile = Join-Path $job 'started.json'
            if (Test-Path -LiteralPath $ackFile) {
                try { $ack = Get-Content -LiteralPath $ackFile -Raw | ConvertFrom-Json } catch { $ack = $null }
                if ($ack -and $ack.version -eq $config.version -and (Get-Process -Id $ack.pid -ErrorAction SilentlyContinue)) { $acknowledged = $true; break }
            }
            if ($started.HasExited -and $started.ExitCode -ne 0) { break }
            Start-Sleep -Milliseconds 200
        }
        if (-not $acknowledged) {
            if (-not $started.HasExited) { & "$env:SystemRoot\System32\taskkill.exe" /PID $started.Id /T /F | Out-Null; $started.WaitForExit(5000) | Out-Null }
            throw 'New version did not acknowledge startup; restoring previous executable'
        }
    } else {
        Start-Sleep -Seconds 5
        if ($started.HasExited -and $started.ExitCode -ne 0) { throw 'New executable failed to start' }
    }
    Remove-Item Env:DDL_UPDATE_JOB -ErrorAction SilentlyContinue
    @{ok=$true; version=$config.version; backup=$backup} | ConvertTo-Json | Set-Content -LiteralPath $config.result -Encoding UTF8
    # Keep the old executable as a recovery copy; never touch task data.
    Remove-Item -LiteralPath $config.source -ErrorAction SilentlyContinue
} catch {
    Remove-Item Env:DDL_UPDATE_JOB -ErrorAction SilentlyContinue
    $reason = $_.Exception.Message
    [IO.File]::WriteAllText((Join-Path $job 'error.txt'), $reason)
    if ($moved -and (Test-Path -LiteralPath $backup)) {
        try {
            if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target }
            Move-Item -LiteralPath $backup -Destination $target
            Start-Process -FilePath $target -WorkingDirectory ([IO.Path]::GetDirectoryName($target)) -WindowStyle Hidden
        } catch { $reason += '; Restore failed. Previous executable: ' + $backup }
    }
    if ($config -and $config.result) { @{ok=$false; error=$reason; backup=$backup} | ConvertTo-Json | Set-Content -LiteralPath $config.result -Encoding UTF8 }
} finally {
    if ($stage -and (Test-Path -LiteralPath $stage)) { Remove-Item -LiteralPath $stage -ErrorAction SilentlyContinue }
}
