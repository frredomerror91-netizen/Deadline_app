/* Shared, side-effect-free validation and updates for main and floating task editors. */
(function(root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TaskEditor = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, () => {
  function fail(code) { const error = new Error(code); error.code = code; throw error; }
  function readRecords(storage) {
    const records = JSON.parse(storage.getItem('deadline-desk.tasks') || '[]');
    if (!Array.isArray(records)) fail('storage');
    return records;
  }
  function localValue(deadline) {
    const date = new Date(deadline);
    if (!Number.isFinite(date.getTime())) fail('deadline');
    return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  }
  function validate(input, editing = false, now = Date.now()) {
    const name = String(input.name || '').trim();
    const deadline = String(input.deadline || '');
    if (!name || name.length > 80) fail('name');
    const timestamp = new Date(deadline).getTime();
    if (!Number.isFinite(timestamp)) fail('deadline');
    if (!editing && timestamp <= now) fail('future');
    return { name, deadline };
  }
  function update(records, id, input, baseline) {
    const index = records.findIndex(task => task && String(task.id) === String(id));
    const task = records[index];
    if (!task || task.archivedAt || task.deletedAt) fail('missing');
    if (baseline && (task.name !== baseline.name || task.deadline !== baseline.deadline)) fail('conflict');
    // Name-only edits must not round seconds away or change the original timezone representation.
    const deadline = baseline && input.deadline === localValue(baseline.deadline) ? baseline.deadline : input.deadline;
    const patch = validate({ ...input, deadline }, true);
    const result = records.slice();
    result[index] = { ...task, ...patch };
    return result;
  }
  function errorText(error) {
    return ({ name: '请输入 1–80 个字符的任务名', deadline: '请填写有效的截止时间', future: '截止时间需要晚于当前时间',
      missing: '任务已删除或归档，无法编辑', conflict: '任务信息已在其他窗口更改，请关闭后重新编辑' })[error?.code] || '保存失败，请重试';
  }
  return { readRecords, localValue, validate, update, errorText };
});
