const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { groupByMonth, inFloatingRange, rangeDays } = require('./deadline-groups');

const source = name => fs.readFileSync(path.join(__dirname, name), 'utf8');

test('v2.1.1 keeps the floating range at seven days by default', () => {
  assert.equal(rangeDays(undefined), 7);
  const now = new Date('2026-09-25T12:00:00');
  assert.equal(inFloatingRange({ deadline:'2026-10-02T12:00:00', completed:false }, 7, now), true);
  assert.equal(inFloatingRange({ deadline:'2026-10-02T12:00:01', completed:false }, 7, now), false);
});

test('v2.1.1 source exposes folded floating months and animated month content', () => {
  const app = source('app.js');
  const html = source('index.html');
  const css = source('styles.css');
  assert.match(app, /kind === 'main' \? group\.key === nearestMonth : false/);
  assert.match(app, /content\.animate\(/);
  assert.match(html, /data-completion-period="year">今年/);
  assert.match(html, /id="periodPreviousLabel"/);
  assert.match(css, /\.completion-period-summary/);
  assert.match(css, /\.deadline-month-items \{ overflow: hidden; \}/);
});

test('month grouping remains local-calendar and preserves order for the main list', () => {
  const groups = groupByMonth([
    { id:'near', deadline:'2026-09-27T12:00:00' },
    { id:'later', deadline:'2026-10-01T12:00:00' }
  ]);
  assert.deepEqual(groups.map(group => [group.key, group.tasks.map(task => task.id)]), [
    ['2026-09', ['near']], ['2026-10', ['later']]
  ]);
});
