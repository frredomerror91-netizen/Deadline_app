// Isolated single-instance conflict contract; never signals a real running app.
const {app,dialog}=require('electron'),fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const profile=fs.mkdtempSync(path.join(app.getPath('temp'),'ddl-instance-'));app.setPath('userData',profile);process.env.DDL_TEST='1';
const scenario=process.argv.find(a=>a.startsWith('--scenario='))?.split('=')[1] || 'legacy';
if(scenario!=='legacy')fs.writeFileSync(path.join(profile,'running-instance.json'),JSON.stringify({version:scenario==='same'?require('./package.json').version:'2.0.8',pid:process.pid}));
app.requestSingleInstanceLock=()=>false;const messages=[];dialog.showMessageBox=async options=>{messages.push(options);return {response:0}};
app.on('before-quit',()=>{try{assert.equal(messages.length,scenario==='same'?0:1);if(messages.length){assert.match(messages[0].detail,/2\.0\.9/);assert.match(messages[0].detail,/退出旧版/);if(scenario==='older')assert.match(messages[0].detail,/2\.0\.8/)}console.log('PASS isolated instance conflict:',scenario)}catch(e){console.error(e);app.exit(1)}});
require('./main');setTimeout(()=>app.exit(1),10000).unref();
