const {app,BrowserWindow,screen}=require('electron');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData',fs.mkdtempSync(path.join(app.getPath('temp'),'ddl-v215-')));
process.env.DDL_TEST='1';
require('electron').net.fetch=async()=>new Response(JSON.stringify({tag_name:'v'+require('./package.json').version}));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR,'main.js') : './main');
setTimeout(()=>{console.error('v215 timeout');app.exit(1)},80000).unref();
app.whenReady().then(async()=>{try{
  const win=BrowserWindow.getAllWindows()[0], js=s=>win.webContents.executeJavaScript(s),errors=[];
  win.webContents.on('console-message',(_e,level,message)=>{if(level===3)errors.push(message)});
  while(win.webContents.isLoading())await delay(40);await delay(150);
  await js('settings.motion=true;syncEdgeMotion();setFloatingMode(true)');
  for(let n=0;n<5;n++){
    await js('document.getElementById("stripExpandButton").click()');await delay(320);
    assert.equal(await js('expanded'),true);assert.equal(win.getBounds().height,360);
    await js('document.getElementById("stripExpandButton").click()');await delay(320);
    assert.equal(await js('expanded'),false);assert.equal(win.getBounds().height,72);
  }
  await js('locked=false;renderLock()');
  const originalCursor=screen.getCursorScreenPoint,display=screen.getPrimaryDisplay(),a=display.workArea;
  let cursor={x:a.x+a.width/2,y:a.y+a.height/2};screen.getCursorScreenPoint=()=>cursor;
  try{
    win.setBounds({x:a.x+a.width-360,y:a.y+100,width:360,height:72});
    await delay(1250);
    assert.equal(await js('document.body.dataset.edge'),'right');assert.equal(win.getBounds().width,360);
    const b=win.getBounds();cursor={x:b.x+3,y:b.y+b.height/2};await delay(400);
    assert.equal(await js('document.body.dataset.edge'),'');
    assert.equal(win.getBounds().x,a.x+a.width-360);assert.equal(win.getBounds().width,360);
    await js('document.getElementById("stripExpandButton").click()');await delay(360);
    assert.equal(win.getBounds().height,360);
    await js('document.getElementById("stripExpandButton").click()');await delay(360);
    assert.equal(win.getBounds().height,72);
  }finally{screen.getCursorScreenPoint=originalCursor}
  for(let n=0;n<8;n++)await js('document.getElementById("stripExpandButton").click()');await delay(500);
  assert.equal(win.getBounds().height,72);
  assert.deepEqual(errors,[]);
  console.log('PASS v215 compact/expanded toggle and right-edge reveal');app.exit(0);
}catch(e){console.error(e);app.exit(1)}});








