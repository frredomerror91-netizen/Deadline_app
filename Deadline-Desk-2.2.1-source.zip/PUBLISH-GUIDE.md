# v2.2.1 GitHub 发布指南

目标仓库为 `frredomerror91-netizen/Deadline_app`，正式标签为 `v2.2.1`。本次用户已明确授权发布；实际发布状态以仓库 API 核验及本地回执为准。

## 发布附件

`dist/github-v2.2.1/` 只包含以下三个附件：

1. `Deadline-Desk-2.2.1.exe`：Windows x64 便携程序。
2. `Deadline-Desk-2.2.1.exe.sha256`：EXE 的 SHA-256。
3. `Deadline-Desk-2.2.1-source.zip`：该版源码、依赖清单、锁文件、测试、构建脚本和说明。

发布正文使用 `RELEASE-NOTES.md`，源码说明为 `SOURCE-README.md`。源包排除任务数据、用户配置、依赖目录、缓存、历史版本和打包输出。

## 发布步骤

1. 按源码说明完成测试、构建和 `pnpm run release`，核验 EXE 版本、包内源码、ZIP 逐文件摘要和三个附件。
2. 使用现有仓库 API 发布脚本，通过清单锁定文件摘要；仓库主分支只更新审核后的 README 和本版源码 ZIP。
3. 本次沿用现有 `v2.2.1` 正式 Release；先上传临时附件并校验，再替换同名附件，保留标签和版本号，不重复创建 Release。
4. 重新读取主分支、标签、发布正文及附件摘要；本轮按用户要求缩减验证，不重复下载整份 EXE。修订回执保存在项目 `.planning/v221-smooth-motion/`，不放入源码包。

需要手动执行时，可使用以下 GitHub CLI 命令；若该标签已存在，先核对现有发布，避免重复创建或替换：

~~~powershell
gh release create v2.2.1 dist/github-v2.2.1/Deadline-Desk-2.2.1.exe dist/github-v2.2.1/Deadline-Desk-2.2.1.exe.sha256 dist/github-v2.2.1/Deadline-Desk-2.2.1-source.zip --repo frredomerror91-netizen/Deadline_app --title "Deadline Desk v2.2.1" --notes-file RELEASE-NOTES.md
~~~

升级前从托盘彻底退出旧版，再运行新 EXE；保留原有用户数据目录。

## 同版本替换提示

已安装 v2.2.1 时须重新下载本次 EXE；现有更新器按语义版本比较，不推送相同版本修订。先从系统托盘退出运行中的旧程序，再替换文件，保留用户任务数据。
