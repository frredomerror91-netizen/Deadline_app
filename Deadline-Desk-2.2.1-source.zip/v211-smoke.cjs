const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v211-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch = async () => new Response(JSON.stringify({tag_name:'v'+require('./package.json').version}));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('v211 timeout'); app.exit(1); }, 60000).unref();
app.whenReady().then(async () => { try {
  const win = BrowserWindow.getAllWindows()[0];
  const js = code => win.webContents.executeJavaScript(code);
  while (win.webContents.isLoading()) await delay(50);
  await delay(120);
  await js(
    "(() => { const now = new Date(); const make=(id,days,completed=false)=>({id,name:id,deadline:toDateTimeLocal(new Date(now.getTime()+days*86400000)),completed, ...(completed ? {completedAt:toDateTimeLocal(new Date(now.getTime()-3600000))} : {})}); tasks=[make('near',2),make('later',6),make('far',60),make('done',-1,true)]; persistTasks(); renderTasks(); })()"
  );
  const mainGroups = await js("[...taskList.querySelectorAll(':scope > .deadline-month')].map(el=>({open:el.querySelector('button').getAttribute('aria-expanded'),count:el.querySelectorAll('.task-row').length}))");
  assert.ok(mainGroups.length >= 2, JSON.stringify(mainGroups));
  assert.equal(mainGroups[0].open, 'true');
  assert.ok(mainGroups.slice(1).every(group => group.open === 'false'), JSON.stringify(mainGroups));
  await js("setFloatingMode(true).then(() => setExpanded(true, false))");
  await delay(120);
  assert.equal(await js("document.getElementById('stripRangeLabel').textContent"), '7 日内截止清单');
  const floatingGroups = await js("[...document.querySelectorAll('#stripTasks > .deadline-month')].map(el=>el.querySelector('button').getAttribute('aria-expanded'))");
  assert.ok(floatingGroups.length >= 1, JSON.stringify(floatingGroups));
  assert.ok(floatingGroups.every(open => open === 'false'), JSON.stringify(floatingGroups));
  if (process.env.DDL_QA_DIR) { fs.mkdirSync(process.env.DDL_QA_DIR, {recursive:true}); fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v211-floating-default.png'), (await win.webContents.capturePage()).toPNG()); }
  const floatingAnimation = await js("(() => { const button=document.querySelector('#stripTasks .deadline-month-toggle'); button.click(); const content=button.nextElementSibling; return {open:button.getAttribute('aria-expanded'), animated:content.getAnimations().some(animation=>animation.effect.getKeyframes().some(frame=>String(frame.height||'').includes('px')))}; })()");
  assert.deepEqual(floatingAnimation, {open:'true', animated:true});
  await delay(260);
  assert.equal(await js("document.querySelector('#stripTasks .deadline-month-items').hidden"), false);
  await js("setFloatingMode(false).then(() => setView('completed-year', t('完成清单')))");
  await delay(80);
  const period = await js("({title:document.getElementById('periodLabel').textContent,range:document.getElementById('periodRange').textContent,previous:document.getElementById('periodPreviousLabel').textContent,next:document.getElementById('periodNextLabel').textContent,todayDisabled:document.getElementById('periodToday').disabled})");
  assert.ok(period.title.includes(String(new Date().getFullYear())), JSON.stringify(period));
  assert.ok(period.range.includes(String(new Date().getFullYear())), JSON.stringify(period));
  assert.equal(period.previous, '上一年');
  assert.equal(period.next, '下一年');
  assert.equal(period.todayDisabled, true);
  await js("document.querySelector('[data-completion-period=month]').click()");
  assert.equal(await js("currentView"), 'completed-month');
  assert.equal(await js("completionDate.value"), await js("completionDateValue()"));
  assert.equal(await js("document.getElementById('periodPreviousLabel').textContent"), '上个月');
  await js("document.getElementById('periodPrevious').click()");
  assert.equal(await js("document.getElementById('periodToday').disabled"), false);
  await js("document.getElementById('periodToday').click()");
  assert.equal(await js("document.getElementById('periodToday').disabled"), true);
  if (process.env.DDL_QA_DIR) {
    fs.mkdirSync(process.env.DDL_QA_DIR, {recursive:true});
    await js("setView('completed-month', t('完成清单'))"); await delay(150);
    fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v211-completed.png'), (await win.webContents.capturePage()).toPNG());
    await js("setFloatingMode(true).then(() => setExpanded(true, false))"); await delay(250);
    fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v211-floating.png'), (await win.webContents.capturePage()).toPNG());
  }
  console.log('PASS v211: floating seven-day default, folded month sections with animation, clearer completion navigation');
  app.exit(0);
} catch(error) { console.error(error); app.exit(1); } });
