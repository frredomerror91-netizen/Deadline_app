const { test } = require('node:test');
const assert = require('node:assert/strict');
const { validate, update, localValue, readRecords, errorText } = require('./task-editor');
const { createTranslator } = require('./i18n-core');
const pending = { id: 'pending', name: 'Original', deadline: '2026-10-10T18:00:27+08:00', completed: false, createdAt: '2026-09-29', extra: { keep: true } };
const baseline = task => ({ name: task.name, deadline: task.deadline });
test('editing changes only name and deadline, keeps identity/history, and is immutable', () => {
  const done = { ...pending, completed: true, completedAt: '2026-09-28T09:00:00Z' };
  const other = { ...pending, id: 'other' };
  const result = update([done, other], 'pending', { name: ' New title ', deadline: '2026-11-11T12:30' }, baseline(done));
  assert.deepEqual(result[0], { ...done, name: 'New title', deadline: '2026-11-11T12:30' });
  assert.equal(result[1], other);
  assert.equal(done.name, 'Original');
});
test('name-only edits preserve original seconds and timezone representation', () => {
  assert.equal(update([pending], 'pending', { name: 'Renamed', deadline: localValue(pending.deadline) }, baseline(pending))[0].deadline, pending.deadline);
});
test('past deadlines can be edited but new tasks must have a future deadline', () => {
  const input = { name: 'Overdue task', deadline: '2020-01-01T08:00' };
  assert.deepEqual(validate(input, true), input);
  assert.throws(() => validate(input, false), { code: 'future' });
});
test('empty, excessive names and invalid dates are rejected', () => {
  for (const name of ['', '   ', 'a'.repeat(81)]) assert.throws(() => validate({ name, deadline: pending.deadline }, true), { code: 'name' });
  for (const deadline of ['', 'not a date']) assert.throws(() => validate({ name: 'Task', deadline }, true), { code: 'deadline' });
});
test('editing missing/deleted/archived tasks never recreates them', () => {
  const patch = { name: 'Renamed', deadline: localValue(pending.deadline) };
  for (const records of [[], [{ ...pending, archivedAt: '2026-09-29' }], [{ ...pending, deletedAt: '2026-09-29' }]]) {
    assert.throws(() => update(records, 'pending', patch, baseline(pending)), { code: 'missing' });
  }
});
test('concurrent edits conflict but concurrent completion history is retained', () => {
  const patch = { name: 'Renamed', deadline: localValue(pending.deadline) };
  for (const change of [{ name: 'Another edit' }, { deadline: '2026-12-01T12:00' }]) {
    assert.throws(() => update([{ ...pending, ...change }], 'pending', patch, baseline(pending)), { code: 'conflict' });
  }
  const current = { ...pending, completed: true, completedAt: '2026-09-29T10:00:00Z' };
  const result = update([current], 'pending', patch, baseline(pending));
  assert.equal(result[0].completed, true);
  assert.equal(result[0].completedAt, current.completedAt);
});
test('invalid storage is rejected rather than replaced with an empty task list', () => {
  assert.throws(() => readRecords({ getItem: () => '{}' }), { code: 'storage' });
  assert.throws(() => readRecords({ getItem: () => '{' }));
  assert.deepEqual(readRecords({ getItem: () => null }), []);
});
test('edit messages are localized and user task text remains unchanged', () => {
  const en = createTranslator('en'), ja = createTranslator('ja');
  assert.equal(en('编辑任务'), 'Edit task');
  assert.equal(ja('编辑任务'), 'タスクを編集');
  assert.match(en(errorText({ code: 'missing' })), /deleted or archived/);
  const userTitle = '保存修改 <script>alert(1)</script>';
  assert.equal(en`${'编辑任务'} ${userTitle}`, '编辑任务 ' + userTitle);
});
