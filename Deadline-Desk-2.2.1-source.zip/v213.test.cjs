const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const lifecycle = require('./task-lifecycle');

const source = name => fs.readFileSync(path.join(__dirname, name), 'utf8');

test('completed tasks enter the completion list after a 24-hour grace period', () => {
  const now = Date.parse('2026-09-25T12:00:00Z');
  const recent = { completed: true, completedAt: '2026-09-25T11:00:00Z', deadline: '2026-09-26T12:00:00Z' };
  const ready = { completed: true, completedAt: '2026-09-24T11:59:59Z', deadline: '2026-09-26T12:00:00Z' };
  assert.equal(lifecycle.isCompletionReady(recent, now), false);
  assert.equal(lifecycle.isCompletionReady(ready, now), true);
  assert.equal(lifecycle.shouldShowInDeadlineLists(recent, now), true);
  assert.equal(lifecycle.shouldShowInDeadlineLists(ready, now), false);
  assert.equal(lifecycle.isCompletionReady({ completed: true }, now), false);
});

test('current source keeps unfinished tasks first and applies the completion grace rule everywhere', () => {
  const app = source('app.js');
  const mini = source('mini-window.js');
  const main = source('main.js');
  const html = source('index.html');
  const css = source('styles.css');
  const packageJson = JSON.parse(source('package.json'));
  assert.match(app, /compareDeadlineTasks/);
  assert.match(app, /shouldShowInDeadlineLists/);
  assert.match(app, /const leavesCurrentList = isCompletionView\(\) && !task\.completed/);
  assert.match(mini, /setBounds\(\{ x: next\.x, y: next\.y, width: size\.width, height: size\.height \}, false\)/);
  assert.doesNotMatch(mini, /setInterval\(dragStep, 16\)/);
  assert.match(main, /transparent: true/);
  assert.match(html, /option value="ja"/);
  assert.match(html, /task-lifecycle\.js/);
  assert.match(css, /quick-editor-page/);
  assert.match(css, /body\.quick-editor[\s\S]*border-radius: 18px/);
});



