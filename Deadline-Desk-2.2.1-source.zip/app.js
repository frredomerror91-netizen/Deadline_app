const t = window.t || ((strings, ...values) => typeof strings === 'string' ? strings : strings.reduce((acc, str, i) => acc + str + (values[i] ?? ''), ''));
const STORAGE_KEY = 'deadline-desk.tasks';
let locked = true;
const MODE_KEY = 'deadline-desk.floating';

const appShell = document.getElementById('appShell');
const taskList = document.getElementById('taskList');
const taskCount = document.getElementById('taskCount');
const taskArea = document.getElementById('taskArea');
const emptyAddButton = document.getElementById('emptyAddButton');
const modalBackdrop = document.getElementById('modalBackdrop');
const taskForm = document.getElementById('taskForm');
const taskNameInput = document.getElementById('taskName');
const taskDeadlineInput = document.getElementById('taskDeadline');
const formError = document.getElementById('formError');
const floatingToggle = document.getElementById('floatingToggle');
const floatingStrip = document.getElementById('floatingStrip');
const stripTasks = document.getElementById('stripTasks');
const lockButton = document.getElementById('stripLockButton');

floatingStrip.addEventListener('pointerdown', event => {
  if (event.button !== 0 || !event.target.closest('.strip-header') || event.target.closest('button, input, .completion-group') || floatingStrip.classList.contains('is-locked')) return;
  floatingStrip.setPointerCapture(event.pointerId);
  window.desktop?.miniDrag(true);
});
for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
  floatingStrip.addEventListener(type, () => window.desktop?.miniDrag(false));
}

const SETTINGS_KEY = 'deadline-desk.settings';
const defaults = { sort: 'asc', showCompleted: true, motion: true, highlightUrgent: true, retentionDays: 30, urgentHours: 48, distantHours: 120 };
let settings;
try { settings = { ...defaults, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') }; }
catch { settings = { ...defaults }; }
if (!Number.isFinite(settings.urgentHours) || settings.urgentHours < 0 || settings.urgentHours > 87600) settings.urgentHours = 48;
if (!Number.isFinite(settings.distantHours) || settings.distantHours < settings.urgentHours || settings.distantHours > 87600) settings.distantHours = Math.max(120, settings.urgentHours);
let completing = false;
let expanded = false;
let settingsDirty = false;
let settingsLoading = false, settingsSaving = false, settingsNativeReady = false;
let settingsEditRevision = 0;
let nativeSettingsSnapshot = { closeBehavior: 'ask', autoStart: false, autoStartSupported: false, layer: 'top', edgeCount: true, shortcut: '' };
let settingsLoadToken = 0;
const motionEnabled = () => DeskMotion.enabled(settings.motion);
function syncMotionState() {
  DeskMotion.sync(settings.motion);
}
function isCompletionReady(task, now = Date.now()) {
  return window.TaskLifecycle?.isCompletionReady(task, now) === true;
}
function shouldShowInDeadlineLists(task, now = Date.now()) {
  return window.TaskLifecycle?.shouldShowInDeadlineLists(task, now) === true;
}
function compareDeadlineTasks(first, second, ascending = true) {
  if (Boolean(first.completed) !== Boolean(second.completed)) return first.completed ? 1 : -1;
  const difference = new Date(first.deadline) - new Date(second.deadline);
  return ascending ? difference : -difference;
}
if (!Number.isInteger(settings.retentionDays) || settings.retentionDays < 1 || settings.retentionDays > 1825) settings.retentionDays = 30;
delete settings.floatingDays; // v2.1.2 removes the legacy day-range preference.
const monthExpansion = { main: new Map(), floating: new Map() };
let modalAnimation;
let tasks = readTasks();
let currentView = 'all';
let sortAscending = settings.sort !== 'desc';
syncMotionState();
const monthFilter = document.getElementById('monthFilter');
monthFilter.value = toDateTimeLocal(new Date()).slice(0, 7);
monthFilter.addEventListener('change', () => DeskMotion.change(taskList, () => renderTasks({ animate: false })));

function readTasks() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(saved) ? saved.filter((task) => task && task.name && Number.isFinite(new Date(task.deadline).getTime())) : [];
  } catch (error) {
    return [];
  }
}

function persistTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function formatDate(date, options = {}) {
  return new Intl.DateTimeFormat(window.deskLocale, { month: 'long', day: 'numeric', ...options }).format(date);
}

function formatShortDate(date) {
  return new Intl.DateTimeFormat(window.deskLocale, { month: 'numeric', day: 'numeric', weekday: 'short' }).format(date);
}

function startOfDay(date) {
  const result = new Date(date);
  result.setHours(0, 0, 0, 0);
  return result;
}

function isSameDay(first, second) {
  return startOfDay(first).getTime() === startOfDay(second).getTime();
}

function isCompletionView() { return currentView.startsWith('completed-'); }
function completionRange(period, value) {
  const start = startOfDay(new Date(value + 'T12:00:00'));
  if (period === 'year') start.setMonth(0, 1);
  if (period === 'month') start.setDate(1);
  if (period === 'week') start.setDate(start.getDate() - (start.getDay() + 6) % 7);
  const end = new Date(start);
  if (period === 'year') end.setFullYear(end.getFullYear()+1);
  else if (period === 'month') end.setMonth(end.getMonth()+1);
  else end.setDate(end.getDate() + (period === 'week' ? 7 : 1));
  return [start,end];
}
function completionMeta(task) {
  return task.completedAt && Number.isFinite(new Date(task.completedAt).getTime()) ? t('完成于 ') + new Date(task.completedAt).toLocaleString(window.deskLocale, {hour12:false}) : t('完成时间未记录');
}
function isDistant(task, now = Date.now()) { return !task.completed && new Date(task.deadline).getTime() - now > settings.distantHours * 60 * 60 * 1000; }
function isUrgent(task, now = Date.now()) { return settings.highlightUrgent !== false && !task.completed && new Date(task.deadline).getTime() - now <= settings.urgentHours * 60 * 60 * 1000; }
function isWarning(task, now = Date.now()) { return !task.completed && !isUrgent(task, now) && !isDistant(task, now); }
function toneClass(task, now = Date.now()) { return task.completed ? 'is-completed' : isUrgent(task, now) ? 'is-urgent' : isDistant(task, now) ? 'is-distant' : 'is-warning'; }
const completionDate = document.getElementById('completionDate');
function completionDateValue(date = new Date()) { return toDateTimeLocal(date).slice(0, 10); }
function completionTitle(period, start) {
  if (period === 'year') return new Intl.DateTimeFormat(window.deskLocale, { year: 'numeric' }).format(start);
  if (period === 'month') return new Intl.DateTimeFormat(window.deskLocale, { year: 'numeric', month: 'long' }).format(start);
  if (period === 'week') return t('本周') + ' · ' + new Intl.DateTimeFormat(window.deskLocale, { month: 'short', day: 'numeric' }).format(start);
  return new Intl.DateTimeFormat(window.deskLocale, { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' }).format(start);
}
function completionRangeText(start, last) {
  const formatter = new Intl.DateTimeFormat(window.deskLocale, { year: 'numeric', month: 'numeric', day: 'numeric' });
  const first = formatter.format(start), second = formatter.format(last);
  return first === second ? first : first + ' — ' + second;
}
function updatePeriodLabel() {
  const label = document.getElementById('periodLabel');
  const range = document.getElementById('periodRange');
  const previousLabel = document.getElementById('periodPreviousLabel');
  const nextLabel = document.getElementById('periodNextLabel');
  const todayButton = document.getElementById('periodToday');
  if (!isCompletionView() || currentView === 'completed-all') {
    label.textContent = ''; range.textContent = ''; return;
  }
  const period = currentView.slice(10), [start, end] = completionRange(period, completionDate.value);
  const last = new Date(end); last.setDate(last.getDate() - 1);
  const navigation = {
    year: [t('上一年'), t('下一年')],
    month: [t('上个月'), t('下个月')],
    week: [t('上一周'), t('下一周')],
    day: [t('前一天'), t('后一天')]
  }[period] || [t('上一期间'), t('下一期间')];
  label.textContent = completionTitle(period, start);
  range.textContent = completionRangeText(start, last);
  previousLabel.textContent = navigation[0];
  nextLabel.textContent = navigation[1];
  document.getElementById('periodPrevious').setAttribute('aria-label', navigation[0]);
  document.getElementById('periodNext').setAttribute('aria-label', navigation[1]);
  const [todayStart] = completionRange(period, completionDateValue());
  todayButton.disabled = start.getTime() === todayStart.getTime();
}
completionDate.value = completionDateValue();
completionDate.onchange = () => { if (!completionDate.value) completionDate.value = completionDateValue(); DeskMotion.change(taskList, () => { updatePeriodLabel(); renderTasks({ animate: false }); }); };
function shiftCompletionPeriod(direction) {
  const period = currentView.slice(10), [date] = completionRange(period, completionDate.value);
  if (period === 'year') date.setFullYear(date.getFullYear() + direction);
  else if (period === 'month') date.setMonth(date.getMonth() + direction);
  else date.setDate(date.getDate() + direction * (period === 'week' ? 7 : 1));
  completionDate.value = completionDateValue(date); completionDate.onchange();
}
document.getElementById('periodPrevious').onclick = () => shiftCompletionPeriod(-1);
document.getElementById('periodNext').onclick = () => shiftCompletionPeriod(1);
document.getElementById('periodToday').onclick = () => { completionDate.value = completionDateValue(); completionDate.onchange(); };
function getFilteredTasks() {
  const activeTasks = tasks.filter(task => !task.archivedAt);
  if (currentView === 'trash') return tasks.filter(task => task.archivedAt);
  const now = new Date();
  const today = startOfDay(now);
  if (isCompletionView()) return activeTasks.filter(task => {
    if (!isCompletionReady(task, now.getTime())) return false;
    if (currentView === 'completed-all') return true;
    const time = new Date(task.completedAt).getTime(), [start,end] = completionRange(currentView.slice(10), completionDate.value);
    return Number.isFinite(time) && time >= start && time < end;
  });
  const deadlineTasks = activeTasks.filter(task => shouldShowInDeadlineLists(task, now.getTime()));
  if (currentView === 'month') return deadlineTasks.filter(task => task.deadline.slice(0, 7) === monthFilter.value);
  if (currentView === 'today') return deadlineTasks.filter((task) => isSameDay(new Date(task.deadline), now));
  if (currentView === 'week') {
    const weekEnd = new Date(today);
    weekEnd.setDate(today.getDate() + 7);
    return deadlineTasks.filter((task) => new Date(task.deadline) >= today && new Date(task.deadline) < weekEnd);
  }
  return deadlineTasks.slice();
}

function sortedTasks(list = getFilteredTasks()) {
  return list.filter(task => isCompletionView() || currentView === 'trash' || settings.showCompleted || !task.completed).sort((first, second) => {
    if (currentView === 'trash') return new Date(second.archivedAt) - new Date(first.archivedAt);
    if (isCompletionView()) return (new Date(second.completedAt).getTime() || 0) - (new Date(first.completedAt).getTime() || 0);
    return compareDeadlineTasks(first, second, sortAscending);
  });
}

function taskStatus(date) {
  const now = new Date();
  const diff = date - now;
  if (diff < 0) return { label: t('已过期'), className: 'is-soon', meta: t('截止时间已过') };
  if (isSameDay(date, now)) return { label: t('今天'), className: 'is-today', meta: t('今天截止') };
  if (diff < 48 * 60 * 60 * 1000) return { label: t('即将截止'), className: 'is-soon', meta: t('不到两天') };
  return { label: t('待完成'), className: '', meta: t`${Math.ceil(diff / (24 * 60 * 60 * 1000))} 天后` };
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
}

function animateTaskRows(container) {
  if (!motionEnabled()) return;
  for (const row of container.querySelectorAll('[data-task-id]')) if (row.getClientRects().length) void DeskMotion.disclose(row, true, { from: 0 });
}
async function contractTask(id) {
  if (!motionEnabled()) return;
  const targets = new Set();
  for (const row of document.querySelectorAll('[data-task-id]')) {
    if (row.dataset.taskId !== String(id) || !row.getClientRects().length) continue;
    const group = row.closest('.deadline-month');
    const task = tasks.find(task => String(task.id) === String(id));
    const groupLeaves = group && group.querySelectorAll('[data-task-id]').length === 1 && (!task || task.archivedAt || task.deletedAt || DeadlineGroups.groupByMonth([task])[0]?.key !== group.dataset.month);
    targets.add(groupLeaves ? group : row);
  }
  await Promise.all([...targets].map(element => DeskMotion.disclose(element, false)));
}
async function renderTaskChange(id) {
  completing = true;
  try { await contractTask(id); }
  finally { completing = false; tasks = readTasks(); renderTasks(); }
}

function renderTasks({ animate = true } = {}) {
  if (completing) return;
  const previousLayout = DeskMotion.snapshot(taskList);
  purgeExpired();
  const sortButton = document.getElementById('sortButton');
  document.getElementById('sortLabel').textContent = t('截止：') + (sortAscending ? t('最近优先') : t('最远优先'));
  sortButton.title = t('点击切换为') + (sortAscending ? t('最远优先') : t('最近优先'));
  sortButton.setAttribute('aria-label', sortButton.textContent + '，' + sortButton.title);
  sortButton.hidden = isCompletionView() || currentView === 'trash';
  const visibleTasks = sortedTasks();
  taskCount.textContent = tasks.filter(task => shouldShowInDeadlineLists(task)).length;
  taskList.classList.toggle('completion-archive', isCompletionView());
  taskList.innerHTML = '';

  if (currentView === 'trash') {
    renderTrash(visibleTasks);
    emptyAddButton.style.display='none'; updateStats(); if (animate) DeskMotion.layout(taskList, previousLayout); renderFloatingTasks(animate); return;
  }
  if (!visibleTasks.length) {
    const emptyTitle = isCompletionView() ? t('这个期间还没有完成记录') : currentView === 'all' ? t('从一个任务开始吧') : currentView === 'today' ? t('今天没有截止任务') : currentView === 'month' ? t('本月没有截止任务') : t('本周没有截止任务');
    const emptySubtitle = isCompletionView() ? t('按实际完成时间归档，可切换日期或查看全部完成') : currentView === 'all' ? t('点击中央的加号，写下第一个截止时间') : t('去全部任务查看你的完整清单');
    taskList.innerHTML = t`<div class="empty-state"><button class="empty-plus" id="centerAddButton" type="button" aria-label="添加任务"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M12 4v16M4 12h16"/></svg></button><p>${emptyTitle}</p><span>${emptySubtitle}</span></div>`;
    emptyAddButton.style.display = currentView === 'all' ? 'inline-block' : 'none';
    if(isCompletionView()) document.getElementById('centerAddButton')?.remove();
    document.getElementById('centerAddButton')?.addEventListener('click', openModal);
  } else {
    emptyAddButton.style.display = 'none';
    visibleTasks.forEach((task, index) => {
      const date = new Date(task.deadline);
      const status = task.completed ? { label: t('已完成'), className: '', meta: completionMeta(task) } : taskStatus(date);
      const row = document.createElement('article');
      row.dataset.taskId = String(task.id);
      row.className = `task-row ${toneClass(task)}`;
      
      row.innerHTML = t`<span class="task-marker" aria-hidden="true"></span><div class="task-main"><p class="task-name" title="${escapeHtml(task.name)}"><span class="task-title-text">${escapeHtml(task.name)}</span>${editControl(task)}</p><span class="task-meta">${formatShortDate(date)} · ${date.toLocaleTimeString(window.deskLocale, { hour: '2-digit', minute: '2-digit' })} · ${status.meta}</span></div><span class="task-badge ${status.className}">${status.label}</span><span class="task-countdown${!task.completed && new Date(task.deadline) <= new Date() ? ' is-overdue' : ''}" data-countdown="${escapeHtml(task.id)}">${countdown(task)}</span><button class="task-delete" type="button" data-delete="${escapeHtml(task.id)}" aria-label="删除 ${escapeHtml(task.name)}" title="删除任务">×</button><input class="task-complete" type="checkbox" data-complete="${escapeHtml(task.id)}" aria-label="${task.completed ? t('标为未完成 ') : t('完成 ')}${escapeHtml(task.name)}" ${task.completed ? 'checked' : ''}>${isCompletionView() ? t`<button class="archive-button" type="button" data-archive="${escapeHtml(task.id)}">归档</button>` : ''}`;
      taskList.appendChild(row);
    });
    if (currentView === 'all') {
      const rows = new Map([...taskList.children].map(row => [row.dataset.taskId, row]));
      // Keep unfinished tasks ahead of completed tasks, then apply the selected deadline order.
      const orderedForDisplay = [...visibleTasks];
      const nearestMonth = DeadlineGroups.groupByMonth([...visibleTasks].sort((a,b) => new Date(a.deadline) - new Date(b.deadline)))[0]?.key;
      taskList.replaceChildren();
      DeadlineGroups.groupByMonth(orderedForDisplay).forEach((group, i) =>
        taskList.appendChild(createMonthSection(group, i, 'main', task => rows.get(String(task.id)), nearestMonth)));
    }
    taskList.querySelectorAll('[data-delete]').forEach((button) => button.addEventListener('click', () => removeTask(button.dataset.delete)));
  }

  taskList.querySelectorAll('[data-archive]').forEach(button=>button.onclick=()=>archiveTask(button.dataset.archive));
  bindCompletion(taskList);
  updateStats();
  if (animate) DeskMotion.layout(taskList, previousLayout);
  renderFloatingTasks(animate);
}

function updateStats() {
  document.getElementById('taskUpdated').textContent = t`${getFilteredTasks().length} 项任务`;
}

function countdown(task, now = Date.now()) {
  if (task.completed) return t('已完成');
  const diff = new Date(task.deadline).getTime() - now;
  const total = Math.floor(Math.abs(diff) / 60000);
  const duration = t`${total >= 1440 ? Math.floor(total / 1440) + t("天") : ""}${Math.floor(total % 1440 / 60)}小时${total % 60}分钟`;
  if (Math.abs(diff) < 60000) return diff > 0 ? t('不足1分钟截止') : t('已逾期不足1分钟');
  return (diff > 0 ? t('剩余 ') : t('已逾期 ')) + duration;
}
function completionControl(task) {
  return `<span class="completion-group"><span class="task-countdown${!task.completed && new Date(task.deadline) <= new Date() ? ' is-overdue' : ''}" data-countdown="${escapeHtml(task.id)}">${countdown(task)}</span><input class="task-complete" type="checkbox" data-complete="${escapeHtml(task.id)}" aria-label="${task.completed ? t('标为未完成 ') : t('完成 ')}${escapeHtml(task.name)}" ${task.completed ? 'checked' : ''}></span>`;
}
function bindCompletion(container) {
  container.querySelectorAll('[data-complete]').forEach(input => input.addEventListener('change', async () => {
    const task = tasks.find(task => String(task.id) === input.dataset.complete);
    if (!task || completing) { input.checked = Boolean(task?.completed); return; }
    const id = String(task.id), previous = { ...task };
    task.completed = input.checked;
    if (task.completed) task.completedAt = new Date().toISOString(); else delete task.completedAt;
    try { persistTasks(); }
    catch { delete task.completedAt; Object.assign(task, previous); input.checked = Boolean(task.completed); return; }
    document.querySelectorAll('[data-complete]').forEach(control => { control.disabled = true; if (control.dataset.complete === id) control.checked = task.completed; });
    await renderTaskChange(id);
    const replacement = [...container.querySelectorAll('[data-complete]')].find(control => control.dataset.complete === id) || container.querySelector('[data-complete]');
    replacement?.focus({ preventScroll: true });
  }));
}
function editControl(task) {
  return `<button type="button" class="task-edit" data-edit="${escapeHtml(task.id)}" aria-label="${t('编辑任务')} ${escapeHtml(task.name)}" title="${t('编辑任务')}"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m16 3 5 5-12 12H4v-5L16 3Z"/><path d="m14 5 5 5"/></svg></button>`;
}
// Delegation survives list rerenders and works for keyboard activation, too.
for (const container of [taskList, floatingStrip]) container.addEventListener('click', event => {
  const button = event.target.closest('[data-edit]');
  if (!button || completing) return;
  event.preventDefault(); event.stopPropagation(); openModal(button.dataset.edit);
});
function floatingRow(task, index, compact = false) {
  const date = new Date(task.deadline);
  const now = new Date();
  const yearPrefix = date.getFullYear() !== now.getFullYear() ? `${date.getFullYear()}/` : '';
  const timeFormatted = `${yearPrefix}${date.getMonth() + 1}/${date.getDate()} ${date.toLocaleTimeString(window.deskLocale, { hour: '2-digit', minute: '2-digit' })}`;
  return t`<div data-task-id="${escapeHtml(task.id)}" class="${compact ? 'preview-task' : 'strip-task'} ${toneClass(task)}${!task.completed && !isUrgent(task) && !isDistant(task) && index === 0 ? ' is-current' : ''}"><div class="strip-task-copy"><div class="strip-task-name" title="${escapeHtml(task.name)}"><span class="task-title-text">${escapeHtml(task.name)}</span>${editControl(task)}</div><div class="strip-task-time" title="${escapeHtml(date.toLocaleString(window.deskLocale))}">${t('截止 ')}${timeFormatted}</div></div>${completionControl(task)}</div>`;
}
function renderFloatingTasks(animate = false) {
  const previewLayout = DeskMotion.snapshot(document.getElementById('stripPreview'));
  const floatingLayout = DeskMotion.snapshot(stripTasks);
  // The floating list is a global deadline view: never narrow it to the current month.
  const ordered = tasks.filter(task => shouldShowInDeadlineLists(task)).sort((a, b) => compareDeadlineTasks(a, b, true));
  const unfinished = ordered.filter(task => !task.completed);
  const monthCaption = t('截止清单');
  document.getElementById('edgeBadge').textContent = unfinished.length > 999 ? '999+' : unfinished.length;
  document.getElementById('edgeBadge').title = unfinished.length + t(' 项待完成');
  document.getElementById('stripCount').textContent = unfinished.length + t(' 项待完成');
  document.getElementById('stripRangeLabel').textContent = monthCaption;
  const preview = document.getElementById('stripPreview');
  document.getElementById('miniTotal').textContent = unfinished.length;
  document.getElementById('miniTotal').setAttribute('aria-label', t('未完成 DDL 总数：') + unfinished.length);
  preview.innerHTML = unfinished.length ? unfinished.slice(0, 2).map((task, i) => floatingRow(task, i, true)).join('') : '<div class="preview-empty">' + (ordered.length ? t('暂无待办任务') : t('暂无截止任务')) + '</div>';
  const visible = ordered.filter(task => settings.showCompleted || !task.completed);
  stripTasks.innerHTML = '';
  if (!visible.length) stripTasks.innerHTML = t('<div class="strip-empty">暂无截止任务</div>');
  else DeadlineGroups.groupByMonth(visible).forEach((group, i) => stripTasks.appendChild(createMonthSection(group, i, 'floating', (task, position) => {
    const wrapper = document.createElement('div');
    wrapper.innerHTML = floatingRow(task, position);
    return wrapper.firstElementChild;
  })));
  bindCompletion(preview);
  bindCompletion(stripTasks);
  if (animate) {
    DeskMotion.layout(preview, previewLayout);
    DeskMotion.layout(stripTasks, floatingLayout);
  }
}
let detailsAnimation;
function setExpanded(value, animate = true, notify = true) {
  const details = document.getElementById('stripDetails');
  const opacity = detailsAnimation && !details.hidden ? getComputedStyle(details).opacity : (value ? '0' : '1');
  const transform = detailsAnimation && !details.hidden ? getComputedStyle(details).transform : (value ? 'translateY(-8px)' : 'none');
  detailsAnimation?.cancel();
  expanded = value;
  const moving = animate && motionEnabled() && appShell.classList.contains('is-floating');
  details.hidden = !expanded && !moving;
  details.inert = !expanded;
  floatingStrip.classList.toggle('is-expanded', expanded);
  const button = document.getElementById('stripExpandButton');
  button.setAttribute('aria-expanded', String(expanded));
  button.setAttribute('aria-label', expanded ? t('收起清单') : t('展开清单'));
  button.title = expanded ? t('收起清单') : t('展开清单');
  if (!button.querySelector('svg')) button.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>`;
  if (moving) {
    detailsAnimation = DeskMotion.play(details, [{ opacity, transform }, { opacity: value ? 1 : 0, transform: value ? 'none' : 'translateY(-8px)' }], {
      duration: value ? 300 : 190
    });
    if (value) animateTaskRows(stripTasks, 'floating', true);
  }
  if (notify) window.desktop?.setExpanded(expanded, moving);
  if (!window.desktop) details.hidden = !expanded;
}
window.desktop?.onExpandedSettled(value => { if (value === expanded) document.getElementById('stripDetails').hidden = !value; });
document.getElementById('stripExpandButton').addEventListener('click', () => setExpanded(!expanded));

let modalTransition = 0, editingTaskId = null, editBaseline = null, taskSaving = false;
function openModal(taskId) {
  // Add buttons pass a MouseEvent; only an explicit id means edit.
  taskId = typeof taskId === 'string' ? taskId : null;
  if (completing) return;
  const task = taskId ? readTasks().find(task => String(task.id) === taskId && !task.archivedAt && !task.deletedAt) : null;
  if (taskId && !task) { window.alert(t('任务已删除或归档，无法编辑')); return; }
  if (appShell.classList.contains('is-floating') && window.desktop) { window.desktop.openEditor(taskId || undefined); return; }
  editingTaskId = taskId;
  editBaseline = task ? { name: task.name, deadline: task.deadline } : null;
  taskSaving = false;
  taskForm.querySelector('[type="submit"]').disabled = false;
  document.getElementById('modalTitle').textContent = task ? t('编辑任务') : t('安排一个新任务');
  document.getElementById('taskModalKicker').textContent = task ? t('EDIT DEADLINE') : t('NEW DEADLINE');
  document.getElementById('taskModalSubtitle').textContent = task ? t('修改名称与截止时间，保留完成状态和记录。') : t('记录下来，心里就多一份从容。');
  document.getElementById('taskSubmitLabel').textContent = task ? t('保存修改') : t('保存任务');
  const token = ++modalTransition;
  modalAnimation?.cancel();
  modalBackdrop.classList.remove('is-closing');
  modalBackdrop.hidden = false;
  taskForm.reset();
  formError.textContent = '';
  const defaultDeadline = new Date();
  defaultDeadline.setDate(defaultDeadline.getDate() + 1);
  defaultDeadline.setHours(15, 0, 0, 0);
  taskNameInput.value = task ? task.name : '';
  taskDeadlineInput.value = task ? TaskEditor.localValue(task.deadline) : toDateTimeLocal(defaultDeadline);
  taskDeadlineInput.dispatchEvent(new Event('change', { bubbles: true }));
  if (motionEnabled()) {
    const panel = modalBackdrop.querySelector('.task-modal');
    modalAnimation = DeskMotion.enter(panel, { duration: 280 });
    DeskMotion.play(modalBackdrop, [{ opacity: 0 }, { opacity: 1 }], { duration: 220 });
  }
  taskNameInput.focus();
}

function finishCloseModal(token) {
  if (token !== modalTransition) return;
  modalAnimation?.cancel();
  modalAnimation = null;
  modalBackdrop.classList.remove('is-closing');
  modalBackdrop.hidden = true;
  DeskMotion.stop(modalBackdrop);
  editingTaskId = null; editBaseline = null; taskSaving = false;
  taskForm.querySelector('[type="submit"]').disabled = false;
  taskForm.reset();
  formError.textContent = '';
}
function closeModal() {
  if (modalBackdrop.hidden) return Promise.resolve();
  if (modalBackdrop.classList.contains('is-closing')) return DeskMotion.finished(modalAnimation);
  const token = ++modalTransition;
  if (!motionEnabled()) { finishCloseModal(token); return Promise.resolve(); }
  modalBackdrop.classList.add('is-closing');
  const panel = modalBackdrop.querySelector('.task-modal');
  modalAnimation = DeskMotion.leave(panel);
  DeskMotion.play(modalBackdrop, [{ opacity: 1 }, { opacity: 0 }], { duration: 190, fill: 'forwards' });
  return DeskMotion.finished(modalAnimation).then(() => finishCloseModal(token));
}

function toDateTimeLocal(date) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60 * 1000).toISOString().slice(0, 16);
}

async function removeTask(id) {
  if (completing) return;
  let task = tasks.find(task => String(task.id) === String(id));
  if (!task || task.archivedAt) return;
  if (!await window.DeskDialog.confirm({ title: t('删除任务'), message: t('确认删除这个任务？删除后将移入回收站，可在保留期内还原。'), taskName: task.name, confirmLabel: t('移入回收站') })) return;
  tasks = readTasks();
  task = tasks.find(task => String(task.id) === String(id));
  if (!task || task.archivedAt || completing) return;
  const previous = {...task};
  task.deletedAt = task.archivedAt = new Date().toISOString();
  try { persistTasks(); } catch { delete task.deletedAt; delete task.archivedAt; Object.assign(task, previous); window.alert(t('删除失败，请重试。')); return; }
  await renderTaskChange(id);
}

function setView(view, label) {
  const content = document.getElementById('content');
  const previous = document.getElementById('settingsPage').hidden ? content : document.getElementById('settingsPage');
  DeskMotion.change(previous, content, () => applyView(view, label));
}
function applyView(view, label) {
  window.closeSettingsSelects?.();
  document.getElementById('settingsPage').hidden = true;
  document.getElementById('content').hidden = false;
  document.getElementById('settingsButton').classList.remove('is-active');
  currentView = view;
  document.getElementById('completionTabs').hidden = !isCompletionView();
  document.getElementById('trashControls').hidden = view !== 'trash';
  document.getElementById('addButton').hidden = isCompletionView() || view === 'trash';
  document.querySelectorAll('[data-completion-period]').forEach(button=>button.setAttribute('aria-pressed', String(view === 'completed-'+button.dataset.completionPeriod)));
  if(view==='trash') syncRetention();
  monthFilter.hidden = view !== 'month';
  document.getElementById('completionPeriod').hidden = !isCompletionView() || view === 'completed-all';
  updatePeriodLabel();
  document.querySelectorAll('.nav-item, .workspace-row').forEach((item) => item.classList.toggle('is-active', item.dataset.view === (isCompletionView() ? 'completed-all' : view)));
  document.getElementById('viewHeading').textContent = label;
  document.getElementById('listHeading').textContent = view === 'all' ? t('总清单') : label;
  renderTasks({ animate: false });
}

let modeTransition = 0, modeAnimation;
async function setFloatingMode(enabled) {
  const token = ++modeTransition;
  const changed = enabled !== appShell.classList.contains('is-floating');
  const moving = (changed || modeAnimation?.playState === 'running') && document.readyState !== 'loading' && motionEnabled();
  if (moving) {
    modeAnimation = DeskMotion.leave(appShell, { duration: 140 });
    await DeskMotion.finished(modeAnimation);
    if (token !== modeTransition) return;
  } else DeskMotion.stop(appShell);
  if (enabled) { locked = true; if (document.readyState !== 'loading') renderLock(); }
  setExpanded(false, false);
  appShell.classList.remove('is-restoring');
  appShell.classList.toggle('is-floating', enabled);
  floatingToggle.classList.toggle('is-on', enabled);
  floatingToggle.setAttribute('aria-pressed', String(enabled));
  localStorage.setItem(MODE_KEY, enabled ? '1' : '0');
  await window.desktop?.setFloatingMode(enabled);
  if (token !== modeTransition) return;
  DeskMotion.stop(appShell);
  if (moving) modeAnimation = DeskMotion.enter(appShell, { duration: 260 });
  if (!enabled) document.getElementById(document.getElementById('settingsPage').hidden ? 'addButton' : 'settingsClose').focus();
}

document.getElementById('addButton').addEventListener('click', openModal);
emptyAddButton.addEventListener('click', openModal);
document.getElementById('stripAddButton').addEventListener('click', openModal);
document.getElementById('stripCloseButton').addEventListener('click', () => setFloatingMode(false));
document.getElementById('modalClose').addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', (event) => { if (event.target === modalBackdrop) closeModal(); });
document.addEventListener('keydown', (event) => { if (!event.defaultPrevented && event.key === 'Escape' && !modalBackdrop.hidden) closeModal(); });
floatingToggle.addEventListener('click', () => setFloatingMode(!appShell.classList.contains('is-floating')));
document.getElementById('sortButton').addEventListener('click', () => { sortAscending = !sortAscending; renderTasks(); });
document.querySelectorAll('[data-view]').forEach((item) => item.addEventListener('click', () => setView(item.dataset.view, item.querySelector('span:nth-child(2)')?.textContent || t('我的清单'))));

taskForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (taskSaving || modalBackdrop.hidden) return;
  const wasEditing = editingTaskId !== null, savedId = editingTaskId;
  const input = { name: taskNameInput.value, deadline: taskDeadlineInput.value };
  try {
    // Merge only editable fields into the latest stored task; never recreate deleted/archived tasks.
    const records = TaskEditor.readRecords(localStorage);
    const next = wasEditing ? TaskEditor.update(records, editingTaskId, input, editBaseline)
      : [...records, { id: crypto.randomUUID(), ...TaskEditor.validate(input) }];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    tasks = readTasks();
    taskSaving = true;
    taskForm.querySelector('[type="submit"]').disabled = true;
    await closeModal();
    tasks = readTasks();
    if (wasEditing) await renderTaskChange(savedId);
    else if (currentView === 'all') renderTasks();
    else { applyView('all', t('总清单')); void DeskMotion.disclose(taskList, true, { from: 0 }); }
  } catch (error) { formError.textContent = t(TaskEditor.errorText(error)); }
});

document.getElementById('todayLabel').textContent = `${formatDate(new Date(), { month: 'long', day: 'numeric', weekday: 'long' })}`;
setFloatingMode(localStorage.getItem(MODE_KEY) === '1');
renderTasks();
document.getElementById('windowMinimize').addEventListener('click', () => window.desktop?.windowAction('minimize'));
document.getElementById('windowClose').addEventListener('click', () => window.desktop?.windowAction('close'));
setInterval(() => {
  // Update labels in place: never interrupt focus, dragging or a completion animation.
  if (document.hidden || completing) return;
  const byId = new Map(tasks.map(task => [String(task.id), task]));
  const now = Date.now();
  document.querySelectorAll('[data-countdown]').forEach(label => {
    const task = byId.get(label.dataset.countdown);
    if (task) {
      const text = countdown(task, now);
      if (label.textContent !== text) label.textContent = text;
      const row = label.closest('[data-task-id]');
      if (row) {
        // Recompute the complete tone on every tick so an unfinished task can never retain the completed green class.
        row.classList.remove('is-urgent', 'is-warning', 'is-distant', 'is-completed');
        row.classList.add(toneClass(task, now));
      }
      label.classList.toggle('is-overdue', !task.completed && new Date(task.deadline) <= new Date());
    }
  });
}, 1000);
setInterval(() => { if (!document.hidden && !completing && !document.querySelector('.date-picker[open]') && modalBackdrop.hidden) renderTasks({ animate: false }); }, 60000);

function renderLock() {
  floatingStrip.classList.toggle('is-locked', locked);
  lockButton.setAttribute('aria-pressed', String(locked));
  lockButton.title = locked ? t('解锁位置并启用贴边隐藏') : t('锁定位置并关闭贴边隐藏');
  lockButton.setAttribute('aria-label', lockButton.title);
  lockButton.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="${locked ? 'M8 10V6a4 4 0 0 1 8 0v4' : 'M8 10V6a4 4 0 0 1 8 0'}"/><path d="M12 14v3"/></svg>`;
  window.desktop?.setLocked(locked);
}
lockButton.onclick = () => { locked = !locked; localStorage.setItem('deadline-desk.locked', locked ? '1' : '0'); renderLock(); DeskMotion.play(lockButton.querySelector('svg'), [{ opacity: .45, transform: 'scale(.85)' }, { opacity: 1, transform: 'none' }], { duration: 180 }); };
renderLock();
async function refreshSavedTasks() {
  if (completing || taskSaving) return;
  const next = readTasks();
  // Storage and IPC can announce the same save; retain the current transition.
  if (JSON.stringify(next) === JSON.stringify(tasks)) return;
  const changed = tasks.filter(task => {
    const updated = next.find(value => String(value.id) === String(task.id));
    return !updated || updated.name !== task.name || updated.deadline !== task.deadline || updated.archivedAt !== task.archivedAt;
  });
  tasks = next;
  if (changed.length) {
    completing = true;
    try { await Promise.all(changed.map(task => contractTask(task.id))); }
    finally { completing = false; tasks = readTasks(); }
  }
  renderTasks();
}
window.desktop?.onTasksChanged(refreshSavedTasks);
window.addEventListener('storage', event => { if (event.key === STORAGE_KEY) refreshSavedTasks(); });

const settingsPage = document.getElementById('settingsPage');
const settingsSaveButton = document.getElementById('saveSettings');
const settingsSaveStatus = document.getElementById('settingsSaveStatus');
function markSettingsDirty() {
  settingsEditRevision += 1;
  settingsDirty = true;
  syncSettingsSaveControl();
  settingsSaveStatus.textContent = t('有未保存的设置更改');
  settingsSaveStatus.classList.add('is-dirty');
}
function markSettingsClean(message = '') {
  settingsDirty = false;
  syncSettingsSaveControl();
  settingsSaveStatus.textContent = message;
  settingsSaveStatus.classList.remove('is-dirty');
}
function syncSettingsSaveControl() {
  settingsSaveButton.disabled = settingsLoading || settingsSaving || !settingsNativeReady;
}
function setNativeSettingsDisabled(disabled) {
  for (const id of ['settingCloseBehavior', 'settingAutoStart', 'settingLayer', 'settingEdgeCount', 'settingShortcut', 'clearShortcut']) {
    document.getElementById(id).disabled = disabled || (id === 'settingAutoStart' && !nativeSettingsSnapshot.autoStartSupported);
  }
  window.refreshSettingsSelects?.();
}
async function loadNativeSettings(token) {
  settingsLoading = true;
  settingsNativeReady = false;
  setNativeSettingsDisabled(true);
  syncSettingsSaveControl();
  settingsSaveStatus.textContent = t('正在读取设置…');
  try {
    const [closeBehavior, autoStart, floating] = await Promise.all([
      window.desktop?.getCloseBehavior(), window.desktop?.getAutoStart(), window.desktop?.getFloatingSettings()
    ]);
    if (token !== settingsLoadToken) return;
    nativeSettingsSnapshot = {
      closeBehavior: closeBehavior || 'ask',
      autoStart: Boolean(autoStart?.enabled),
      autoStartSupported: autoStart?.supported !== false,
      layer: floating?.layer || 'top',
      edgeCount: floating?.edgeCount !== false,
      shortcut: floating?.shortcut || ''
    };
    document.getElementById('settingCloseBehavior').value = nativeSettingsSnapshot.closeBehavior;
    document.getElementById('settingAutoStart').checked = nativeSettingsSnapshot.autoStart;
    document.getElementById('settingAutoStart').disabled = !nativeSettingsSnapshot.autoStartSupported;
    document.getElementById('settingLayer').value = nativeSettingsSnapshot.layer;
    document.getElementById('settingEdgeCount').checked = nativeSettingsSnapshot.edgeCount;
    document.getElementById('settingShortcut').value = nativeSettingsSnapshot.shortcut;
    settingsNativeReady = true;
    if (!settingsDirty) settingsSaveStatus.textContent = '';
  } catch {
    if (token === settingsLoadToken) settingsSaveStatus.textContent = t('读取设置失败，请重试');
  } finally {
    if (token === settingsLoadToken) {
      settingsLoading = false;
      setNativeSettingsDisabled(!settingsNativeReady);
      syncSettingsSaveControl();
    }
  }
}
document.getElementById('settingsButton').addEventListener('click', () => {
  if (settingsSaving || !settingsPage.hidden) return;
  document.getElementById('settingTheme').value = document.documentElement.dataset.theme;
  document.getElementById('settingSort').value = settings.sort;
  document.getElementById('settingCompleted').checked = settings.showCompleted;
  document.getElementById('settingMotion').checked = settings.motion;
  document.getElementById('settingUrgent').checked = settings.highlightUrgent;
  document.getElementById('settingUrgentHours').value = settings.urgentHours;
  document.getElementById('settingDistantHours').value = settings.distantHours;
  settingsSaveStatus.textContent = '';
  settingsSaveStatus.classList.remove('is-dirty');
  settingsDirty = false;
  const token = ++settingsLoadToken;
  void loadNativeSettings(token);
  DeskMotion.change(document.getElementById('content'), settingsPage, () => {
  document.getElementById('content').hidden = true;
  settingsPage.hidden = false;
  document.querySelectorAll('[data-view]').forEach(item => item.classList.remove('is-active'));
  document.getElementById('settingsButton').classList.add('is-active');
  document.getElementById('viewHeading').textContent = t('设置');
  document.getElementById('settingsClose').focus();
  window.refreshSettingsSelects?.();
  });
});
document.getElementById('settingsClose').onclick = () => {
  const nav = document.querySelector(`[data-view="${isCompletionView() ? 'completed-all' : currentView}"]`);
  setView(currentView, isCompletionView() ? t('已完成') : nav.querySelector('span:nth-child(2)').textContent); nav.focus();
};
settingsPage.addEventListener('change', event => {
  if (event.target.closest('[data-settings-panel]')) markSettingsDirty();
});

const autoStartCheckbox = document.getElementById('settingAutoStart');
async function refreshAutoStart() {
  const status = document.getElementById('autoStartStatus');
  try {
    const state = await window.desktop.getAutoStart();
    if (settingsLoading || settingsSaving) return;
    autoStartCheckbox.checked = state.enabled;
    autoStartCheckbox.disabled = !state.supported;
    status.textContent = state.supported ? '' : t('开机自启动仅支持打包后的 Windows 程序');
  } catch { autoStartCheckbox.disabled = true; status.textContent = t('读取开机自启动设置失败'); }
}
void refreshAutoStart();
// v2.1.2: the floating window follows the current calendar month automatically.
window.desktop?.onMiniResized(value => setExpanded(value, false, false));
const icon = path => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
const icons = {
  windowMinimize: '<path d="M5 12h14"/>', windowClose: '<path d="m6 6 12 12M18 6 6 18"/>',
  stripExitButton: '<path d="M12 3v9M7 5.5a8 8 0 1 0 10 0"/>',
  stripAddButton: '<path d="M12 5v14M5 12h14"/>',
  stripCloseButton: '<path d="M14 4h6v6M20 4 10 14M10 4H4v16h16v-6"/>',
  modalClose: '<path d="m6 6 12 12M18 6 6 18"/>'
};
Object.entries(icons).forEach(([id, path]) => document.getElementById(id).innerHTML = icon(path));
const maximizeButton = document.getElementById('windowMaximize');
function renderMaximized(value) {
  maximizeButton.innerHTML = icon(value ? '<path d="M8 8V4h12v12h-4"/><rect x="4" y="8" width="12" height="12" rx="1"/>' : '<rect x="5" y="5" width="14" height="14" rx="1"/>');
  maximizeButton.title = value ? t('还原窗口') : t('最大化');
  maximizeButton.setAttribute('aria-label', maximizeButton.title);
}
renderMaximized(false);
let nativeWindowStateReady = false;
function animateWindowResize(maximizedState) {
  if (!motionEnabled() || !nativeWindowStateReady) return;
  appShell.animate(
    maximizedState
      ? [{ opacity: .76, transform: 'scale(.975)' }, { opacity: 1, transform: 'none' }]
      : [{ opacity: .76, transform: 'scale(1.018)' }, { opacity: 1, transform: 'none' }],
    { duration: 220, easing: 'cubic-bezier(.2,.7,.2,1)' }
  );
}
window.desktop?.onMaximized(value => { renderMaximized(value); animateWindowResize(value); nativeWindowStateReady = true; });
maximizeButton.onclick = () => window.desktop?.windowAction('maximize');
document.getElementById('stripExitButton').onclick = () => window.desktop?.windowAction('close');
for (const edge of ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw']) {
  const handle = document.createElement('div');
  handle.className = 'resize-edge edge-' + edge;
  handle.setAttribute('aria-hidden', 'true');
  floatingStrip.append(handle);
  handle.addEventListener('pointerdown', event => {
    if (event.button !== 0 || locked) return;
    event.preventDefault(); event.stopPropagation();
    handle.setPointerCapture(event.pointerId);
    window.desktop?.miniResize(edge);
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) handle.addEventListener(type, event => {
    event.stopPropagation(); window.desktop?.miniResize(null);
  });
}

// Native preferences are shared by the context menu and settings pages.
const settingsPanels = [...document.querySelectorAll('[data-settings-panel]')];
const settingsPanelHost = document.createElement('div'); settingsPanelHost.className = 'settings-panels';
settingsPanels[0].before(settingsPanelHost); settingsPanelHost.append(...settingsPanels);
let settingsTabTransition = 0;
function selectSettingsTab(name) {
  window.closeSettingsSelects?.();
  const next = settingsPanels.find(panel => panel.dataset.settingsPanel === name);
  const previous = settingsPanels.find(panel => !panel.hidden);
  if (!next || next === previous) return;
  const token = ++settingsTabTransition, height = settingsPanelHost.getBoundingClientRect().height;
  DeskMotion.stop(settingsPanelHost);
  DeskMotion.change(previous, next, () => {
    settingsPanels.forEach(panel => panel.hidden = panel !== next);
    document.querySelectorAll('[data-settings-tab]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.settingsTab === name)));
  });
  const target = next.getBoundingClientRect().height;
  settingsPanelHost.style.overflow = 'hidden';
  const resize = DeskMotion.play(settingsPanelHost, [{ height: height + 'px' }, { height: target + 'px' }], { duration: 280 });
  void DeskMotion.finished(resize).then(() => { if (token === settingsTabTransition) { DeskMotion.stop(settingsPanelHost); settingsPanelHost.style.removeProperty('overflow'); } });
}
document.querySelectorAll('[data-settings-tab]').forEach(button => button.onclick = () => selectSettingsTab(button.dataset.settingsTab));
const shortcutInput = document.getElementById('settingShortcut');
function showFloatingSettings(value) {
  if (!value) return;
  document.getElementById('settingLayer').value = value.layer;
  document.getElementById('settingEdgeCount').checked = value.edgeCount !== false;
  shortcutInput.value = value.shortcut || '';
  window.refreshSettingsSelects?.();
  document.getElementById('floatingSettingsStatus').textContent = value.error || '';
}
async function saveFloatingSettings(patch) {
  try { showFloatingSettings(await window.desktop?.saveFloatingSettings(patch)); }
  catch { document.getElementById('floatingSettingsStatus').textContent = t('设置保存失败，请重试。'); }
}
window.desktop?.getFloatingSettings().then(showFloatingSettings);
window.desktop?.onFloatingSettings(showFloatingSettings);
document.getElementById('settingLayer').onchange = () => markSettingsDirty();
document.getElementById('clearShortcut').onclick = () => { document.getElementById('settingShortcut').value = ''; markSettingsDirty(); };
shortcutInput.onkeydown = event => {
  if (event.key === 'Tab') return;
  event.preventDefault(); event.stopPropagation();
  if (event.key === 'Escape') { shortcutInput.blur(); return; }
  if (['Control','Alt','Shift','Meta'].includes(event.key) || event.repeat) return;
  const modifiers = [event.ctrlKey && 'Ctrl', event.altKey && 'Alt', event.shiftKey && 'Shift'].filter(Boolean);
  let key = event.code.replace(/^Key/, '').replace(/^Digit/, '');
  if (event.metaKey || !modifiers.length || !/^([A-Z0-9]|F([1-9]|1[0-9]|2[0-4]))$/.test(key)) {
    document.getElementById('floatingSettingsStatus').textContent = t('请使用 Ctrl、Alt 或 Shift 加字母、数字或功能键。'); return;
  }
  shortcutInput.value = [...modifiers,key].join('+');
  markSettingsDirty();
};
window.desktop?.onToggleFloating(() => {
  document.querySelector('.date-picker[open]')?.close(); closeModal();
  setFloatingMode(!appShell.classList.contains('is-floating'));
});
window.desktop?.onShowFloating(() => {
  document.querySelector('.date-picker[open]')?.close(); closeModal();
  setFloatingMode(true);
});
window.desktop?.onOpenFloatingSettings(() => {
  setFloatingMode(false); document.getElementById('settingsButton').click(); selectSettingsTab('floating');
});

document.getElementById('settingEdgeCount').onchange = () => markSettingsDirty();
window.desktop?.onEdgeState(value => {
  document.body.dataset.edge = value.edge || '';
  document.getElementById('edgeBadge').hidden = !value.edge || !value.count;
});
const syncEdgeMotion = () => { syncMotionState(); window.desktop?.setEdgeMotion(motionEnabled()); };
syncEdgeMotion();
document.getElementById('settingMotion').addEventListener('change', markSettingsDirty);
matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', syncEdgeMotion);

// Archive timestamps share the task store, so restoring retains completion history.
function purgeExpired(now = Date.now()) {
  const kept = tasks.filter(task => {
    const archived = task.archivedAt && new Date(task.archivedAt).getTime();
    return !Number.isFinite(archived) || now < archived + settings.retentionDays*86400000;
  });
  if(kept.length===tasks.length) return;
  const previous=tasks; tasks=kept;
  try { persistTasks(); } catch { tasks=previous; document.getElementById('retentionStatus').textContent=t('自动清理保存失败，请检查磁盘空间后重试。'); }
}
async function archiveTask(id) {
  if(completing) return;
  const task=tasks.find(task=>String(task.id)===id);
  if(!task?.completed || task.archivedAt) return;
  task.archivedAt=new Date().toISOString();
  try { persistTasks(); } catch { delete task.archivedAt; window.alert(t('归档保存失败，请重试。')); return; }
  await renderTaskChange(id);
}
async function restoreArchived(id) {
  if (completing) return;
  const task=tasks.find(task=>String(task.id)===id);
  if(!task?.archivedAt) return;
  const archivedAt=task.archivedAt, deletedAt=task.deletedAt; delete task.archivedAt; delete task.deletedAt;
  try { persistTasks(); } catch { task.archivedAt=archivedAt; if (deletedAt) task.deletedAt=deletedAt; window.alert(t('还原保存失败，请重试。')); return; }
  await renderTaskChange(id);
}
async function deleteArchived(id) {
  if (completing) return;
  const record = tasks.find(task => String(task.id) === String(id) && task.archivedAt);
  if (!record || !await window.DeskDialog.confirm({ title: t('永久删除'), message: t('永久删除这条回收站记录？此操作无法撤销。'), taskName: record.name, confirmLabel: t('永久删除') })) return;
  tasks = readTasks();
  const previous=tasks; tasks=tasks.filter(task=>String(task.id)!==id || !task.archivedAt);
  try { persistTasks(); } catch { tasks=previous; window.alert(t('删除失败，请重试。')); return; }
  await renderTaskChange(id);
}
function renderTrash(records) {
  if(!records.length) { taskList.innerHTML=t('<div class="empty-state"><p>回收站为空</p><span>在已完成中点击“归档”，记录会移到这里。</span></div>'); return; }
  let previousMonth='';
  for(const task of records) {
    const date=new Date(task.archivedAt), valid=Number.isFinite(date.getTime());
    const month=valid?date.getFullYear()+t('年')+(date.getMonth()+1)+t('月'):t('归档时间未记录');
    if(month!==previousMonth) { const heading=document.createElement('h3');heading.className='trash-month';heading.textContent=month;taskList.append(heading);previousMonth=month; }
    const row=document.createElement('article'); row.className='trash-row' + (task.deletedAt ? ' is-deleted' : ''); row.dataset.taskId=task.id;
    const expiry=valid?new Date(date.getTime()+settings.retentionDays*86400000).toLocaleString(window.deskLocale,{hour12:false}):t('待核实');
    row.innerHTML='<div class="task-main"><p class="task-name">'+escapeHtml(task.name)+'</p><div class="task-meta">'+escapeHtml(task.deletedAt ? t('已删除') + ' · ' + (task.completed ? completionMeta(task) : t('删除前未完成')) : t('已归档') + ' · ' + completionMeta(task))+'</div><div class="task-meta">'+(task.deletedAt ? t('删除：') : t('归档：'))+(valid?date.toLocaleString(window.deskLocale,{hour12:false}):t('未知'))+t(' · 自动删除：')+expiry+t('</div></div><div class="trash-actions"><button type="button" data-restore>还原</button><button type="button" data-purge>永久删除</button></div>');
    row.querySelector('[data-restore]').onclick=()=>restoreArchived(String(task.id));
    row.querySelector('[data-purge]').onclick=()=>deleteArchived(String(task.id));taskList.append(row);
  }
}
function syncRetention() {
  const days=settings.retentionDays, preset=[7,30,90].includes(days);
  document.getElementById('trashRetention').value=preset?String(days):'custom';
  document.getElementById('customRetention').value=days;
  document.getElementById('customRetentionLabel').hidden=preset;
}
document.getElementById('trashRetention').onchange=event=>{ void DeskMotion.disclose(document.getElementById('customRetentionLabel'), event.target.value==='custom'); };
document.getElementById('saveRetention').onclick=async()=>{
  const preset=document.getElementById('trashRetention').value;
  const raw=preset==='custom'?document.getElementById('customRetention').value:preset;
  const days=Number(raw), status=document.getElementById('retentionStatus');
  if(!/^\d+$/.test(raw) || !Number.isInteger(days) || days<1 || days>1825) { status.textContent=t('请输入 1–1825 的整数天数（最长 5 年）。'); return; }
  const expires=tasks.filter(task=>task.archivedAt && new Date(task.archivedAt).getTime()+days*86400000<=Date.now()).length;
  if(expires && !await window.DeskDialog.confirm({ title: t('永久删除'), message: t('此保留期限将立即永久删除 ')+expires+t(' 条到期归档记录，是否继续？'), confirmLabel: t('永久删除') })) return;
  try { localStorage.setItem(SETTINGS_KEY,JSON.stringify({...settings,retentionDays:days})); }
  catch { status.textContent=t('设置保存失败，请重试。'); return; }
  settings.retentionDays=days;status.textContent=t('已保存：归档后 ')+days+t(' 天自动删除。');renderTasks();
};
document.querySelectorAll('[data-completion-period]').forEach(button=>button.onclick=()=>{ const view='completed-'+button.dataset.completionPeriod; if(view!=='completed-all' && view!==currentView) completionDate.value=completionDateValue(); setView(view,t('已完成')); });
async function showDesktopMenuStatus(repair=false) {
  const button=document.getElementById('repairDesktopMenu'), status=document.getElementById('desktopMenuStatus');
  button.disabled=true;
  try { const result=await window.desktop?.desktopMenu(repair); status.textContent=result?.ok?t('已启用：桌面右键 → 显示更多选项 → 添加任务'):result?.error || t('未启用，请点击修复菜单'); }
  catch { status.textContent=t('菜单检查失败，请点击修复菜单重试。'); }
  finally { button.disabled=false; }
}
document.getElementById('repairDesktopMenu').onclick=()=>showDesktopMenuStatus(true);
showDesktopMenuStatus();

window.addEventListener('focus', () => { if(!completing) refreshSavedTasks(); });

const closeBehavior = document.getElementById('settingCloseBehavior');
const showCloseBehavior = value => { if (value && !settingsLoading && !settingsSaving) { closeBehavior.value = value; window.refreshSettingsSelects?.(); } };
window.desktop?.onCloseBehavior(showCloseBehavior);
closeBehavior.onchange = () => markSettingsDirty();

window.desktop?.onOpenSettings(() => {
  setFloatingMode(false); document.getElementById('settingsButton').click(); selectSettingsTab('general');
});

async function saveAllSettings() {
  if (settingsSaving || settingsLoading || !settingsNativeReady) return;
  const red = document.getElementById('settingUrgentHours'), white = document.getElementById('settingDistantHours');
  const urgentHours = Number(red.value), distantHours = Number(white.value);
  if (!red.value.trim() || !white.value.trim() || !red.checkValidity() || !white.checkValidity() || distantHours < urgentHours) {
    settingsSaveStatus.textContent = t('请输入 0–87600 小时，白色时间不得小于红色时间。');
    settingsSaveStatus.classList.add('is-dirty');
    return;
  }
  const snapshot = {
    local: { ...settings, highlightUrgent: document.getElementById('settingUrgent').checked, urgentHours, distantHours, sort: document.getElementById('settingSort').value, showCompleted: document.getElementById('settingCompleted').checked, motion: document.getElementById('settingMotion').checked },
    floating: { layer: document.getElementById('settingLayer').value, edgeCount: document.getElementById('settingEdgeCount').checked, shortcut: document.getElementById('settingShortcut').value },
    autoStart: autoStartCheckbox.checked, closeBehavior: closeBehavior.value,
    theme: document.getElementById('settingTheme').value, language: document.getElementById('settingLanguage').value,
    revision: settingsEditRevision
  };
  settingsSaving = true;
  window.closeSettingsSelects?.();
  const controls = [...settingsPage.querySelectorAll('input, select, button'), ...['settingsButton', 'themeToggle', 'languageToggle'].map(id => document.getElementById(id))];
  const disabledStates = new Map(controls.map(control => [control, control.disabled]));
  controls.forEach(control => { control.disabled = true; });
  settingsSaveButton.disabled = true;
  settingsSaveStatus.textContent = t('正在保存…');
  try {
    const next = snapshot.local;
    const floating = await window.desktop?.saveFloatingSettings(snapshot.floating);
    if (floating?.error) throw new Error(floating.error);
    const autoStart = nativeSettingsSnapshot.autoStartSupported ? await window.desktop?.saveAutoStart(snapshot.autoStart) : nativeSettingsSnapshot.autoStart;
    const close = await window.desktop?.saveCloseBehavior(snapshot.closeBehavior);
    if (close && close !== snapshot.closeBehavior) throw new Error(t('保存失败，请重试'));
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
    settings = next;
    window.setDeskTheme(snapshot.theme);
    syncMotionState();
    window.desktop?.setEdgeMotion(motionEnabled());
    sortAscending = settings.sort === 'asc';
    renderTasks();
    nativeSettingsSnapshot = { ...nativeSettingsSnapshot, closeBehavior: snapshot.closeBehavior, autoStart: snapshot.autoStart, ...snapshot.floating };
    if (settingsEditRevision === snapshot.revision) markSettingsClean(t('设置已保存'));
    else markSettingsDirty();
    if (snapshot.language !== window.deskLanguage) {
      window.saveLanguageNavigation?.();
      await window.desktop.saveLanguage(snapshot.language);
      location.reload();
    }
  } catch (error) {
    settingsDirty = true;
    settingsSaveStatus.textContent = error?.message || t('设置保存失败，请重试。');
    settingsSaveStatus.classList.add('is-dirty');
  } finally {
    disabledStates.forEach((disabled, control) => { control.disabled = disabled; });
    settingsSaving = false;
    window.refreshSettingsSelects?.();
    syncSettingsSaveControl();
  }
}
settingsSaveButton.onclick = saveAllSettings;
window.saveLanguageNavigation = () => sessionStorage.setItem('desk-navigation', JSON.stringify({
  view:currentView, month:monthFilter.value, date:completionDate.value, ascending:sortAscending,
  settings:!settingsPage.hidden, tab:document.querySelector('[data-settings-tab][aria-pressed="true"]')?.dataset.settingsTab,
  scroll:settingsPage.scrollTop, expanded
}));
window.restoreLanguageNavigation = () => {
  const saved=sessionStorage.getItem('desk-navigation'); sessionStorage.removeItem('desk-navigation');
  if(!saved)return;
  try {
    const value=JSON.parse(saved);
    monthFilter.value=value.month; completionDate.value=value.date; sortAscending=value.ascending;
    const nav=document.querySelector('[data-view="'+(value.view.startsWith('completed-')?'completed-all':value.view)+'"]');
    if(nav) setView(value.view,nav.querySelector('span:nth-child(2)')?.textContent || t('已完成'));
    if(value.settings) { document.getElementById('settingsButton').click(); selectSettingsTab(value.tab || 'general'); settingsPage.scrollTop=value.scroll; }
    if(value.expanded && appShell.classList.contains('is-floating')) setExpanded(true,false);
  } catch { /* Ignore stale navigation only; task storage is untouched. */ }
};

function finishMonthContent(content, open) {
  content.style.removeProperty('height');
  content.style.removeProperty('opacity');
  content.hidden = !open;
  content.inert = !open;
}
function animateMonthContent(content, open) {
  void DeskMotion.disclose(content, open, { duration: 300 });
}
function createMonthSection(group, index, kind, makeRow, nearestMonth) {
  const section = document.createElement('section');
  section.className = 'deadline-month'; section.dataset.month = group.key;
  const button = document.createElement('button');
  button.className = 'deadline-month-toggle'; button.type = 'button';
  const label = new Date(Number(group.key.slice(0, 4)), Number(group.key.slice(5, 7)) - 1, 1)
    .toLocaleDateString(window.deskLocale, { year: 'numeric', month: 'long' });
  button.innerHTML = '<span class="month-title"></span><span class="month-count"></span><span class="month-chevron" aria-hidden="true"></span>';
  button.querySelector('.month-title').textContent = label;
  button.querySelector('.month-count').textContent = t`${group.tasks.length} 项任务`;
  const content = document.createElement('div'); content.className = 'deadline-month-items';
  content.id = kind + '-deadline-month-' + group.key;
  button.setAttribute('aria-controls', content.id);
  const state = monthExpansion[kind];
  // Main lists open their nearest month; the global floating list keeps every month expanded so all pending tasks are immediately visible.
  const expanded = state.has(group.key) ? state.get(group.key) : kind === 'floating' ? true : group.key === nearestMonth;
  const update = (value, animate = false) => {
    button.setAttribute('aria-expanded', String(value));
    button.setAttribute('aria-label', label + (value ? t('收起清单') : t('展开清单')));
    if (animate) animateMonthContent(content, value);
    else finishMonthContent(content, value);
  };
  update(expanded);
  button.addEventListener('click', () => {
    const next = button.getAttribute('aria-expanded') !== 'true';
    state.set(group.key, next); update(next, true);
  });
  group.tasks.forEach((task, position) => content.appendChild(makeRow(task, position)));
  section.append(button, content);
  return section;
}
