# 更新日志

## 2026-10-16

### 新增

- 完成 Deadline Desk v2.2（程序版本 2.2.0）本地交付：在 `Latest/v2.2.0/dist/github-v2.2.0/` 集中整理 EXE、同名 SHA-256 和源码 ZIP，新增 `settings-controls.js`、`app-dialog.js`、`v220.test.cjs`、`v220-smoke.cjs` 与 `v220-display-smoke.cjs`。
- 完成 Deadline Desk v2.2.1 Windows x64 便携交付，新增 `v221-smoke.cjs` 动画回归；三个发布附件集中在 `Latest/v2.2.1/dist/github-v2.2.1/`。

### 修改

- 增大主清单和悬浮窗任务文字；导航统一为“总清单、今日、本周、本月、已完成”；设置下拉菜单与标签加入轻量动画和键盘操作，保留点击保存才生效并支持减少动态效果。灰色主题统一为中性灰背景、卡片和控件，保留任务状态色。主要涉及 `styles.css`、`app.js`、`index.html`、`i18n-core.js`、`theme.js`、`update-ui.js`。
- 将任务删除、永久删除和缩短保留期的确认改为应用内弹窗，提供任务名称、取消、Esc 和焦点约束；确认后读取最新任务，避免覆盖同期更改。
- 将 `Latest/v2.1.9/` 归档至 `HistoryVersion/v2.1.9/`，`Latest/` 只保留 `v2.2.0`；同步根 `README.md` 和本版 `RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`、`SOURCE-README.md`。本轮仅本地整理，未执行 Git 提交、推送或 GitHub Release。
- 将 `Latest/v2.2.0/` 归档至 `HistoryVersion/v2.2.0/`，当前目录只保留 v2.2.1；同步根 `README.md`、本版发布正文、源码说明和发布指南。

### 修复

- 修复解锁悬浮窗时整窗拖动区域吞掉列表滚轮事件的问题，保留顶部拖动与边缘缩放；修正字号增大后的倒计时宽度以及长设置选项在窄窗口和日文界面下的裁切。

- 修复设置慢速读取覆盖新选择，以及保存期间可重复提交、显示值与已保存值不一致的问题；读取完成前禁用相关选项，保存时固定本次提交值并冻结设置控件，完成或失败后恢复。补充延迟 IPC 交互回归，主要涉及 `app.js`、`i18n-core.js`、`styles.css`、`v220-smoke.cjs` 和 `v214.test.cjs`。
- 补齐主清单新增任务、悬浮清单展开/收起与任务变化动画；合并跨窗口重复通知，避免打断正在播放的入场过渡。主要涉及 `app.js`。
- 添加任务小窗在取消、Esc 或保存后先完成退场；阻止重复保存，对退场期间的新打开请求排队，并同步应用与系统减少动态效果偏好。主要涉及 `add-task.js`、`mini-window.js`、`preload.js`、`styles.css`。
- 按 v2.1.9 重新统一任务、悬浮窗和添加任务动效，消除 CSS 与脚本重复播放及全局取消动画；补齐确认框、日期选择器退场、日历翻页、主题和按钮反馈，展开悬浮清单时任务依次入场。版本号保持 `2.2.1`；主要涉及 `interaction-motion.js`、`app.js`、`i18n.js`、`add-task.js`、`app-dialog.js`、`deadline-picker.js`、`theme.js`、`styles.css`，新增 `motion-smoke.cjs` 定点验证。

## 2026-10-15

### 修改

- 将仓库首页和 v2.1.9 发布正文改写为中英双语，只介绍软件功能与用户可感知的变化；发布指南补充相同写作规范。涉及根 `README.md`、`RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`，同步当前源码包中的说明文档。

- 按历史发布范围整理 v2.1.9 GitHub 发布说明：仓库 README 与源码 ZIP，Release 三个附件；更新 `RELEASE-NOTES.md` 和 `PUBLISH-GUIDE.md` 的授权与校验说明，版本仍为 2.1.9。

### 修复

- v2.1.9 保持版本号不变，修复中英日切换后顶栏按钮溢出及设置下拉选项裁切；增大主清单截止时间与倒计时、悬浮窗时间字号，剩余任务数取消反色底块。涉及 `Latest/v2.1.9/index.html`、`styles.css`、`package.json`，新增 `v219-display-smoke.cjs`。同步 README 和三份发布说明，重建本地 EXE、SHA-256、源码 ZIP。36 项单元测试、三语言多宽度显示检查、主题与任务编辑、空数据启动及实际便携 EXE 文件核对通过；未线上发布。

## 2026-10-14

### 新增

- 完成 v2.1.9 Windows x64 本地发布资料；`Latest/v2.1.9/dist/github-v2.1.9/` 集中放置 `Deadline-Desk-2.1.9.exe`、同名 SHA-256 和源码 ZIP，并补齐 `RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`、`SOURCE-README.md`。
- 新增 v2.1.9 专项回归验证：新增 `v219.test.cjs` 单元测试与 `v219-smoke.cjs` 烟雾测试，全面覆盖顶栏工具分流、边栏聚焦导航、深/灰/浅色彩阶元与动画流畅度。
- 完成 v2.1.8 Windows x64 本地发布资料并归档至 `HistoryVersion/v2.1.8/`。

### 修改

- v2.1.9 全面重塑色彩阶元、优化界面逻辑布局并升级动效流畅度：
  - 重塑深色、灰色与浅色模式色彩层级：针对深色模式“一团黑”问题，将卡片表面明显抬升至板岩色（`#1a2232`），配合清晰细线边框（`#28364b`）与高对比度文字（`#f8fafc` / `#94a3b8`），彻底解决缺乏层次与边界模糊的问题；灰色模式升级为板岩灰蓝，浅色模式升级为纯净纸白；
  - 界面逻辑布局全面重构（边栏减负，顶栏赋能）：将主题切换、设置面板、语言选择及版本更新检测统一移至顶部 Header 工具栏，左侧边栏专注于核心视图导航与悬浮窗模式，空间更通透、层级更清晰；
  - 硬件加速流畅动效升级：重构动画过渡曲线，引入 `cubic-bezier(0.16, 1, 0.3, 1)`（Ease-Out Expo），剔除易掉帧的 `transition: all`，任务卡片入场、悬停浮起、弹窗展开与按钮点击全面引入 GPU 硬件合成，操作手感丝滑灵动；
  - 完备继承红黄白绿连续截止分级、跨月分组、悬浮胶囊 HUD 与任务编辑能力；
  - 主要涉及 `Latest/v2.1.9/index.html`、`styles.css`、`package.json`、`v219.test.cjs`、`v219-smoke.cjs`。

- 将原 `Latest/v2.1.8/` 完整归档至 `HistoryVersion/v2.1.8/`，`Latest/` 现仅保留 `v2.1.9`，新目录文件结构与上一版完全一致；同步更新根 `README.md` 的当前版本入口和发布资料链接。

### 修复

- 深度修复界面排版与视觉布局问题：
  - 修复顶栏挤压与状态文本单字竖排折行 Bug：修复 `.theme-toggle` 宽度继承与 `overflow-wrap: anywhere` 导致 `#updateStatus`（“已是最新版本”）被压缩为单字折行、左侧面包屑导航被严重挤压的问题；重构 `.topbar-actions` 与 `.update-panel` 布局并补充 `white-space: nowrap` 与胶囊徽标样式，在顶栏各功能组之间引入纤细分割线（`.topbar-divider`），使日期展示、更新检测、偏好设置与窗口控制形成清晰的间距与归类层级；调整媒体查询断点（820px），确保默认 940px 窗口下 `#todayLabel` 正常显示，`.breadcrumb` 设置 `min-width: max-content` 彻底根除面包屑文字被截断；
  - 修复任务项交互与元素对齐排版：将重命名/编辑铅笔图标紧密贴附于任务标题文本末尾，消除多余空隙；将删除按钮（`×`）从状态徽章与倒计时之间移出，归入倒计时右侧、复选框左侧的独立固定列，消除鼠标悬停时卡片内容跳动与位移；
  - 消除冗余双层主标题：重构主窗口标题结构，移除“我的任务”与“总截止清单”重叠的双层大标题，统一为利落的单层主标题与工具栏结构；
  - 修复悬浮窗（Floating Window）小长条（preview）与展开列表（details）排版：重构折叠预览卡片（`.preview-task`）的 3 行网格与内边距，移除 `.strip-header` 硬编码 64px 最小高度，流体适配 50px–70px 紧凑高度；精简预览卡片时间格式，省略同一年份前缀，彻底解决 360px 窄窗口下标题、截止时间与逾期倒计时被压缩截断为省略号的问题；规范悬浮展开列表中的任务项排版，与主清单保持统一的色彩分级、对比度与清晰层级；
  - 重建 Windows x64 便携版程序 `Deadline-Desk-2.1.9.exe`、同名 SHA-256 校验文件及源码压缩包，并通过所有单元测试与便携烟雾验证。

## 2026-09-29

### 新增

- v2.1.7 新增任务名称与截止时间编辑：主清单、完成清单及悬浮预览/展开清单提供铅笔入口，预填原任务信息；保存刷新倒计时、颜色、排序及月份分组，取消不写入，保留任务 ID、完成状态、完成时间和其他字段。允许编辑逾期任务，并保护已删除/归档及并发修改任务不被覆盖；仅改名称保留原时间精度。涉及 `task-editor.js`、`app.js`、`add-task.js`、`index.html`、`add-task.html`、`preload.js`、`mini-window.js`、`styles.css`、`i18n-core.js`，新增 8 项单元测试与 `task-edit-smoke.cjs`；`prepare-release.cjs` 支持独立打包目录及旧 EXE 检测，`portable-smoke.cjs` 校验实际免安装 EXE 的包内文件与源码一致；重新核验整理三个发布附件。

- 完成 v2.1.7 Windows x64 本地发布资料；`Latest/v2.1.7/dist/github-v2.1.7/` 集中放置 EXE、SHA-256 和源码 ZIP，并补齐 `RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`、`SOURCE-README.md`。

### 修改

- v2.1.7 将悬浮窗改为全局未完成任务视图，按截止月份分组；新增红、黄、白连续截止时间分级、绿色完成状态和最大化/还原窗口动画，涉及 `app.js`、`index.html`、`styles.css`、`main.js`、`i18n-core.js`。

### 修复

- 修复 v2.1.7 远期未完成任务仍显示绿色文字：移除旧版“五天外标绿”样式，在浅色、灰色和深色主题的主清单、悬浮预览及展开列表中改为白色文字配深色底色；绿色仅用于已完成任务。倒计时刷新继续按任务状态重新计算颜色类，涉及 `styles.css`、`v217.test.cjs`、`v217-smoke.cjs`。

- 修复悬浮窗只显示当前月份任务的问题；跨月份的未完成任务现在会在悬浮窗展开列表中保留并计入未完成总数。

## 2026-09-27

### 新增

- 完成 v2.1.5 Windows x64 本地发布资料；`Latest/v2.1.5/dist/github-v2.1.5/` 集中放置 `Deadline-Desk-2.1.5.exe`、SHA-256 和 69 文件源码 ZIP，并核验 EXE/ASAR、哈希、源码 ZIP 逐文件一致。同步新增 v2.1.5 发布正文、上传指南、源码说明和专项回归测试。

### 修改

- v2.1.5 为贴边收缩悬浮窗增加逻辑矩形重应用，修复透明窗口动画唤起时原生宽度漂移造成的图示、内容和边缘命中区错位；深色模式改为近黑底色配蓝色强调，涉及 `Latest/v2.1.5/mini-window.js`、`styles.css`、`theme.js`、`package.json` 与回归测试。
- v2.1.6 捕获悬浮窗唤起动画中的原生窗口 API 参数转换异常，校验坐标与窗口矩形并在失败后恢复，避免主进程弹出 JavaScript 错误对话框；新增故障注入 smoke test。主要涉及 `Latest/v2.1.6/mini-window.js`、`v216-smoke.cjs`、`v216.test.cjs`、`package.json`。

### 修复

- 将原 `Latest/v2.1.4/`、`Latest/v2.1.5/` 分别归档至对应 `HistoryVersion/` 版本目录，`Latest/` 现仅保留 v2.1.6；同步更新根 `README.md` 的当前版本入口和发布资料链接。

## 2026-09-26

### 新增

- 完成 v2.1.4 Windows x64 本地发布资料；`Latest/v2.1.4/dist/github-v2.1.4/` 集中放置 `Deadline-Desk-2.1.4.exe`、SHA-256 和 66 文件源码 ZIP，并核验 EXE/ASAR、哈希、源码 ZIP 逐文件一致。同步新增 v2.1.4 发布正文、上传指南、源码说明和聚焦测试。

### 修改

- v2.1.4 为悬浮窗拖动和边缘缩放固定逻辑尺寸并隔离缩放会话，修复持续按住时窗口自行扩大；完成清单侧栏符号改为绿色强调；设置页下拉控件统一圆角、箭头、悬停和聚焦视觉，并新增“保存设置”按钮，通用、悬浮窗和快捷键修改必须显式保存后生效。主要涉及 `Latest/v2.1.4/mini-window.js`、`app.js`、`styles.css`、`index.html`、`i18n.js`、`package.json` 及回归测试。

- 将原 `Latest/v2.1.3/` 归档至 `HistoryVersion/v2.1.3/`，`Latest/` 现仅保留 v2.1.4；同步更新根 `README.md` 的当前版本入口和本地发布资料链接。

## 2026-09-25

### 新增

- 完成 v2.1.3 独立源码与 Windows x64 本地发布附件；`Latest/v2.1.3/dist/github-v2.1.3/` 集中放置 `Deadline-Desk-2.1.3.exe`、SHA-256 和 64 文件源码 ZIP，核对 EXE/ASAR、哈希、源码 ZIP 逐文件一致，并新增 `task-lifecycle.js`、`v213.test.cjs`、`v213-smoke.cjs`。

- 完成 v2.1.0 独立源码与 Windows x64 本地发布附件；`Latest/v2.1.0/dist/github-v2.1.0/` 集中放置 EXE、SHA-256 和 57 文件源码 ZIP，核对 EXE 版本、哈希、ASAR 与源码 ZIP 逐文件一致。新增 `auto-start.js`、`deadline-groups.js`、`v210.test.cjs`、`v210-smoke.cjs`，保留本机任务数据，未线上发布。

- 完成 v2.1.1 独立源码与 Windows x64 本地发布附件；`Latest/v2.1.1/dist/github-v2.1.1/` 集中放置 `Deadline-Desk-2.1.1.exe`、SHA-256 和 59 文件源码 ZIP，核对 EXE/ASAR、哈希、源码 ZIP 逐文件一致，并新增 `v211.test.cjs`、`v211-smoke.cjs`。

- 完成 v2.1.2 独立源码与 Windows x64 本地发布附件；`Latest/v2.1.2/dist/github-v2.1.2/` 集中放置 `Deadline-Desk-2.1.2.exe`、SHA-256 和 61 文件源码 ZIP，核对 EXE/ASAR、哈希、源码 ZIP 逐文件一致，并新增 `v212.test.cjs`、`v212-smoke.cjs`。

### 修改

- v2.1.3 将未完成任务固定排在已完成任务之前；完成任务保留 24 小时后自动进入完成清单并从其他截止清单及悬浮窗隐藏；悬浮窗改用按显示器刷新率自适应的轻量位置调度并关闭后台节流；新增日语界面、圆角快速添加窗口和统一轻量交互动画。主要涉及 `Latest/v2.1.3/app.js`、`task-lifecycle.js`、`mini-window.js`、`main.js`、`styles.css`、`i18n-core.js`、`i18n.js`、
ative-language.js`、`add-task.html`、`index.html`。

- 总截止清单按截止年/月分组并默认展开最近月份；悬浮清单默认筛选 7 日内截止任务，可选 1、7、30 或自定义 1–999 日，保留逾期未完成任务，预览与范围内计数同步；增加悬浮窗回主界面过渡动画和默认关闭的 Windows 开机自启动设置。涉及 `Latest/v2.1.0/app.js`、`index.html`、`styles.css`、`main.js`、`preload.js`、`i18n-core.js` 及测试。

- 更新根 `README.md` 的当前版本入口，以及 `Latest/v2.1.0/RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`、`SOURCE-README.md`。v2.1.0 单元测试、原有完整界面回归、专项与最终包内 150% 缩放测试、空白配置启动检查通过。

- 将旧版 `Latest/v2.0.9/` 完整归档至 `HistoryVersion/v2.0.9/`，核对历史 EXE 与 SHA-256 一致；`Latest/` 现仅保留 `v2.1.0/`。

- v2.1.1 优化悬浮窗与完成清单操作：展开默认显示 7 日范围并将月份折叠，月份展开加入高度/透明度动画；完成筛选改为全部/今年/本月/本周/今天，期间摘要显示日期区间，前后导航按钮直接标注上一年、上个月、上一周和前一天等动作；完成期间、月份标题和悬浮控件同步美化。主要涉及 `Latest/v2.1.1/app.js`、`index.html`、`styles.css`、`deadline-picker.js`、`i18n-core.js`。同时更新根 `README.md`、v2.1.1 发布说明、上传指南与源码说明。

- 将原 `Latest/v2.1.0/` 移入 `HistoryVersion/v2.1.0/`，`Latest/` 现仅保留 `v2.1.1/`。

- v2.1.2 将悬浮窗改为当前日历月截止清单并默认展开，移除 7 日设置；撤回上一轮极简直角方案，恢复圆润卡片与轻阴影基础，重新整理侧栏、顶部栏、内容列、任务行和月份层级，并将深色主题改为黑蓝“蓝夜”配色。主要涉及 `Latest/v2.1.2/styles.css`、`theme.js`、`v212.test.cjs`、`v212-smoke.cjs`，同时更新根 README 与本版发布资料并重新打包。

- 将原 `Latest/v2.1.1/` 移入 `HistoryVersion/v2.1.1/`，`Latest/` 现仅保留 `v2.1.2/`。

### 修复

- 修复总清单在月份分组重排后已完成任务错误显示在未完成任务前的问题，并修复快速添加窗口四角显示尖角背景的问题；将原 `Latest/v2.1.2/` 归档至 `HistoryVersion/v2.1.2/`，同步更新根 `README.md` 与 v2.1.3 发布资料。

## 2026-09-23

### 新增

- 完成 v2.1.6 Windows x64 本地发布资料；`Latest/v2.1.6/dist/github-v2.1.6/` 集中放置 `Deadline-Desk-2.1.6.exe`、SHA-256 和 71 文件源码 ZIP，并核验 EXE/ASAR、哈希、源码 ZIP 逐文件一致。同步新增 v2.1.6 发布正文、上传指南、源码说明和故障注入回归测试。

- 完成 v2.0.9 独立源码和本地发布附件；发布目录 `v2.0.9/dist/github-v2.0.9/` 含 `Deadline-Desk-2.0.9.exe`、SHA-256 文件和 53 文件源码 ZIP；同步更新根 `README.md`、`v2.0.9/RELEASE-NOTES.md`、`PUBLISH-GUIDE.md` 与 `SOURCE-README.md`。

### 修复

- 修复 v2.0.9 Windows 任务栏白纸/空白文档图标：保持 `com.deadlinedesk.app` AppUserModelId 与 electron-builder `appId` 一致，改用标准 16/24/32/48/64/128/256 多尺寸 `app-icon.ico`，并让 BrowserWindow、便携 EXE 与任务栏快捷项统一使用该 ICO；重新打包核验 EXE、SHA-256 与源码 ZIP。主要涉及 `v2.0.9/main.js`、`v2.0.9/app-icon.ico`、`v2.0.9/v209.test.cjs` 及本地发布附件。

### 修改

- 调整版本资料目录：将当前最新版 v2.0.9 从根目录移动到 `Latest/v2.0.9/`，将旧版本目录（含 `v2`）归档到 `HistoryVersion/`；将 `.scratch-v205` 至 `.scratch-v208` 整理到 `HistoryVersion/DevelopmentScratch/`，删除空的 `.scratch-v209/`；同步更新 `README.md` 与 `AGENTS.md`，以后更新只读取 `Latest/`。

- 加强版本与更新链路：统一运行版本、旧实例提示、Release 标签/附件路径校验、EXE 元数据和启动确认；修复临时图标资源，悬浮模式隐藏任务栏按钮并保留系统托盘入口；删除任务增加二次确认并移入带“已删除”标记的回收站；贴边仅数字标签矩形唤醒；优化窗口、倒计时和任务完成动画。主要涉及 `v2.0.9/main.js`、`app.js`、`updater.js`、`update-helper.ps1`、`app-identity.js`、`edge-hit-test.js`、`mini-window.js`、`window-lifecycle.js`、`window-motion.js`、`package.json` 及测试脚本。完成更新器、版本身份、回收站、贴边命中、150% 缩放、历史回归和最终打包一致性核验；未上传、未提交、未推送。

## 2026-09-22

### 新增

- 完成 v2.0.8 独立源码和本地发布附件；新增主界面进入悬浮窗动画，以及设置中的标红/标绿小时数，默认 48/120 小时不变，保存时校验范围并确保互斥。发布目录 `v2.0.8/dist/github-v2.0.8/` 含 EXE、SHA-256 和 46 文件源码 ZIP；更新 `RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`、`SOURCE-README.md` 与根 `README.md`。

- 完成 v2.0.7 独立源码及本地发布附件：超过五天的未完成任务在主列表、悬浮条和展开列表标绿，侧栏增加圆形中英文切换按钮。发布目录为 `v2.0.7/dist/github-v2.0.7/`，含 EXE、SHA-256 与 45 文件源码 ZIP；更新发布正文、上传指南、源码说明及根 README。

- 完成 v2.0.6 独立源码和本地发布附件，启动时后台自动检测一次更新；整理 `v2.0.6/dist/github-v2.0.6/` 的 EXE、SHA-256 与 44 文件源码 ZIP，更新发布正文、上传指南、源码说明及根 README。

- 完成 v2.0.5 本地发布资料：新增中英文界面与语言持久化、窗口打开/恢复/最小化动画、紧凑可移动添加窗口、右上角锁定的最小悬浮窗和浅色/深色/灰色主题循环；整理 `v2.0.5/dist/github-v2.0.5/` 的 EXE、SHA-256 与源码 ZIP，更新 `v2.0.5/RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`、`SOURCE-README.md` 与根 `README.md`。

- 整理 v2.0.4 GitHub 发布附件到 `v2.0.4/dist/github-v2.0.4/`（EXE、SHA-256、37 文件源码 ZIP），校验 EXE 哈希、源码 ZIP 各文件与版本源码一致、运行源码与发行包一致；新增 `v2.0.4/PUBLISH-GUIDE.md`、`SOURCE-README.md` 和根 `AGENTS.md`，同步更新发布正文及 README。将每版默认整理三个附件、发布说明和核验记录写入项目规则；未上传或发布。

- 新增 v2.0.4 独立源码、Windows x64 免安装程序 `v2.0.4/dist/Deadline-Desk-2.0.4.exe` 及 SHA-256 文件；关闭按钮支持询问、记住退出或最小化到系统托盘，并可在通用设置修改。系统托盘支持恢复、设置、图层、添加与退出；任务栏跳转列表增加设置、图层和添加快捷项，正常退出后保留可冷启动的原始 EXE 路径。涉及 `window-lifecycle.js`、`preload.js`、`app.js`、`index.html`、`package.json`、`v204-smoke.cjs`、`RELEASE-NOTES.md` 及根 `README.md`。

### 修复

- 修复 Windows 更新助手脱离启动不执行、父进程退出后助手终止的问题，改为独立隐藏进程并补充准备状态与失败诊断；切换语言保留当前页面、设置子页及日期筛选，悬浮窗四边仅数字标签区域唤醒。涉及 `v2.0.8/updater.js`、`update-helper.ps1`、`update-ui.js`、`app.js`、`i18n.js`、`mini-window.js`、`index.html`、`styles.css` 及测试。8 项更新器/翻译测试、专项和 150% 打包回归、更新界面/语言/托盘回归、空白启动与发布内容核验通过；历史完整回归及 v2.0.4 回归仍有置顶断言失败，旧版对照也复现，限制已写入发布说明。旧版更新失败需手动运行一次本版；未清空数据，未提交、推送或线上发布。

- 修复 Windows 显示桌面后悬浮窗消失，依据原生桌面遮挡状态无焦点恢复，保留三种图层和主动隐藏行为；涉及 `v2.0.7/window-layer.js`、`floating-settings.js`。完整历史回归、7 项翻译/更新器测试、新版与 150% 缩放打包源码测试通过；核验 EXE 版本、SHA-256、包内源码和 ZIP 一致性。未清空数据，未提交、推送或线上发布。

- 修复任务栏显示 Electron 的名称与图标资源，补充窗口重启标识；修复被遮挡窗口动画不结束导致无法隐藏到托盘。涉及 `v2.0.6/package.json`、`main.js`、`i18n.js`、`prepare-release.cjs` 及回归测试。

- 修复桌面右键和任务栏唤起添加窗口无法移动、默认位置不居中及底部空白问题；日期面板按需展开并在关闭后恢复紧凑尺寸。修复悬浮窗首次进入位置、尺寸和锁定状态不符合预期。通过完整历史回归、更新器测试、英语重启持久化和 150% 缩放检查；未提交、推送或线上发布。

- 桌面添加改为直接运行已展开程序进行单实例转交，避免重复解压和临时资源清理风险；修复页面加载完成后添加请求仍滞留的时序问题，添加窗口改为不透明背景并绑定具体实例的显示回调。置底窗口被唤回后临时前置，添加窗口操作期间保留，切换到其他应用恢复置底。涉及 `v2.0.4/main.js`、`desktop-menu.js`、`mini-window.js`、`floating-settings.js`、`window-layer.js`。完整原功能回归、5 项更新器测试、新增功能回归及 150% 缩放检查通过；真实第二进程转交测试约 586 毫秒就绪，发行包隔离启动和源码一致性已核验。Explorer 跳转列表实际外观及异缩放多屏未人工验收，未执行提交、推送或线上发布。

### 修改

- 灰色主题保留原有亮点和层次，稍微加深中性灰底，按钮和装饰改为蓝灰配色；涉及 `v2.0.7/styles.css`、`app.js`、`index.html`、`i18n.js`。

- 加深灰色主题；托盘点击直接显示悬浮窗；桌面右键及任务栏添加入口仅显示添加窗口，保存后自动进入悬浮窗。涉及 `v2.0.6/styles.css`、`main.js`、`window-lifecycle.js`、`mini-window.js`、`preload.js`、`app.js` 与 `i18n-core.js`。

## 2026-09-21

### 新增

- 完成 v2.0.3 正式发布准备：重新构建并核对 EXE、SHA-256 与包内 19 个白名单文件，整理 `v2.0.3/dist/github-v2.0.3/` 上传目录（EXE、校验文件、34 文件源码 ZIP）；新增 `v2.0.3/RELEASE-NOTES.md`、`PUBLISH-GUIDE.md`、`SOURCE-README.md` 和 `release-clean-smoke.cjs`，更新根 `README.md` 发布入口。按要求清空本机应用数据，验证包内程序空白启动无任务、默认设置。更新模块 5 项测试通过，完整界面回归重跑通过；发布指南记录首次贴边动画计时断言偶发失败及尚未验证的线上升级范围。未执行 Git 提交、推送或 GitHub 发布。

- 新增 v2.0.3 独立源码、Windows x64 免安装程序 `v2.0.3/dist/Deadline-Desk-2.0.3.exe` 和同名 `.exe.sha256` 校验文件。完成清单定位日期改为整框日期按钮，支持鼠标任意位置、键盘打开、确认及取消；主界面侧栏与设置页显示当前版本。侧栏新增 GitHub Releases 检测更新，连接公开仓库 `frredomerror91-netizen/AgentProject`，支持版本比较、下载进度、SHA-256 校验、自动替换重启、旧程序备份、替换/启动失败回滚与失败重试，保留任务数据。涉及 `v2.0.3/deadline-picker.js`、`index.html`、`styles.css`、`main.js`、`preload.js`、`updater.js`、`update-ui.js`、`update-helper.ps1`、`release-checksum.cjs`、`package.json`、更新测试及 `README.md`。通过完整功能回归、150% 缩放新功能测试、5 项更新测试（含 Windows 实际替换和启动失败回滚），已检查截图及打包源码一致性。补充 GitHub 正式 Release 的标签、EXE 与校验文件发布说明；当前仓库尚无可用正式 Release，线上完整升级待发布后验证。

- 新增 v2.0.2 独立源码和 Windows x64 免安装程序 `v2.0.2/dist/Deadline-Desk-2.0.2.exe`：左侧完成清单合并为单一入口，全部/年/月/周/日筛选移至右侧，移除完成清单空状态圆形添加按钮及新建入口；新增完成记录归档和独立回收站，按归档月份分组，支持还原并保留完成时间、确认后永久删除。默认归档后 30 天清理，可设 7/30/90 天或 1–1825 天自定义期限，显示预计删除时间，启动/返回前台/运行期间检查到期记录，缩短期限导致立即删除时先确认。桌面菜单改用 Explorer Directory Background 注册路径，核验启动命令、清理旧注册项，通用设置新增状态和修复按钮；Windows 11 使用“显示更多选项”。涉及 `v2.0.2/app.js`、`index.html`、`styles.css`、`desktop-menu.js`、`main.js`、`preload.js`、`package.json`、`smoke-test.cjs`、`v201-checks.cjs`、`v202-checks.cjs` 及 `README.md`。通过完整回归、150% 缩放新增功能验证、归档/还原/分组、保留期限边界及启动清理、菜单注册状态/清理测试；已检查两种缩放界面并核对发布包源码。

- 新增 v2.0.1 独立源码和 Windows x64 免安装程序 `v2.0.1/dist/Deadline-Desk-2.0.1.exe`：左侧新增全部完成及年/月/周/日完成清单，按实际完成时间归档，支持日期定位和前后期间切换，周按周一至周日计算；完成时间持久化，撤销时清除，旧版无时间记录保留在全部完成并明确标注。新增默认开启的两天内任务标红设置，覆盖主清单、悬浮条和展开列表的任务名与倒计时，包含 48 小时边界和逾期未完成任务。主界面和快速添加默认截止时间统一为本地明天 15:00。涉及 `v2.0.1/app.js`、`index.html`、`styles.css`、`add-task.js`、`package.json`、`smoke-test.cjs`、`v201-checks.cjs` 及 `README.md`。通过完整原有功能回归，以及当前和 150% 缩放下完成归档/撤销/持久化、旧记录兼容、跨年跨周与月末边界、标红开关和默认时间测试，已目视检查清单并核对发布包源码。

- 新增 v2.0.0 独立源码和 Windows x64 免安装程序 `v2.0.0/dist/Deadline-Desk-2.0.0.exe`：悬浮窗支持四边约 260 毫秒动画收缩与唤回，默认显示约 40×28 逻辑像素待完成数量标签，提供持久化开关；时钟保留拖动并支持直接键入小时/分钟，非法及越界输入提示错误并阻止确认；新增灰色主题；启动时注册当前用户桌面右键“添加任务”菜单，正常退出清理，重复启动转交已有实例并复用添加窗口。涉及 `v2.0.0/mini-window.js`、`floating-settings.js`、`deadline-picker.js`、`theme.js`、`styles.css`、`index.html`、`app.js`、`preload.js`、`main.js`、`desktop-menu.js`、`package.json`、`smoke-test.cjs`、`v19-checks.cjs`、`v20-checks.cjs` 和 `README.md`。通过当前及 150% 缩放回归、时间输入边界、四边动画中间帧与标签截图、注册表测试键注册/清理、真实第二进程转交及任务保存测试，并核对发布包源码一致性；Windows 11 通常需在“显示更多选项”中使用菜单，异缩放多屏仍待实机验证。

- 新增 v1.9.0 独立源码和 Windows x64 免安装程序 `v1.9.0/dist/Deadline-Desk-1.9.0.exe`：悬浮窗右键图层菜单与设置专页同步，支持置顶、普通和 Windows 原生置底；新增默认不绑定的全局模式切换快捷键及冲突提示；保留年月日选择，时分改为支持点选、拖动和键盘微调的 24 小时时钟轮盘；紧凑显示未完成 DDL 数量；左右贴边自动隐藏、鼠标唤回，锁定取消隐藏，编辑/菜单/拖动期间暂停隐藏。涉及 `v1.9.0/floating-settings.js`、`window-layer.js`、`main.js`、`mini-window.js`、`preload.js`、`app.js`、`index.html`、`deadline-picker.js`、`window-geometry.js`、`styles.css`、`package.json`、`smoke-test.cjs`、`v19-checks.cjs` 和 `README.md`。已通过当前及 150% 缩放回归、Windows 实际置底顺序、截图检查和发布包源码一致性核验；异缩放多屏仍需实机验证。

- 新增 v1.8.0 独立源码及 Windows x64 免安装程序 `v1.8.0/dist/Deadline-Desk-1.8.0.exe`：放大任务名与倒计时，单任务悬浮条空间充足时左右分区展示名称/截止时间与倒计时/完成框；完成动画仅滑动淡出、列表补位，去掉背景变色和完成框填色切换；日期与窗口控制分列防遮挡，两个添加入口改用居中 SVG 加号，排序按钮明确显示“截止：最近优先 / 最远优先”。涉及 `v1.8.0/app.js`、`styles.css`、`index.html`、`package.json`、`smoke-test.cjs` 和 `README.md`。已通过当前缩放与 150% 缩放回归、界面截图检查及发布包源码一致性核验。

- 新增 v1.7.0 独立源码及 Windows x64 免安装程序 `v1.7.0/dist/Deadline-Desk-1.7.0.exe`：悬浮窗支持八方向拖边缩放（最小 360×72），窄窗仅显示最近一项任务及必要操作，高度扩大自动展开清单，锁定同时固定位置和尺寸；新增退出按钮与主界面最大化/还原按钮，保留切换悬浮模式前的窗口状态。主界面月份框、截止时间框及快速添加时间框统一为不可选中文字的整框按钮，打开约 180 毫秒淡入缩放的日期/月历面板，支持键盘操作和减少动态效果偏好；统一窗口操作 SVG、完成勾选及按钮居中。涉及 `v1.7.0/main.js`、`mini-window.js`、`preload.js`、`app.js`、`index.html`、`deadline-picker.js`、`add-task.js`、`styles.css`、`package.json`、`smoke-test.cjs` 和 `README.md`。已通过当前及强制 150% 缩放回归，验证缩放后拖动、最小布局、最大化还原、日期月份保存、真实鼠标点击、Escape 关闭层级、退出及原有功能；已核对发布包源码，异缩放多屏仍待实机验证。

- 新增 v1.6.0 独立源码和 Windows x64 免安装程序 `v1.6.0/dist/Deadline-Desk-1.6.0.exe`：小长条补充截止年月日与时分，不足一天的倒计时及逾期时长省略“0天”；设置切换为主窗口内专属页面，支持返回原清单；完整清单采用上下帘幕展开/收起动画，箭头改为居中 SVG。涉及 `v1.6.0/app.js`、`index.html`、`styles.css`、`mini-window.js`、`preload.js`、`main.js`、`theme.js`、`package.json`、`smoke-test.cjs` 和 `README.md`。
- 新增 v1.5.0 独立源码和 Windows x64 免安装程序 `v1.5.0/dist/Deadline-Desk-1.5.0.exe`：默认双任务并列悬浮横条、右侧展开/收起完整列表；新增主题、默认排序、已完成项显示及动画设置并持久化；完成任务淡出和列表平滑补位；完成框左侧显示天/小时/分钟倒计时和逾期时长。涉及 `v1.5.0/app.js`、`index.html`、`styles.css`、`main.js`、`mini-window.js`、`preload.js`、`package.json`、`smoke-test.cjs` 及 `README.md`。已验证尺寸切换、动画、设置重启保存、倒计时边界、锁定状态下底部展开和原有拖动/快速添加功能。
- 新增 v1.4.0 独立源码及 Windows x64 免安装程序 `v1.4.0/dist/Deadline-Desk-1.4.0.exe`，保留原有任务存储；新增月截止清单及年月筛选，主界面和悬浮窗每条任务右侧新增完成勾选框，完成状态持久化、已完成项沉底并支持恢复，涉及 `v1.4.0/app.js`、`index.html`、`styles.css`、`package.json`。
- 新增 Deadline Desk 桌面应用初版，包含任务空状态、任务创建弹窗、截止时间排序列表、任务筛选和本地持久化，涉及 `index.html`、`styles.css`、`app.js`。
- 新增 Electron 窗口入口与安全预加载脚本，支持将主窗口缩为置顶悬浮条并展示最近两个截止任务，涉及 `main.js`、`preload.js`、`package.json`。
- 新增 Windows x64 免安装程序，历史 v1.1.0 现归档为 `v1.1.0/dist/Deadline-Desk-1.1.0.exe`；补齐打包配置和依赖锁定文件。
- 新增悬浮位置锁定、屏幕边缘吸附与独立快速添加窗口；小窗在悬浮条下方打开，底部空间不足时移至上方，保存后同步任务，涉及 `mini-window.js`、`window-geometry.js`、`add-task.html`、`add-task.js`。
- 新增 v1.3.0 暗夜模式，覆盖主界面、悬浮条、任务弹窗和快速添加窗口；左下角切换并保存偏好，窗口间同步主题，涉及 `v1.3.0/theme.js`、`index.html`、`add-task.html`、`styles.css`。
- 新增最新 Windows x64 免安装程序 `v1.3.0/dist/Deadline-Desk-1.3.0.exe`，以及版本目录和使用说明 `README.md`。
- 新增 v1.3.1 版本目录及代码绘制的三色柱形应用图标，配置 Windows 窗口与打包图标，涉及 `v1.3.1/app-icon.png`、`v1.3.1/main.js`、`v1.3.1/package.json`。
- 新增 v1.3.1 Windows x64 免安装程序及完整 `win-unpacked` 发布目录，涉及 `v1.3.1/dist/Deadline-Desk-1.3.1.exe`。

### 修改

- v2.0.3 更新源迁移至 `frredomerror91-netizen/Deadline_app`，同步下载地址校验、旧仓库拒绝测试和发布指南；为根 `README.md` 与 `v2.0.3/SOURCE-README.md` 补充简洁中英双语介绍。重新生成 EXE、SHA-256 和源码 ZIP，替换 `v2.0.3/dist/github-v2.0.3/` 上传文件并更新指南校验信息。5 项更新测试、最终包 19 文件源码比对、空白启动和源码 ZIP 一致性验证通过。涉及 `v2.0.3/updater.js`、`updater.test.cjs`、`PUBLISH-GUIDE.md` 及上述文件；版本仍为 2.0.3，尚未上传或发布。

- v1.4.0 将“全部任务”明确为“总截止清单”，悬浮窗改为约 380×360 的顶部操作栏和可滚动纵向清单，按截止时间优先展示未完成任务并保留逾期项；支持拖动标题栏，更新版本使用说明，涉及 `v1.4.0/index.html`、`app.js`、`styles.css`、`main.js`、`README.md`。
- 将悬浮窗缩为约 420×56 的无边框置顶 Mini 长条，移除左侧标识，仅保留任务和锁定、添加、恢复操作；主界面去除标语、统计卡片及重复入口，涉及 `index.html`、`styles.css`、`main.js`、`preload.js`。
- 按版本隔离应用文件：原 `dist/Deadline-Desk-1.0.0.exe` 移至 `v1.0.0/dist/`；原根目录 v1.1.0 源码、依赖配置及其 `dist/` 移至 `v1.1.0/`，从该版建立独立 `v1.3.0/`。未发现 v1.2.0；v1.0.0 仅保留现有可执行程序，不虚构历史源码。
- 将 v1.3.1 悬浮窗改为透明窗口配合圆角裁切，消除悬浮条尖锐边角；为主界面和快速添加窗口的截止时间输入增加聚焦光晕与时钟指针动画，涉及 `v1.3.1/styles.css`、`v1.3.1/index.html`、`v1.3.1/add-task.html`。
- 重绘 v1.3.1 图标为透明背景、等宽等间距且统一圆角的三根彩色柱子，并重新生成 Windows 发布包，涉及 `v1.3.1/app-icon.png`、`v1.3.1/dist/Deadline-Desk-1.3.1.exe`、`v1.3.1/styles.css`。
- 放大 v1.3.1 图标三根柱子的整体占比，保留透明边距、等宽等间距和圆角设计，并重新生成 Windows 发布包，涉及 `v1.3.1/app-icon.png`、`v1.3.1/dist/Deadline-Desk-1.3.1.exe`。

### 修复

- v1.6.0 拖动时同时提交固定逻辑尺寸与位置，维持稳定的最小尺寸约束，修复 Windows 缩放下悬浮窗拖动扩大；动画帧暂停时完成任务流程增加超时收尾，设置页主题与侧栏切换同步。已通过当前缩放和强制 150% 缩放下的持续拖动、边缘约束、动画中间高度/反向收起、日期/倒计时、设置持久化及原有功能回归，发布包源码一致性已核对；不同缩放多屏间拖动尚未实机验证。
- v1.4.0 清除根页面不透明底色并关闭原生阴影，修复悬浮窗圆角外露底色；拖动仅更新窗口位置、跳过静止帧，停止拖动后再吸附，避免重复设置尺寸和移动事件竞争；主界面及快速添加窗口点击整个截止时间框均可调用选择器。涉及 `v1.4.0/styles.css`、`main.js`、`mini-window.js`、`deadline-picker.js`、`add-task.html`，并通过 `v1.4.0/smoke-test.cjs` 的透明像素、排序存储、月份筛选、时间框调用及连续贴边拖动等回归验证。
- Mini 始终展示最近两个未到期任务，不受列表倒序影响；修复窗口样式切换后置顶状态丢失，新增原生窗口回归验证，涉及 `app.js`、`main.js`、`smoke-test.cjs`。
- 修复右侧吸附后继续拖动导致空白区域持续扩大的问题：使用指针拖动及固定 420×56 逻辑尺寸，避免 Windows 移动循环和 DPI 尺寸取整累积；保留锁定、回拖、屏幕边缘约束和恢复主界面，涉及 `v1.3.0/main.js`、`mini-window.js`、`preload.js`、`app.js`。`v1.3.0/smoke-test.cjs` 已通过连续右拖 15 次、回拖、窗口锁定、添加同步、主题持久化及子窗口主题同步回归。














