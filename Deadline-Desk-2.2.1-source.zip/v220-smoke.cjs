const { app, BrowserWindow, net, ipcMain } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const results = [];
const output = process.env.DDL_UI_OUTPUT;
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v220-')));
process.env.DDL_TEST = '1';
net.fetch = async () => new Response(JSON.stringify({ tag_name: 'v' + require('./package.json').version }));
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('v2.2 UI regression timeout'); app.exit(1); }, 90000).unref();
app.whenReady().then(async () => {
  const win = BrowserWindow.getAllWindows()[0];
  const js = code => win.webContents.executeJavaScript(code);
  const settle = async () => { while(win.webContents.isLoading()) await delay(30); await delay(220); };
  const capture = async name => { if(output) { fs.mkdirSync(output,{recursive:true}); fs.writeFileSync(path.join(output,name+'.png'),(await win.webContents.capturePage()).toPNG()); } };
  const check = async (name, run) => { try { await run(); results.push({name,passed:true}); console.log('PASS '+name); } catch(error) { results.push({name,passed:false,error:error.message}); console.error('FAIL '+name+': '+error.message); } };
  try {
    await settle();
    const tasks = Array.from({length:18},(_,i)=>({id:'case-'+i,name:i===0?'离散第七次作业 <测试>':'大物实验报告与学习任务 '+(i+1),deadline:new Date(Date.now()+(168+i)*3600000).toISOString()}));
    await js('localStorage.setItem("deadline-desk.tasks", '+JSON.stringify(JSON.stringify(tasks))+'); localStorage.setItem("deadline-desk.settings", '+JSON.stringify(JSON.stringify({motion:true,showCompleted:true}))+'); location.reload()');
    await settle(); win.setSize(1180,830); await delay(200);
    await check('concise navigation names and page titles', async()=>{
      const expected={all:'总清单',today:'今日',week:'本周',month:'本月','completed-all':'已完成'};
      for(const [view,label] of Object.entries(expected)) {
        const actual=await js('(() => { const nav=document.querySelector('+JSON.stringify('[data-view="'+view+'"]')+'); nav.click(); return [nav.querySelector("span:nth-child(2)").textContent,viewHeading.textContent,listHeading.textContent]; })()');
        assert.deepEqual(actual,[label,label,label]);
      }
    });
    await js('document.querySelector("[data-view=all]").click(); window.setDeskTheme("gray")'); await delay(250);
    await check('gray theme uses neutral gray on backgrounds, cards and text',async()=>{
      const colors=await js('(() => { const color=(selector,property)=>getComputedStyle(document.querySelector(selector))[property]; return [color("body","backgroundColor"),color(".sidebar","backgroundColor"),color(".task-row.is-distant","backgroundColor"),color(".task-row .task-meta","color"),getComputedStyle(document.documentElement).getPropertyValue("--card-bg").trim()]; })()');
      for(const color of colors) { const values=color.startsWith('#')?color.slice(1).match(/../g).map(x=>parseInt(x,16)):color.match(/[\d.]+/g).slice(0,3).map(Number); assert.equal(values[0],values[1],color); assert.equal(values[1],values[2],color); }
      assert.equal(await js('document.querySelector("meta[name=theme-color]").content'),'#292929');
    });
    await check('main task text is larger and stays within its card',async()=>{
      const result=await js('(() => {const n=document.querySelector(".task-row .task-name"),meta=document.querySelector(".task-meta");return {font:parseFloat(getComputedStyle(n).fontSize),meta:parseFloat(getComputedStyle(meta).fontSize),overflow:document.documentElement.scrollWidth>innerWidth};})()');
      assert.ok(result.font>=16,JSON.stringify(result)); assert.ok(result.meta>=13,JSON.stringify(result)); assert.equal(result.overflow,false);
    });
    await capture('main-gray');
    await check('unlocked floating list receives wheel input without moving the window',async()=>{
      await js('setFloatingMode(true)'); await delay(280); await js('setExpanded(true); if(locked) stripLockButton.click()'); await delay(250); win.setBounds({x:220,y:160,width:450,height:300}); await delay(250);
      assert.equal(await js('getComputedStyle(floatingStrip).webkitAppRegion'),'no-drag','unlocked window must not swallow input as a native drag region');
      const point=await js('(() => {stripTasks.scrollTop=0;const r=stripTasks.getBoundingClientRect();return {x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2),overflow:stripTasks.scrollHeight-stripTasks.clientHeight};})()'); assert.ok(point.overflow>0);
      const before=win.getBounds();
      for(const lockedState of [false,true]) {
        await js('if(locked!=='+lockedState+') stripLockButton.click(); stripTasks.scrollTop=0');await delay(120);
        win.webContents.sendInputEvent({type:'mouseWheel',x:point.x,y:point.y,deltaX:0,deltaY:-180,canScroll:true}); await delay(220);
        assert.ok(await js('stripTasks.scrollTop')>0,'wheel must scroll with locked='+lockedState);
      }
      assert.deepEqual(win.getBounds(),before);
      await js('if(locked) stripLockButton.click()'); await capture('floating-unlocked');
    });
    await check('floating titles are larger at both compact and expanded widths',async()=>{
      await js('setFloatingMode(true); setExpanded(true)'); await delay(200); win.setSize(450,300); await delay(160);
      const fonts=await js('({expanded:parseFloat(getComputedStyle(document.querySelector(".strip-task .strip-task-name")).fontSize),preview:parseFloat(getComputedStyle(document.querySelector(".preview-task .strip-task-name")).fontSize)})'); assert.ok(fonts.expanded>=15,JSON.stringify(fonts));assert.ok(fonts.preview>=14,JSON.stringify(fonts));
      win.setSize(360,300); await delay(160); assert.equal(await js('document.documentElement.scrollWidth>innerWidth'),false);
    });
    await js('setFloatingMode(false)'); await delay(300); win.setSize(1180,830); await js('settingsButton.click()'); await delay(200);
    await check('settings dropdown animates, supports keyboard, and preserves save semantics',async()=>{
      const state=await js('(() => {const trigger=document.querySelector("[data-select-for=settingLanguage]");assertTrigger=!!trigger;if(!trigger)return null;trigger.click();const menu=document.getElementById(trigger.getAttribute("aria-controls"));return {expanded:trigger.getAttribute("aria-expanded"),role:trigger.getAttribute("role"),animated:menu.getAnimations().some(a=>a.playState==="running"),options:menu.querySelectorAll("[role=option]").length};})()');
      assert.ok(state,'custom settings dropdown is missing');assert.equal(state.expanded,'true');assert.equal(state.role,'combobox');assert.equal(state.animated,true);assert.equal(state.options,3);await delay(230);await capture('settings-dropdown');
      win.webContents.sendInputEvent({type:'keyDown',keyCode:'Down'}); win.webContents.sendInputEvent({type:'keyDown',keyCode:'Return'});await delay(100);
      assert.equal(await js('settingLanguage.value'),'en'); assert.equal(await js('document.documentElement.lang'),'zh-CN','language is applied only on Save'); assert.equal(await js('settingsDirty'),true);
      await js('settingLanguage.value="zh-CN";window.refreshSettingsSelects();document.querySelector("[data-select-for=settingCloseBehavior]").click()');
      win.webContents.sendInputEvent({type:'keyDown',keyCode:'Escape'});await delay(100);assert.equal(await js('document.querySelector("[data-select-for=settingCloseBehavior]").getAttribute("aria-expanded")'),'false');
    });
    await check('settings tabs animate and reduced motion disables new animations',async()=>{
      await js('document.querySelector("[data-settings-tab=floating]").click()');
      assert.equal(await js('document.querySelector("[data-settings-panel=floating]").getAnimations().some(a=>a.playState==="running")'),true);
      await delay(250); await js('settings.motion=false;syncMotionState();document.querySelector("[data-settings-tab=general]").click();document.querySelector("[data-select-for=settingSort]").click()');
      assert.equal(await js('document.querySelector("[data-settings-panel=general]").getAnimations().some(a=>a.playState==="running")'),false);
      assert.equal(await js('document.querySelector(".setting-select-menu:not([hidden])").getAnimations().some(a=>a.playState==="running")'),false);
      await js('window.closeSettingsSelects();settings.motion=true;syncMotionState()');
    });
    await check('native preferences refresh the custom control and persist only when saved',async()=>{
      await js('window.desktop.saveCloseBehavior("tray").then(()=>settingsButton.click())');await delay(180);
      assert.equal(await js('document.querySelector("[data-select-for=settingCloseBehavior] .setting-select-value").textContent'),'最小化到系统托盘');
      await js('document.querySelector("[data-select-for=settingCloseBehavior]").click();document.querySelector("#settingCloseBehavior-listbox [role=option]:nth-child(3)").click()');
      assert.equal(await js('settingCloseBehavior.value'),'quit');assert.equal(await js('window.desktop.getCloseBehavior()'),'tray');
      await js('saveAllSettings()');assert.equal(await js('window.desktop.getCloseBehavior()'),'quit');
    });
    await js('document.querySelector("[data-view=all]").click();window.confirm=()=>{throw Error("native confirm must not be used")};void 0;');
    await check('in-app delete confirmation cancels safely, traps focus and escapes task names',async()=>{
      await js('void removeTask("case-0")');await delay(180);
      assert.equal(await js('document.querySelector("#confirmBackdrop").hidden'),false);assert.equal(await js('document.querySelector("#confirmTaskName").textContent'),tasks[0].name);assert.equal(await js('document.querySelector("#confirmTaskName").children.length'),0);
      assert.equal(await js('tasks[0].archivedAt'),undefined);assert.equal(await js('document.activeElement.id'),'confirmCancel');await capture('delete-confirmation');
      win.webContents.sendInputEvent({type:'keyDown',keyCode:'Tab',modifiers:['shift']});await delay(50);assert.ok(await js('document.querySelector("#confirmBackdrop").contains(document.activeElement)'));
      win.webContents.sendInputEvent({type:'keyDown',keyCode:'Escape'});await delay(180);assert.equal(await js('document.querySelector("#confirmBackdrop").hidden'),true);assert.equal(await js('tasks[0].archivedAt'),undefined);
    });
    await check('confirm delete moves to recycle bin; permanent deletion also uses in-app confirmation',async()=>{
      await js('void removeTask("case-0")');await delay(50);await js('document.getElementById("confirmAccept").click()');await delay(180);assert.ok(await js('tasks.find(t=>t.id==="case-0").deletedAt'));
      await js('void deleteArchived("case-0")');await delay(80);assert.equal(await js('document.getElementById("confirmBackdrop").hidden'),false);await js('confirmCancel.click()');await delay(100);assert.ok(await js('tasks.some(t=>t.id==="case-0")'));
      await js('void deleteArchived("case-0")');await delay(80);await js('confirmAccept.click()');await delay(150);assert.equal(await js('tasks.some(t=>t.id==="case-0")'),false);
    });
    await check('retention cleanup confirms inside the app and cancellation preserves records',async()=>{
      await js('tasks.push({id:"expired-case",name:"保留期测试",deadline:new Date().toISOString(),archivedAt:new Date(Date.now()-15*86400000).toISOString()});persistTasks();document.querySelector("[data-view=trash]").click();trashRetention.value="7";saveRetention.click()');await delay(100);
      assert.equal(await js('confirmBackdrop.hidden'),false);await js('confirmCancel.click()');await delay(100);assert.equal(await js('settings.retentionDays'),30);assert.equal(await js('tasks.some(t=>t.id==="expired-case")'),true);
      await js('saveRetention.click()');await delay(70);await js('confirmAccept.click()');await delay(130);assert.equal(await js('settings.retentionDays'),7);assert.equal(await js('tasks.some(t=>t.id==="expired-case")'),false);
    });
    await check('native settings remain disabled until delayed reads settle',async()=>{
      let releaseLoad;
      ipcMain.removeHandler('get-auto-start');
      ipcMain.handle('get-auto-start',()=>new Promise(resolve=>{releaseLoad=resolve;}));
      try {
        await js('settingsButton.click()');await delay(80);
        const blocked=await js('({select:settingCloseBehavior.disabled,trigger:document.querySelector("[data-select-for=settingCloseBehavior]").disabled,save:saveSettings.disabled})');
        assert.deepEqual(blocked,{select:true,trigger:true,save:true});
        await js('document.querySelector("[data-select-for=settingCloseBehavior]").click()');
        assert.equal(await js('document.querySelector("[data-select-for=settingCloseBehavior]").getAttribute("aria-expanded")'),'false');
        releaseLoad({enabled:false,supported:false});await delay(150);
        assert.equal(await js('settingCloseBehavior.disabled'),false);
        await js('document.querySelector("[data-select-for=settingCloseBehavior]").click();document.querySelector("#settingCloseBehavior-listbox [role=option]:nth-child(2)").click()');await delay(100);
        assert.equal(await js('settingCloseBehavior.value'),'tray');
      } finally {
        releaseLoad?.({enabled:false,supported:false});
        ipcMain.removeHandler('get-auto-start');ipcMain.handle('get-auto-start',()=>({enabled:false,supported:false}));
        await delay(130);
      }
    });
    await check('delayed saves freeze controls and reject overlapping save attempts',async()=>{
      const pending=[];let calls=0;
      ipcMain.removeHandler('save-floating-settings');
      ipcMain.handle('save-floating-settings',()=>{calls++;return new Promise(resolve=>pending.push(resolve));});
      const response={layer:'top',edgeCount:true,shortcut:'',error:''};
      try {
        await js('settingsButton.click()');await delay(120);
        await js('settingCompleted.checked=true;settingCompleted.click();window.pendingSaveOne=saveAllSettings();void 0');await delay(80);
        const state=await js('({field:settingCompleted.disabled,select:document.querySelector("[data-select-for=settingCloseBehavior]").disabled,save:saveSettings.disabled})');
        await js('settingCompleted.click();window.pendingSaveTwo=saveAllSettings();void 0');await delay(80);
        assert.deepEqual(state,{field:true,select:true,save:true});assert.equal(calls,1,'save must be serialized');assert.equal(await js('settingCompleted.checked'),false);
        pending.forEach(resolve=>resolve(response));await js('Promise.allSettled([window.pendingSaveOne,window.pendingSaveTwo]).then(()=>undefined)');
        assert.equal(await js('JSON.parse(localStorage.getItem(SETTINGS_KEY)).showCompleted'),false);assert.equal(await js('settingCompleted.checked'),false);assert.equal(await js('settingsDirty'),false);assert.equal(await js('settingCompleted.disabled'),false);
      } finally {
        pending.forEach(resolve=>resolve(response));ipcMain.removeHandler('save-floating-settings');ipcMain.handle('save-floating-settings',()=>response);await delay(120);
      }
    });
    if(output)fs.writeFileSync(path.join(output,'ui-report.json'),JSON.stringify({version:require('./package.json').version,userData:app.getPath('userData'),results},null,2));
    console.log(JSON.stringify(results,null,2)); app.exit(results.every(r=>r.passed)?0:1);
  } catch(error) {console.error(error);app.exit(1);}
});
