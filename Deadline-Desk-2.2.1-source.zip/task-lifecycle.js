(function(root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TaskLifecycle = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, () => {
  const COMPLETION_GRACE_MS = 24 * 60 * 60 * 1000;
  function completedAtMs(task) {
    const value = new Date(task?.completedAt).getTime();
    return Number.isFinite(value) ? value : NaN;
  }
  function isCompletionReady(task, now = Date.now()) {
    const completedAt = completedAtMs(task);
    return Boolean(task?.completed) && Number.isFinite(completedAt) && now - completedAt >= COMPLETION_GRACE_MS;
  }
  function shouldShowInDeadlineLists(task, now = Date.now()) {
    return Boolean(task) && !task.archivedAt && !isCompletionReady(task, now);
  }
  return { COMPLETION_GRACE_MS, completedAtMs, isCompletionReady, shouldShowInDeadlineLists };
});
