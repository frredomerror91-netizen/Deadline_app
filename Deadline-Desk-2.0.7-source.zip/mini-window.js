const { BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');
const { constrain, editorBounds } = require('./window-geometry');
module.exports = function setupMini(mainWindow, isFloating, onEditorSaved = () => {}, onEditorClosed = () => {}) {
  let hiddenBounds = null, menuOpen = false, outsideSince = 0;
  let slideTimer, slideTarget, edgeCount = true, motion = true;
  const sendEdge = edge => mainWindow.webContents.send('edge-state', { edge, count: edgeCount });
  function stopSlide() { clearInterval(slideTimer); slideTimer = null; slideTarget = null; }
  function slide(target, done) {
    stopSlide(); clearTimeout(moveTimer);
    const start = mainWindow.getBounds(), began = Date.now();
    if (!motion) { mainWindow.setBounds(target, false); done?.(); return; }
    slideTarget = target;
    slideTimer = setInterval(() => {
      const t = Math.min(1, (Date.now() - began) / 260), eased = 1 - (1-t)**3;
      mainWindow.setBounds({ ...target, x:Math.round(start.x+(target.x-start.x)*eased), y:Math.round(start.y+(target.y-start.y)*eased) }, false);
      if (t === 1) { stopSlide(); done?.(); }
    }, 16);
  }
  function reveal(animate = false) {
    if (mainWindow.isDestroyed()) return;
    if (!hiddenBounds) {
      if (!animate && slideTarget) { const target=slideTarget; stopSlide(); mainWindow.setBounds(target,false); }
      return;
    }
    const bounds = hiddenBounds; hiddenBounds = null; sendEdge('');
    const target = constrain(bounds, screen.getDisplayMatching(bounds).workArea, 0);
    if (animate) slide(target); else { stopSlide(); mainWindow.setBounds(target, false); }
    outsideSince = Date.now();
  }
  const hideTimer = setInterval(() => {
    if (mainWindow.isDestroyed() || !isFloating() || mainWindow.isMinimized()) return;
    if (locked || editor || menuOpen || dragOrigin || edgeOrigin || resizeTimer) { reveal(); outsideSince = Date.now(); return; }
    const b = mainWindow.getBounds(), cursor = screen.getCursorScreenPoint();
    const inside = cursor.x >= b.x - 2 && cursor.x <= b.x + b.width + 2 && cursor.y >= b.y - 2 && cursor.y <= b.y + b.height + 2;
    if (inside) { reveal(true); outsideSince = Date.now(); return; }
    if (hiddenBounds || slideTimer) return;
    if (!outsideSince) outsideSince = Date.now();
    if (Date.now() - outsideSince < 800) return;
    const display = screen.getDisplayMatching(b), area = display.workArea;
    const edge = Math.abs(b.x-area.x)<=2 ? 'left' : Math.abs(b.x+b.width-area.x-area.width)<=2 ? 'right' : Math.abs(b.y-area.y)<=2 ? 'top' : Math.abs(b.y+b.height-area.y-area.height)<=2 ? 'bottom' : '';
    if (!edge) return;
    const vertical = edge === 'left' || edge === 'right';
    const side = edge === 'left' ? area.x-1 : edge === 'right' ? area.x+area.width : edge === 'top' ? area.y-1 : area.y+area.height;
    if (screen.getAllDisplays().some(d => d.id !== display.id && (vertical
      ? side>=d.bounds.x && side<d.bounds.x+d.bounds.width && b.y<d.bounds.y+d.bounds.height && b.y+b.height>d.bounds.y
      : side>=d.bounds.y && side<d.bounds.y+d.bounds.height && b.x<d.bounds.x+d.bounds.width && b.x+b.width>d.bounds.x))) return;
    const peek = edgeCount ? (vertical ? 40 : 28) : 6;
    const target = { ...b };
    if (edge==='left') target.x=area.x-b.width+peek;
    if (edge==='right') target.x=area.x+area.width-peek;
    if (edge==='top') target.y=area.y-b.height+peek;
    if (edge==='bottom') target.y=area.y+area.height-peek;
    hiddenBounds = b;
    slide(target, () => { if (hiddenBounds) sendEdge(edgeCount ? edge : ''); });
  }, 50);
  let editor, locked = true, moveTimer, dragTimer, dragOrigin;
  let expanded = false, resizeTimer;
  let width = 360, expandedHeight = 360, compactHeight = 72, edgeTimer, edgeOrigin;
  function stopResize() { clearInterval(resizeTimer); resizeTimer = null; }
  const dimensions = () => ({ width, height: expanded ? expandedHeight : compactHeight });
  function stopEdge() { clearInterval(edgeTimer); edgeTimer = null; edgeOrigin = null; }
  function edgeStep() {
    if (!edgeOrigin || mainWindow.isDestroyed() || !isFloating() || locked) { stopEdge(); return; }
    const cursor = screen.getCursorScreenPoint();
    const { bounds: b, cursor: start, edge, area } = edgeOrigin;
    const dx = cursor.x - start.x, dy = cursor.y - start.y;
    let left = b.x, right = b.x + b.width, top = b.y, bottom = b.y + b.height;
    if (edge.includes('w')) left = Math.max(area.x, Math.min(b.x + dx, right - 360));
    if (edge.includes('e')) right = Math.min(area.x + area.width, Math.max(right + dx, left + 360));
    if (edge.includes('n')) top = Math.max(area.y, Math.min(b.y + dy, bottom - 72));
    if (edge.includes('s')) bottom = Math.min(area.y + area.height, Math.max(bottom + dy, top + 72));
    width = right - left;
    const height = bottom - top;
    const nextExpanded = height > 110;
    if (nextExpanded) expandedHeight = height;
    else compactHeight = height;
    if (expanded !== nextExpanded) {
      expanded = nextExpanded;
      mainWindow.webContents.send('mini-resized', expanded);
    }
    mainWindow.setBounds({ x: left, y: top, width, height }, false);
    positionEditor();
  }
  function stopDrag() { clearInterval(dragTimer); dragTimer = null; dragOrigin = null; }
  function dragStep() {
    if (!dragOrigin || mainWindow.isDestroyed() || !isFloating() || locked) { stopDrag(); return; }
    const cursor = screen.getCursorScreenPoint();
    const proposed = { ...dragOrigin.bounds, x: dragOrigin.bounds.x + cursor.x - dragOrigin.cursor.x, y: dragOrigin.bounds.y + cursor.y - dragOrigin.cursor.y };
    const next = constrain(proposed, screen.getDisplayNearestPoint(cursor).workArea, 0);
    // Use fixed logical dimensions, not rounded getBounds() results from each move.
    const current = mainWindow.getPosition();
    if (current[0] !== next.x || current[1] !== next.y) mainWindow.setBounds({ ...next, ...dimensions() }, false);
  }
  const fromMain = event => !mainWindow.isDestroyed() && event.sender === mainWindow.webContents;
  function positionEditor() { /* The editor is independently movable. */ }
  function settle() {
    if (mainWindow.isDestroyed() || !isFloating() || hiddenBounds || slideTimer || dragOrigin || resizeTimer || edgeOrigin) return;
    const bounds = mainWindow.getBounds();
    const size = dimensions();
    const next = constrain({ ...bounds, ...size }, screen.getDisplayMatching(bounds).workArea);
    if (next.x !== bounds.x || next.y !== bounds.y || Math.abs(bounds.width - size.width) > 1 || Math.abs(bounds.height - size.height) > 1) mainWindow.setBounds(next);
    positionEditor();
  }
  function closeEditor() { if (editor) editor.close(); }
  mainWindow.on('will-move', (event, bounds) => {
    if (!isFloating()) return;
    if (locked) { event.preventDefault(); return; }
    const next = constrain(bounds, screen.getDisplayMatching(bounds).workArea, 0);
    if (next.x !== bounds.x || next.y !== bounds.y) event.preventDefault();
  });
  mainWindow.on('move', () => { if (dragOrigin || slideTimer || hiddenBounds) return; clearTimeout(moveTimer); moveTimer = setTimeout(settle, 100); positionEditor(); });
  const lockHandler = (event, value) => {
    if (!fromMain(event) || typeof value !== 'boolean') return;
    reveal();
    locked = value;
    stopDrag(); stopEdge();
    mainWindow.setMovable(!isFloating() || !locked);

  };
  const openHandler = (event, standalone = false) => {
    if (event && !fromMain(event)) return;
    reveal();
    if (editor) { if (standalone) editor.setParentWindow(null); editor.show(); editor.focus(); return; }
    const bounds = mainWindow.getBounds();
    editor = new BrowserWindow({ ...editorBounds(bounds, screen.getDisplayMatching(bounds).workArea), minWidth: 360, minHeight: 200, parent: mainWindow, frame: false, thickFrame: false, resizable: false, movable: true, skipTaskbar: true, alwaysOnTop: true, show: false, transparent: false, hasShadow: false, backgroundColor: '#202c38', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false } });
    if (standalone) editor.setParentWindow(null);
    editor.loadFile(path.join(__dirname, 'add-task.html'));
    const created = editor;
    require('./window-motion')(created);
    created.once('ready-to-show', () => { if (editor === created && !created.isDestroyed()) { created.setBounds(editorBounds(mainWindow.getBounds(), screen.getDisplayMatching(mainWindow.getBounds()).workArea)); created.show(); } });
    editor.on('closed', () => { editor = null; onEditorClosed(); });
  };
  const editorSizeHandler = (event, expanded) => {
    if (!editor || event.sender !== editor.webContents || typeof expanded !== 'boolean') return;
    const bounds=editor.getBounds(), area=screen.getDisplayMatching(bounds).workArea;
    editor.setBounds(constrain({ ...bounds, width: Math.min(expanded ? 620 : 480, area.width), height: Math.min(expanded ? 460 : 270, area.height) }, area, 0));
  };
  const closeHandler = event => { if (editor && event.sender === editor.webContents) closeEditor(); };
  const changedHandler = event => {
    if (editor && event.sender === editor.webContents) {
      mainWindow.webContents.send('tasks-changed');
      onEditorSaved();
    }
  };
  const dragHandler = (event, active) => {
    if (!fromMain(event)) return;
    reveal();
    stopDrag();
    if (active === true && isFloating() && !locked) {
      stopEdge();
      finishResize();
      clearTimeout(moveTimer);
      dragOrigin = { cursor: screen.getCursorScreenPoint(), bounds: { ...mainWindow.getBounds(), ...dimensions() } };
      dragTimer = setInterval(dragStep, 8);
    } else settle();
  };
  function finishResize() {
    stopResize();
    if (mainWindow.isDestroyed() || !isFloating()) return;
    const bounds = mainWindow.getBounds();
    mainWindow.setBounds(constrain({ ...bounds, ...dimensions() }, screen.getDisplayMatching(bounds).workArea, 0), false);
    mainWindow.webContents.send('expanded-settled', expanded);
    positionEditor();
  }
  const expandHandler = (event, value, animate) => {
    if (!fromMain(event) || !isFloating() || typeof value !== 'boolean') return;
    reveal();
    stopDrag(); stopResize(); stopEdge(); clearTimeout(moveTimer);
    expanded = value;
    if (!expanded) compactHeight = 72;
    const start = mainWindow.getBounds();
    const target = constrain({ ...start, ...dimensions() }, screen.getDisplayMatching(start).workArea, 0);
    // Keep minimum size constant: changing it on each move can amplify DPI rounding.
    mainWindow.setMinimumSize(360, 72);
    if (animate === true && start.height !== target.height) {
      const began = Date.now();
      resizeTimer = setInterval(() => {
        const t = Math.min(1, (Date.now() - began) / 240);
        const eased = 1 - Math.pow(1 - t, 3);
        mainWindow.setBounds({ x: target.x, y: target.y, width, height: Math.round(start.height + (target.height - start.height) * eased) }, false);
        if (t === 1) finishResize();
      }, 16);
    } else finishResize();

  };
  const edgeHandler = (event, edge) => {
    if (!fromMain(event)) return;
    reveal();
    stopEdge();
    if (!isFloating() || locked) return;
    if (typeof edge !== 'string' || !/^(n|s|e|w|ne|nw|se|sw)$/.test(edge)) { settle(); return; }
    finishResize(); stopDrag(); clearTimeout(moveTimer);
    const bounds = mainWindow.getBounds();
    edgeOrigin = { edge, bounds: { ...bounds, ...dimensions() }, cursor: screen.getCursorScreenPoint(), area: screen.getDisplayMatching(bounds).workArea };
    edgeTimer = setInterval(edgeStep, 8);
  };
  const handlers = { 'editor-size': editorSizeHandler, 'edge-motion': (event, value) => { if (fromMain(event) && typeof value === 'boolean') motion=value; }, 'mini-resize': edgeHandler, 'set-expanded': expandHandler, 'mini-drag': dragHandler, 'set-locked': lockHandler, 'open-editor': openHandler, 'close-editor': closeHandler, 'tasks-changed': changedHandler };
  for (const [channel, handler] of Object.entries(handlers)) ipcMain.on(channel, handler);
  const displayChanged = () => { reveal(); settle(); };
  screen.on('display-metrics-changed', displayChanged);
  screen.on('display-removed', displayChanged);
  mainWindow.on('closed', () => {
    closeEditor();
    stopDrag(); stopResize(); stopEdge();
    stopSlide(); clearInterval(hideTimer);
    clearTimeout(moveTimer);
    for (const [channel, handler] of Object.entries(handlers)) ipcMain.removeListener(channel, handler);
    screen.removeListener('display-metrics-changed', displayChanged);
    screen.removeListener('display-removed', displayChanged);
  });
  mainWindow.on('blur', () => { stopDrag(); stopEdge(); });
  return { closeEditor, getEditor: () => editor, reveal, openEditor: standalone => openHandler(undefined, standalone), setEdgeCount(value) { if (edgeCount !== value) { reveal(); edgeCount=value; } }, setMenuOpen(value) { menuOpen = value; outsideSince = Date.now(); }, modeChanged() { if (isFloating()) locked = true; expanded = false; width = 360; compactHeight = 72; expandedHeight = 360; stopResize(); stopDrag(); stopEdge(); closeEditor(); mainWindow.setMovable(!isFloating() || !locked); settle(); } };
};

