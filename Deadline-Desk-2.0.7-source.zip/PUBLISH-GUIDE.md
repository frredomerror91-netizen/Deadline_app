# v2.0.7 GitHub 发布操作

## 上传附件

发布文件已集中在 `dist/github-v2.0.7/`，上传其中全部三个文件：

| 文件 | 用途 |
| --- | --- |
| `Deadline-Desk-2.0.7.exe` | Windows x64 免安装程序 |
| `Deadline-Desk-2.0.7.exe.sha256` | 自动更新与人工核验使用的 SHA-256 校验文件 |
| `Deadline-Desk-2.0.7-source.zip` | 本版源码、测试、依赖锁文件与说明 |

发布正文使用本目录的 `RELEASE-NOTES.md`。源码 ZIP 不包含个人数据、依赖、缓存和构建输出；保留已有用户数据，无需清空本机应用记录。

## 发布步骤

1. 确保 GitHub 仓库准备打标签的提交已包含 v2.0.7 对应源码。GitHub 自动生成的 Source code 附件来自标签提交，不能用额外上传的源码 ZIP 替代标签源码同步。
2. 打开 [新建 Release](https://github.com/frredomerror91-netizen/Deadline_app/releases/new)，标签填写 `v2.0.7`，Target 选择包含本版源码的分支或提交。若标签已存在，先核对对应提交。
3. 标题填写 `Deadline Desk v2.0.7`，描述粘贴 `RELEASE-NOTES.md` 正文。
4. 上传上表三个附件，保留原文件名，等待全部上传完成。
5. 不勾选预发布；若显示 Latest 选项，将其设为最新正式版，再点击 Publish release。
6. 检查 [最新正式版](https://github.com/frredomerror91-netizen/Deadline_app/releases/latest) 指向 v2.0.7，三个附件均可下载。重新下载 EXE 和校验文件核验；然后可从 v2.0.3 检测更新，验证线上升级。

本次仅整理本地文件，没有提交、推送、上传或发布。线上跨版本升级需实际发布后验证；其余验证与已知边界见发布正文。

## 下载文件核验

在下载目录运行：

```powershell
$actual = (Get-FileHash -LiteralPath '.\Deadline-Desk-2.0.7.exe' -Algorithm SHA256).Hash.ToLowerInvariant()
$expected = ((Get-Content -LiteralPath '.\Deadline-Desk-2.0.7.exe.sha256' -Raw).Trim() -split '\s+')[0]
if ($actual -ne $expected) { throw '校验失败' }
'SHA-256 校验通过'
```

