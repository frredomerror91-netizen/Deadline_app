const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { net } = require('electron');
const { REPOSITORY } = require('./updater');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
module.exports = async main => {
  main.show(); main.focus();
  const js = code => main.webContents.executeJavaScript(code);
  await js("setFloatingMode(false); setView('completed-month','完成清单'); completionDate.value='2026-09-21'; completionDate.onchange()");
  assert.equal(await js("document.getElementById('appVersion').textContent"), 'Deadline Desk · v'+require('./package.json').version);
  for (const fraction of [.1, .5, .92]) {
    const point = await js(`(() => { const r=document.getElementById('completionDateTrigger').getBoundingClientRect(); return {x:Math.round(r.left+r.width*${fraction}),y:Math.round(r.top+r.height/2)}; })()`);
    main.webContents.sendInputEvent({ type:'mouseDown', ...point, button:'left', clickCount:1 });
    main.webContents.sendInputEvent({ type:'mouseUp', ...point, button:'left', clickCount:1 });
    await delay(200);
    assert.equal(await js("document.querySelector('.date-picker').open && document.querySelector('.picker-time').hidden && getSelection().toString()==='' && completionDate.type==='hidden'"), true);
    await js("document.querySelector('.picker-cancel').click()");
  }
  await js("document.getElementById('completionDateTrigger').focus()");
  main.webContents.sendInputEvent({ type:'keyDown', keyCode:'Enter' }); main.webContents.sendInputEvent({ type:'char', keyCode:'\r' }); main.webContents.sendInputEvent({ type:'keyUp', keyCode:'Enter' }); await delay(100);
  assert.equal(await js("document.querySelector('.date-picker').open"), true);
  await js("document.querySelector('[aria-label=\"2026-09-15\"]').click(); document.querySelector('.picker-confirm').click()");
  assert.equal(await js('completionDate.value'), '2026-09-15');
  await js("document.getElementById('completionDateTrigger').click(); document.querySelector('[aria-label=\"2026-09-16\"]').click()");
  main.webContents.sendInputEvent({ type:'keyDown', keyCode:'Escape' }); main.webContents.sendInputEvent({ type:'keyUp', keyCode:'Escape' }); await delay(50);
  assert.equal(await js('completionDate.value'), '2026-09-15');
  assert.equal(await js("document.activeElement.id"), 'completionDateTrigger');
  const original = net.fetch;
  try {
    net.fetch = async () => new Response(JSON.stringify({ tag_name:'v2.0.8', assets:[{name:'Deadline-Desk-2.0.8.exe',size:100,digest:'sha256:'+'a'.repeat(64),browser_download_url:`https://github.com/${REPOSITORY}/releases/download/v2.0.8/Deadline-Desk-2.0.8.exe`}] }));
    await js("document.getElementById('checkUpdate').click()"); await delay(200);
    assert.equal(await js("document.getElementById('checkUpdate').textContent"), '更新至 v2.0.8');
    if (process.env.DDL_QA_DIR) {
      fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v203-main.png'), (await main.webContents.capturePage()).toPNG());
      await js("document.getElementById('completionDateTrigger').click()"); await delay(250);
      fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v203-picker.png'), (await main.webContents.capturePage()).toPNG());
      await js("document.querySelector('.picker-cancel').click()");
    }
    await js("document.getElementById('checkUpdate').click()"); await delay(100);
    assert.ok((await js("document.getElementById('updateStatus').textContent")).includes('免安装 EXE'));
    net.fetch = async () => new Response(JSON.stringify({tag_name:'v2.0.3'}));
    await js("document.getElementById('checkUpdate').click()"); await delay(100);
    assert.equal(await js("document.getElementById('updateStatus').textContent"), '当前已是最新版本');
    net.fetch = async () => { throw new Error('网络不可用'); };
    await js("document.getElementById('checkUpdate').click()"); await delay(100);
    assert.equal(await js("document.getElementById('checkUpdate').disabled"), false);
    assert.ok((await js("document.getElementById('updateStatus').textContent")).includes('网络不可用'));
  } finally { net.fetch = original; }
  console.log('PASS: v2.0.3 whole-field date clicks, keyboard/cancel, runtime version and updater UI states');
};

