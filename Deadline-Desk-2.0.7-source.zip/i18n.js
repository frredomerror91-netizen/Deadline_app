(() => {
  window.deskLocale = window.desktop?.language === 'en' ? 'en' : 'zh-CN';
  window.t = window.DeskI18n.createTranslator(window.deskLocale);
  document.documentElement.lang = window.deskLocale;
  // Only initial, authored markup is translated. Never translate user task data.
  window.translateStaticPage = () => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    for(const node of nodes) if(!node.parentElement.closest('script,style')) node.textContent=t(node.textContent);
    document.querySelectorAll('[title],[placeholder],[aria-label]').forEach(el=>{
      for(const attr of ['title','placeholder','aria-label']) if(el.hasAttribute(attr)) el.setAttribute(attr,t(el.getAttribute(attr)));
    });
    document.title=t(document.title);
  };
  let animation;
  const motion = () => { try { return JSON.parse(localStorage.getItem('deadline-desk.settings')||'{}').motion !== false && !matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return true; } };
  window.desktop?.onWindowMotion(async kind => {
    animation?.cancel();
    const el=document.querySelector('.app-shell') || document.body;
    if(motion()) {
      animation=el.animate(kind!=='open' ? [{opacity:1,transform:'scale(1)'},{opacity:0,transform:'translateY(22px) scale(.94)'}] : [{opacity:0,transform:'translateY(12px) scale(.97)'},{opacity:1,transform:'none'}], {duration:kind!=='open'?160:200,easing:'cubic-bezier(.2,.7,.2,1)'});
      const current = animation;
      let timer;
      try {
        // Occluded windows can pause compositor animations indefinitely.
        await Promise.race([current.finished, new Promise(resolve => { timer = setTimeout(resolve, 350); })]);
      } catch { return; }
      finally { clearTimeout(timer); }
      if (animation !== current) return;
      current.cancel();
    }
    if(kind==='minimize') window.desktop.finishMinimize();
    if(kind==='hide') window.desktop.finishHide();
  });
  document.addEventListener('DOMContentLoaded',()=>{
    const toggle=document.getElementById('languageToggle');
    if(toggle) {
      const label=window.deskLocale==='en' ? '切换为中文' : 'Switch to English';
      toggle.textContent=window.deskLocale==='en' ? '中' : 'EN';
      toggle.title=label; toggle.setAttribute('aria-label',label);
      toggle.addEventListener('click',async()=>{
        toggle.disabled=true;
        try { await window.desktop.saveLanguage(window.deskLocale==='en'?'zh-CN':'en'); location.reload(); }
        catch { toggle.disabled=false; alert(t('保存失败，请重试')); }
      });
    }
    const select=document.getElementById('settingLanguage'); if(!select)return;
    select.value=window.deskLocale;
    select.addEventListener('change',async event=>{
      event.stopPropagation(); select.disabled=true;
      try { await window.desktop.saveLanguage(select.value); sessionStorage.setItem('desk-reopen-settings','1'); location.reload(); }
      catch { select.disabled=false; select.value=window.deskLocale; alert(t('保存失败，请重试')); }
    });
    if(sessionStorage.getItem('desk-reopen-settings')) { sessionStorage.removeItem('desk-reopen-settings'); document.getElementById('settingsButton').click(); }
  });
})();
