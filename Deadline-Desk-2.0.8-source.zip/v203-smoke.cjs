const { app, BrowserWindow } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v203-smoke-')));
process.env.DDL_TEST = '1';
require('electron').net.fetch=async()=>new Response(JSON.stringify({tag_name:'v'+require('./package.json').version}));
require('./main');
setTimeout(() => { console.error('v2.0.3 smoke timed out'); app.exit(1); }, 30000).unref();
app.whenReady().then(async () => {
  try {
    const main = BrowserWindow.getAllWindows()[0];
    if (main.webContents.isLoading()) await new Promise(resolve => main.webContents.once('did-finish-load', resolve));
    await require('./v203-checks.cjs')(main); app.exit(0);
  } catch (error) { console.error(error); app.exit(1); }
});
