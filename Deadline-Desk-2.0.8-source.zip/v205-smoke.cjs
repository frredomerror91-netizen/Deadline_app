const { app, BrowserWindow, screen, Menu, dialog } = require('electron');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const profile=process.env.DDL_TEST_PROFILE || fs.mkdtempSync(path.join(app.getPath('temp'),'ddl-v205-'));
app.setPath('userData',profile);process.env.DDL_TEST='1';
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR,'main.js') : './main');
setTimeout(()=>{console.error('v205 timeout');app.exit(1);},60000).unref();
app.whenReady().then(async()=>{
 try {
  const main=BrowserWindow.getAllWindows()[0];
  const loaded=async win=>{if(win.webContents.isLoading())await new Promise(r=>win.webContents.once('did-finish-load',r));await delay(120);};
  await loaded(main);const js=s=>main.webContents.executeJavaScript(s);
  const capture=async(win,name)=>{if(process.env.DDL_QA_DIR)fs.writeFileSync(path.join(process.env.DDL_QA_DIR,name+'.png'),(await win.webContents.capturePage()).toPNG());};
  const size=(win,w,h)=>assert.ok(win.getSize().every((n,i)=>Math.abs(n-[w,h][i])<=3),JSON.stringify(win.getBounds()));
  if(process.env.DDL_VERIFY_LANGUAGE){assert.equal(await js('deskLocale'),'en');console.log('PASS English persisted across process restart');app.exit(0);return;}
  await js("tasks=[{id:'user-text',name:'今天 保存任务 深色模式 <test>',deadline:toDateTimeLocal(new Date(Date.now()+86400000))}];persistTasks();renderTasks()");
  for(const theme of ['dark','gray','light']){await js("document.getElementById('themeToggle').click()");assert.equal(await js('document.documentElement.dataset.theme'),theme);}
  await js('setFloatingMode(true)');await delay(250);
  size(main,360,72);const area=screen.getDisplayMatching(main.getBounds()).workArea;
  assert.equal(main.getBounds().x+main.getBounds().width,area.x+area.width);assert.equal(main.getBounds().y,area.y);
  assert.equal(main.isMovable(),false);assert.equal(await js('locked'),true);
  await js("document.getElementById('stripLockButton').click()");await delay(80);assert.equal(main.isMovable(),true);
  await js('setFloatingMode(false);setFloatingMode(true)');await delay(200);assert.equal(main.isMovable(),false);size(main,360,72);
  await capture(main,'v205-floating');
  app.emit('second-instance',{},['exe','--add-task']);await delay(250);
  let editor=BrowserWindow.getAllWindows().find(w=>w!==main);await loaded(editor);
  size(editor,480,270);const ea=screen.getDisplayMatching(editor.getBounds()).workArea,b=editor.getBounds();
  assert.ok(Math.abs(b.x+b.width/2-ea.x-ea.width/2)<=1);assert.ok(Math.abs(b.y+b.height/2-ea.y-ea.height/2)<=3);
  assert.equal(editor.isMovable(),true);
  const ej=s=>editor.webContents.executeJavaScript(s);
  assert.equal(await ej("getComputedStyle(document.querySelector('header')).webkitAppRegion"),'drag');
  assert.equal(await ej("getComputedStyle(document.getElementById('cancel')).webkitAppRegion"),'no-drag');
  assert.ok(await ej("document.querySelector('.submit-button').getBoundingClientRect().bottom<=innerHeight-8"),'Save fits compact editor');
  editor.setPosition(ea.x+40,ea.y+40);main.setPosition(area.x+80,area.y+80);await delay(300);
  assert.equal(editor.getBounds().x,ea.x+40,'Moving main does not reposition editor');
  await capture(editor,'v205-editor-zh');
  await ej("document.getElementById('deadlineTrigger').click()");await delay(250);size(editor,620,460);
  await capture(editor,'v205-picker-zh');
  assert.ok(await ej("document.querySelector('.date-picker').scrollHeight<=document.querySelector('.date-picker').clientHeight+2"),'Picker fits without scrolling');
  await ej("document.querySelector('.picker-cancel').click()");await delay(100);size(editor,480,270);
  await ej("nameInput.value='保存任务 English unchanged';document.getElementById('quickForm').requestSubmit()");await delay(150);
  assert.equal(await js("tasks.some(x=>x.name==='保存任务 English unchanged')"),true);
  await js("setFloatingMode(false);document.getElementById('settingsButton').click();document.getElementById('settingLanguage').value='en';document.getElementById('settingLanguage').dispatchEvent(new Event('change',{bubbles:true}))");await delay(500);await loaded(main);
  assert.equal(await js('deskLocale'),'en');assert.equal(await js('!settingsPage.hidden'),true);
  assert.equal(await js("document.getElementById('settingsTitle').textContent"),'Settings');
  assert.equal(await js("tasks[0].name"),'今天 保存任务 深色模式 <test>');
  assert.equal(JSON.parse(fs.readFileSync(path.join(profile,'language.json'))).language,'en');
  await capture(main,'v205-settings-en');
  await js("document.getElementById('settingsClose').click()");await capture(main,'v205-main-en');
  const chinese=await js("(()=>{const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT),a=[];while(w.nextNode()){const n=w.currentNode;if(!n.parentElement.closest('script,style,#languageToggle,.task-name,.strip-task-name,option[value=\"zh-CN\"]')&&/[\\p{Script=Han}]/u.test(n.textContent))a.push(n.textContent)}return a})()");assert.deepEqual(chinese,[],'No untranslated authored labels');
  await js("desktop.openEditor()");await delay(200);editor=BrowserWindow.getAllWindows().find(w=>w!==main);await loaded(editor);
  assert.equal(await ej("document.querySelector('header strong').textContent"),'New deadline');
  await capture(editor,'v205-editor-en');await ej("document.getElementById('deadlineTrigger').click()");await delay(250);await capture(editor,'v205-picker-en');
  assert.equal(await ej("document.querySelector('.picker-week').textContent"),'MoTuWeThFrSaSu');
  editor.close();await js('setFloatingMode(true)');await delay(200);
  let menu;const popup=Menu.prototype.popup;Menu.prototype.popup=function(o){menu=this;o.callback();};main.webContents.emit('context-menu');Menu.prototype.popup=popup;
  assert.equal(menu.items[0].label,'Add task');assert.equal(menu.items[1].label,'Window layer');
  let prompt;dialog.showMessageBox=async(_win,options)=>{prompt=options;return{response:2};};main.close();await delay(80);assert.equal(prompt.buttons[2],'Cancel');
  await js('setFloatingMode(false);settings.motion=true');main.webContents.send('window-opening');await delay(50);
  assert.equal(await js("document.querySelector('.app-shell').getAnimations().length>0"),true);await delay(220);
  await js("document.getElementById('windowMinimize').click()");await delay(60);assert.equal(main.isMinimized(),false);await delay(200);assert.equal(main.isMinimized(),true);
  main.restore();await delay(250);await js('settings.motion=false;localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings))');
  await js("document.getElementById('windowMinimize').click()");await delay(50);assert.equal(main.isMinimized(),true);main.restore();await delay(220);
  assert.equal(await js("document.querySelector('.app-shell').getAnimations().length"),0);
  // Switch back without altering data, then retain English for restart verification.
  await js("desktop.saveLanguage('zh-CN')");main.reload();await loaded(main);assert.equal(await js("document.querySelector('[data-view=all] span:nth-child(2)').textContent"),'总截止清单');
  await js("desktop.saveLanguage('en')");
  console.log('PASS v2.0.5 themes, compact centered movable editor, picker sizing, safe bilingual UI/native menus/persistence, floating defaults, window motion and disabled motion; profile='+profile);
  app.exit(0);
 }catch(e){console.error(e);app.exit(1);}
});

