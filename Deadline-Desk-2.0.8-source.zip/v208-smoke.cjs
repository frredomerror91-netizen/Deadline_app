const {app,BrowserWindow,screen}=require('electron');
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.setPath('userData',fs.mkdtempSync(path.join(app.getPath('temp'),'ddl-v208-')));process.env.DDL_TEST='1';
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR,'main.js') : './main');
setTimeout(()=>{console.error('v208 timeout');app.exit(1)},90000).unref();
app.whenReady().then(async()=>{try{
const win=BrowserWindow.getAllWindows()[0],js=s=>win.webContents.executeJavaScript(s);
while(win.webContents.isLoading())await delay(50);await delay(250);
assert.deepEqual(await js(`(()=>{const now=Date.now(),task=h=>({deadline:new Date(now+h*3600000).toISOString()});return [settings.urgentHours,settings.distantHours,isUrgent(task(48),now),isDistant(task(120),now),isDistant(task(120.01),now)];})()`),[48,120,true,false,true]);
await js(`document.getElementById('settingsButton').click(); settingUrgentHours.value=24;settingDistantHours.value=12;saveHighlightHours.click()`);
assert.deepEqual(await js('[settings.urgentHours,settings.distantHours]'),[48,120]);
await js('settingDistantHours.value=24;saveHighlightHours.click()');
assert.deepEqual(await js(`(()=>{const now=Date.now(),task=h=>({deadline:new Date(now+h*3600000).toISOString()});return [settings.urgentHours,settings.distantHours,isUrgent(task(24),now),isDistant(task(24),now),isUrgent(task(24.01),now),isDistant(task(24.01),now),isDistant({...task(25),completed:true},now),isUrgent(task(-1),now)];})()`),[24,24,true,false,false,true,false,true]);
for(const invalid of ['','-1','87601','abc']) {await js(`settingUrgentHours.value=${JSON.stringify(invalid)};saveHighlightHours.click()`);assert.equal(await js('settings.urgentHours'),24);}
await js(`settingUrgentHours.value=12;settingDistantHours.value=72;saveHighlightHours.click();tasks=[{id:'soon',name:'soon',deadline:new Date(Date.now()+3600000).toISOString()},{id:'far',name:'far',deadline:new Date(Date.now()+100*3600000).toISOString()}];persistTasks();renderTasks()`);
const reload=async action=>{const loaded=new Promise(r=>win.webContents.once('did-finish-load',r));await js(action);await loaded;await delay(250)};
await js(`setView('month',t('月截止清单'));monthFilter.value='2026-12';document.getElementById('settingsButton').click();selectSettingsTab('floating')`);
await reload(`languageToggle.click()`);
assert.deepEqual(await js(`[deskLocale,currentView,monthFilter.value,!settingsPage.hidden,document.querySelector('[data-settings-tab][aria-pressed="true"]').dataset.settingsTab,settings.urgentHours,settings.distantHours]`),['en','month','2026-12',true,'floating',12,72]);
await reload(`selectSettingsTab('general');settingLanguage.value='zh-CN';settingLanguage.dispatchEvent(new Event('change',{bubbles:true}))`);
assert.deepEqual(await js(`[deskLocale,!settingsPage.hidden,currentView]`),['zh-CN',true,'month']);
await js(`settingsPage.scrollTop=350`);await delay(100);
if(process.env.DDL_QA_DIR)fs.writeFileSync(path.join(process.env.DDL_QA_DIR,'v208-settings.png'),(await win.webContents.capturePage()).toPNG());
await js(`settingsClose.click();setView('completed-month',t('完成清单'));completionDate.value='2025-12-15';renderTasks()`);
await reload('languageToggle.click()');
assert.deepEqual(await js(`[currentView,completionDate.value,settingsPage.hidden]`),['completed-month','2025-12-15',true]);
await js(`settings.motion=true;setFloatingMode(true)`);await delay(40);
assert.equal(await js('appShell.classList.contains("is-floating")'),true);
assert.equal(await js('floatingStrip.getAnimations().length>0'),true);
await delay(250);
assert.equal(await js('document.querySelectorAll(".is-urgent.is-distant").length'),0);
await js('setFloatingMode(false);settings.motion=false');await js('setFloatingMode(true)');await delay(60);
assert.equal(await js('floatingStrip.getAnimations().length'),0);
const original=screen.getCursorScreenPoint,displays=screen.getAllDisplays,display=screen.getPrimaryDisplay(),a=display.workArea;
let cursor={x:a.x+a.width/2,y:a.y+a.height/2};screen.getCursorScreenPoint=()=>cursor;screen.getAllDisplays=()=>[display];
try {for(const side of ['left','right','top','bottom']) {
await js('locked=true;renderLock()');await delay(60);
const b={x:side==='left'?a.x:side==='right'?a.x+a.width-360:a.x+100,y:side==='top'?a.y:side==='bottom'?a.y+a.height-72:a.y+100,width:360,height:72};
win.setBounds(b);await js('locked=false;renderLock()');await delay(1300);
assert.equal(await js('document.body.dataset.edge'),side);
const hidden=win.getBounds(),vertical=side==='left'||side==='right';
cursor={x:vertical?(side==='left'?a.x+2:a.x+a.width-2):b.x+60,y:vertical?b.y+5:(side==='top'?a.y+2:a.y+a.height-2)};
await delay(400);assert.equal(await js('document.body.dataset.edge'),side,'Blank edge must not reveal '+side);
const badge=await js(`(()=>{const b=edgeBadge.getBoundingClientRect();return {x:b.x+b.width/2,y:b.y+b.height/2}})()`);
cursor={x:Math.round(hidden.x+badge.x),y:Math.round(hidden.y+badge.y)};await delay(400);
assert.equal(await js('document.body.dataset.edge'),'','Badge reveals '+side);
cursor={x:a.x+a.width/2,y:a.y+a.height/2};
}
} finally{screen.getCursorScreenPoint=original;screen.getAllDisplays=displays}
await js('locked=true;renderLock();setFloatingMode(false)');
console.log('PASS v208: thresholds/overlap/persistence, page and filter preservation for both language controls, animation and disabled motion, four-edge badge-only reveal');app.exit(0);
}catch(e){console.error(e);app.exit(1)}});
