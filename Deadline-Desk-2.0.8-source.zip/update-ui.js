(() => {
  const button = document.getElementById('checkUpdate');
  const label = document.getElementById('updateStatus');
  let state;
  function render(value) {
    state = value;
    document.getElementById('appVersion').textContent = `Deadline Desk · v${value.version}`;
    document.getElementById('settingsVersion').textContent = value.version;
    button.disabled = ['checking', 'downloading', 'preparing', 'installing'].includes(value.phase);
    button.textContent = value.phase === 'available' ? t`更新至 v${value.latest}`
      : value.phase === 'checking' ? t('正在检测…')
      : value.phase === 'downloading' ? t`正在下载 ${value.progress || 0}%`
      : value.phase === 'preparing' ? t('正在准备更新…')
      : value.phase === 'installing' ? t('正在重启更新…') : t('↻ 检测更新');
    label.textContent = t(value.message || '');
  }
  button.onclick = async () => {
    button.disabled = true;
    try { render(await (state?.phase === 'available' ? window.desktop.installUpdate() : window.desktop.checkUpdate())); }
    catch { label.textContent = t('更新服务暂不可用，请重试。'); button.disabled = false; }
  };
  window.desktop?.onUpdate(render);
  window.desktop?.updateStatus().then(render).catch(() => { label.textContent = t('无法读取版本信息'); });
})();
