const { app, BrowserWindow, Tray, net } = require('electron');
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const delay = ms => new Promise(r => setTimeout(r, ms));
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-v206-')));
process.env.DDL_TEST = '1';
let tray, checks = 0, mainShows = 0;
const tooltip = Tray.prototype.setToolTip;
Tray.prototype.setToolTip = function (...args) { tray = this; return tooltip.apply(this, args); };
net.fetch = async () => { checks++; return new Response(JSON.stringify({ tag_name: 'v'+require('./package.json').version })); };
app.on('browser-window-created', (_event, win) => {
  if (BrowserWindow.getAllWindows().length === 1) win.on('show', () => mainShows++);
});
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR, 'main.js') : './main');
setTimeout(() => { console.error('v206 timeout'); app.exit(1); }, 45000).unref();
app.whenReady().then(async () => {
  try {
    const main = BrowserWindow.getAllWindows()[0];
    const js = s => main.webContents.executeJavaScript(s);
    const waitFor = async check => { for (let n = 0; n < 100; n++) { if (await check()) return; await delay(30); } throw new Error('Condition timed out'); };
    await waitFor(() => !main.webContents.isLoading()); await delay(300);
    assert.equal(checks, 1, 'Exactly one automatic startup check');
    assert.equal((await js('desktop.updateStatus()')).phase, 'current');
    if (process.argv.includes('--add-task')) {
      assert.equal(mainShows, 0, 'Cold desktop launch never shows main');
      assert.equal(main.isVisible(), false);
    } else {
      await js('setFloatingMode(false)'); await delay(100);
      main.hide(); tray.emit('click');
      await waitFor(() => main.isVisible());
      assert.equal(await js("appShell.classList.contains('is-floating')"), true);
      assert.ok(Math.abs(main.getSize()[0] - 360) <= 2);
      main.hide(); tray.emit('click'); await waitFor(() => main.isVisible());
      assert.equal(await js("appShell.classList.contains('is-floating')"), true, 'Repeated clicks do not toggle to main');
      await js('setFloatingMode(false)'); await delay(100);
      app.emit('second-instance', {}, ['exe', '--add-task']);
    }
    const getEditor = () => BrowserWindow.getAllWindows().find(w => w !== main);
    await waitFor(() => getEditor() && !getEditor().webContents.isLoading() && getEditor().isVisible());
    assert.equal(main.isVisible(), false, 'Only editor visible');
    let editor = getEditor();
    const before = mainShows;
    app.emit('second-instance', {}, ['exe', '--add-task']); await delay(100);
    assert.equal(getEditor(), editor, 'Repeated add reuses editor'); assert.equal(mainShows, before);
    await editor.webContents.executeJavaScript("nameInput.value='desktop task';document.getElementById('quickForm').requestSubmit()");
    await waitFor(() => !getEditor() && main.isVisible());
    assert.equal(await js("appShell.classList.contains('is-floating')"), true, 'Save enters floating');
    assert.equal(await js("tasks.filter(t=>t.name==='desktop task').length"), 1);
    assert.equal(await js("localStorage.getItem(MODE_KEY)"), '1');
    await js('setFloatingMode(false)'); await delay(100);
    app.emit('second-instance', {}, ['exe', '--add-task']);
    await waitFor(() => getEditor()?.isVisible());
    getEditor().close(); await delay(100);
    assert.equal(main.isVisible(), false, 'Cancel does not show main or save');
    tray.emit('click'); await waitFor(() => main.isVisible());
    await js('setFloatingMode(false);setDeskTheme("gray")'); await delay(120);
    assert.equal(await js("getComputedStyle(document.documentElement).getPropertyValue('--surface').trim()"), '#adaeb0');
    if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'v206-gray.png'), (await main.webContents.capturePage()).toPNG());
    main.reload(); await waitFor(() => !main.webContents.isLoading()); await delay(200);
    assert.equal(checks, 1, 'Reload does not recheck');
    await js('desktop.checkUpdate()'); assert.equal(checks, 2, 'Manual check still works');
    // A cancelled desktop editor must not affect a later normal editor save.
    await js('desktop.openEditor()'); await waitFor(() => getEditor()?.isVisible());
    await getEditor().webContents.executeJavaScript("nameInput.value='normal task';document.getElementById('quickForm').requestSubmit()");
    await delay(200); assert.equal(await js("appShell.classList.contains('is-floating')"), false);
    console.log('PASS v2.0.6 startup/manual checks, tray floating, editor-only launch/save/cancel/reopen, gray theme');
    app.exit(0);
  } catch (error) { console.error(error); app.exit(1); }
});
