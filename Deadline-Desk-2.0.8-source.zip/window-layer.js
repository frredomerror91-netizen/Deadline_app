// Windows HWND_BOTTOM support, isolated from the renderer. No extra npm runtime.
const { spawn } = require('node:child_process');
module.exports = win => {
  if (process.platform !== 'win32') return { setBottom() {}, setDesktopProtection() {}, isDesktopActive: () => false, close() {} };
  let worker, desired = false, protect = false, ready = false, failed = false, desktopActive = false;
  const send = () => { if (worker && ready) worker.stdin.write((desired ? '1' : '0') + (protect ? '1' : '0') + '\n'); };
  const handle = win.getNativeWindowHandle().readBigUInt64LE().toString();
  const script = `Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Text;
public static class DeadlineWindowLayer {
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool IsChild(IntPtr parent, IntPtr child);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
  [DllImport("user32.dll")] static extern int GetClassName(IntPtr hwnd, StringBuilder name, int count);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hwnd);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int command);
  [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW")] static extern IntPtr GetWindowLongPtr(IntPtr hwnd, int index);
  [StructLayout(LayoutKind.Sequential)] struct Point { public int x, y; }
  [StructLayout(LayoutKind.Sequential)] struct Rect { public int left, top, right, bottom; }
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hwnd, out Rect rect);
  [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(Point point);
  [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
  static bool ShellClass(string name) { return name == "Progman" || name == "WorkerW" || name == "XamlExplorerHostIslandWindow"; }
  static volatile bool protectDesktop = false;
  static volatile bool bottom = false;
  static volatile bool alive = true;
  public static void Run(long handle) {
    var hwnd = new IntPtr(handle);
    var thread = new Thread(() => {
      bool raised = false, wasTop = false;
      while (alive && IsWindow(hwnd)) {
        var foreground = GetForegroundWindow();
        var name = new StringBuilder(256); GetClassName(foreground, name, name.Capacity);
        Rect rect; GetWindowRect(hwnd, out rect);
        var hit = GetAncestor(WindowFromPoint(new Point { x = (rect.left + rect.right) / 2, y = (rect.top + rect.bottom) / 2 }), 2);
        var hitName = new StringBuilder(256); GetClassName(hit, hitName, hitName.Capacity);
        bool desktop = ShellClass(name.ToString()) && (IsIconic(hwnd) || ShellClass(hitName.ToString()) || (raised && hit == hwnd));
        if (protectDesktop && desktop && (IsWindowVisible(hwnd) || IsIconic(hwnd))) {
          if (!raised) { wasTop = (GetWindowLongPtr(hwnd, -20).ToInt64() & 8) != 0; raised = true; Console.WriteLine("desktop-on"); Console.Out.Flush(); }
          if (IsIconic(hwnd)) ShowWindow(hwnd, 4); // SW_SHOWNOACTIVATE: never steal focus.
          SetWindowPos(hwnd, new IntPtr(-1), 0, 0, 0, 0, 0x0053);
        } else if (raised) {
          SetWindowPos(hwnd, new IntPtr(protectDesktop && wasTop ? -1 : -2), 0, 0, 0, 0, 0x0013);
          raised = false; Console.WriteLine("desktop-off"); Console.Out.Flush();
        }
        if (!raised && bottom && GetForegroundWindow() != hwnd && !IsChild(hwnd, GetForegroundWindow())) SetWindowPos(hwnd, new IntPtr(1), 0, 0, 0, 0, 0x0013);
        Thread.Sleep(200);
      }
    });
    thread.IsBackground = true; thread.Start();
    Console.WriteLine("ready"); Console.Out.Flush();
    string line;
    while ((line = Console.ReadLine()) != null) {
      bottom = line.Length > 0 && line[0] == '1';
      protectDesktop = line.Length > 1 && line[1] == '1';
      if (bottom && !protectDesktop) SetWindowPos(hwnd, new IntPtr(1), 0, 0, 0, 0, 0x0013);
    }
    alive = false;
  }
}
'@
[DeadlineWindowLayer]::Run(${handle})`;
  function start() {
    worker = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, stdio: ['pipe','pipe','pipe'] });
    worker.stdin.on('error', () => {});
    let output = '';
    worker.stdout.on('data', data => {
      output += data;
      let end;
      while ((end = output.indexOf('\n')) !== -1) {
        const line = output.slice(0,end).trim(); output = output.slice(end+1);
        if (line === 'ready') { ready = true; send(); }
        if (line === 'desktop-on') desktopActive = true;
        if (line === 'desktop-off') desktopActive = false;
      }
    });
    worker.stderr.on('data', data => console.error('Window layer:', String(data)));
    worker.on('error', error => { failed = true; console.error('Window layer:', error.message); });
    worker.on('exit', () => { ready = false; worker = null; failed = true; });
  }
  return {
    isDesktopActive: () => desktopActive,
    setBottom(value) {
      if (value === desired) return;
      desired = value;
      if (value && !worker && !failed) start();
      send();
    },
    setDesktopProtection(value) {
      if (protect === value) return;
      protect = value;
      if (value && !worker && !failed) start();
      send();
    },
    close() { if (worker) { worker.stdin.end(); worker.kill(); } }
  };
};
