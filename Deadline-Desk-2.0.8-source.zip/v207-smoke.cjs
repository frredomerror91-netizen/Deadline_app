const {app,BrowserWindow}=require('electron');
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {execFile}=require('child_process');
const ps=script=>new Promise((resolve,reject)=>execFile('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true},(e,out,err)=>e?reject(new Error(err||e.message)):resolve(out.trim())));
const delay=ms=>new Promise(r=>setTimeout(r,ms));
app.setPath('userData',fs.mkdtempSync(path.join(app.getPath('temp'),'ddl-v207-')));process.env.DDL_TEST='1';
require(process.env.DDL_RELEASE_ASAR ? path.join(process.env.DDL_RELEASE_ASAR,'main.js') : './main');
setTimeout(()=>{console.error('v207 timeout');app.exit(1)},90000).unref();
app.whenReady().then(async()=>{
let shellChanged=false;
try {
const win=BrowserWindow.getAllWindows()[0],js=s=>win.webContents.executeJavaScript(s);
while(win.webContents.isLoading())await delay(50);await delay(350);
assert.deepEqual(await js(`(()=>{const now=Date.now(),task=h=>({deadline:new Date(now+h*3600000).toISOString()});return [isDistant(task(120),now),isDistant(task(120.001),now),isDistant({...task(121),completed:true},now),isDistant(task(-1),now),isUrgent(task(48),now)];})()`),[false,true,false,false,true]);
await js(`settings.motion=false;tasks=[{id:'far',name:'六天后 / Six days',deadline:new Date(Date.now()+144*3600000).toISOString(),completed:false},{id:'soon',name:'明天提交',deadline:new Date(Date.now()+24*3600000).toISOString(),completed:false}];localStorage.setItem(STORAGE_KEY,JSON.stringify(tasks));renderTasks();setDeskTheme('gray');`);
assert.equal(await js(`document.querySelector('[data-task-id="far"]').classList.contains('is-distant')`),true);
assert.equal(await js(`getComputedStyle(document.querySelector('[data-task-id="far"] .task-name')).color`),'rgb(23, 98, 54)');
assert.equal(await js(`getComputedStyle(document.getElementById('languageToggle')).borderRadius`),'50%');
await delay(300);
if(process.env.DDL_QA_DIR)fs.writeFileSync(path.join(process.env.DDL_QA_DIR,'v207-gray.png'),(await win.webContents.capturePage()).toPNG());
await js(`document.getElementById('languageToggle').click()`);await delay(1000);
assert.equal(await js('deskLocale'),'en');assert.equal(await js('tasks[0].name'),'六天后 / Six days');
await js(`document.getElementById('languageToggle').click()`);await delay(1000);assert.equal(await js('deskLocale'),'zh-CN');
await js('setFloatingMode(true)');await delay(2000);
assert.equal(await js("document.querySelector('.preview-task[data-task-id=far]').classList.contains('is-distant')"),true);
await js("tasks.find(t=>t.id==='far').deadline=new Date(Date.now()+120*3600000-1000).toISOString()");await delay(1100);
assert.equal(await js("document.querySelector('.preview-task[data-task-id=far]').classList.contains('is-distant')"),false);
await js("tasks.find(t=>t.id==='far').deadline=new Date(Date.now()+144*3600000).toISOString();renderTasks()");
assert.equal(await js(`document.querySelector('.strip-task[data-task-id="far"]').classList.contains('is-distant')`),true);
const hwnd=win.getNativeWindowHandle().readBigUInt64LE().toString();
const inspect=`Add-Type -TypeDefinition @'
using System;using System.Text;using System.Runtime.InteropServices;
public static class Probe {
[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern int GetClassName(IntPtr h,StringBuilder b,int n);
[DllImport("user32.dll",EntryPoint="GetWindowLongPtrW")] public static extern IntPtr GetWindowLongPtr(IntPtr h,int i);
[StructLayout(LayoutKind.Sequential)] public struct Point { public int x,y; }
[StructLayout(LayoutKind.Sequential)] public struct Rect { public int left,top,right,bottom; }
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out Rect r);
[DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(Point p);
[DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h,uint f);
[DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h,int a,out int v,int s);
}
'@
$h=[IntPtr]::new(${hwnd});$b=[Text.StringBuilder]::new(256);[void][Probe]::GetClassName([Probe]::GetForegroundWindow(),$b,256);$cloak=0;[void][Probe]::DwmGetWindowAttribute($h,14,[ref]$cloak,4)
$r=[Probe+Rect]::new();[void][Probe]::GetWindowRect($h,[ref]$r);$point=[Probe+Point]::new();$point.x=($r.left+$r.right)/2;$point.y=($r.top+$r.bottom)/2
@{uncovered=([Probe]::GetAncestor([Probe]::WindowFromPoint($point),2)-eq $h);iconic=[Probe]::IsIconic($h);visible=[Probe]::IsWindowVisible($h);foreground=$b.ToString();top=(([Probe]::GetWindowLongPtr($h,-20).ToInt64()-band 8)-ne 0);cloaked=$cloak}|ConvertTo-Json -Compress`;
for(const layer of ['top','normal','bottom']) {
await js(`desktop.saveFloatingSettings({layer:'${layer}'})`);win.show();win.focus();await delay(300);
await ps('(New-Object -ComObject Shell.Application).ToggleDesktop()');shellChanged=true;await delay(1300);
const state=JSON.parse(await ps(inspect));console.log(layer,state);
assert.equal(state.iconic,false);assert.equal(state.visible,true);assert.equal(state.cloaked,0);assert.equal(state.uncovered,true,"Floating window actually visible above desktop");assert.ok(['WorkerW','Progman','XamlExplorerHostIslandWindow'].includes(state.foreground),'Does not steal desktop focus');
await ps('(New-Object -ComObject Shell.Application).UndoMinimizeALL()');shellChanged=false;win.focus();await delay(300);
}
win.hide();await ps('(New-Object -ComObject Shell.Application).ToggleDesktop()');shellChanged=true;await delay(800);assert.equal(win.isVisible(),false,'Explicit hide remains hidden');
await ps('(New-Object -ComObject Shell.Application).UndoMinimizeALL()');shellChanged=false;
win.show();await js('setFloatingMode(false)');await delay(350);
console.log('PASS v207: deadline boundaries, round language switch, native Show Desktop in all layers, focus and explicit hide');app.exit(0);
}catch(e){console.error(e);if(shellChanged)await ps('(New-Object -ComObject Shell.Application).UndoMinimizeALL()').catch(()=>{});app.exit(1)}
});

