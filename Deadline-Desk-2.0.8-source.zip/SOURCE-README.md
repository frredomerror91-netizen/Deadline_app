# Deadline Desk v2.0.8 源码 / Source

Windows x64 桌面截止时间管理工具，支持中英文界面、悬浮倒计时和本地数据保存。本源码包与 v2.0.8 EXE 对应，不含个人数据、依赖或构建产物。

```powershell
pnpm install --frozen-lockfile
pnpm start
pnpm test
pnpm run test:v208
pnpm run test:v207
pnpm run test:v206
pnpm exec electron v206-smoke.cjs --add-task
pnpm run test:v204
pnpm run test:v205
pnpm run test:i18n
pnpm run test:update
pnpm dist
pnpm run release
```

`pnpm run release` 会在 `dist/github-v2.0.8/` 整理 EXE、SHA-256 和源码 ZIP，并校验包内源码与 ZIP 内容。界面测试需要可交互的 Windows 桌面并使用隔离数据目录；正式应用数据位于 `%APPDATA%\deadline-desk`，升级时不要删除。

构建配置启用 Windows EXE 资源编辑，将产品名、文件说明、版本与应用图标写入程序；不会自动给程序添加数字签名。首次构建可能需要下载 electron-builder 工具。

English UI is selected in Settings → General → Language. User task names remain unchanged. The source ZIP excludes dependencies, caches, personal settings and generated builds.

