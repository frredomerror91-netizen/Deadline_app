// Frameless transparent windows do not receive Windows' normal frame animation.
// Animate their content, then delegate actual minimizing/restoring to Windows.
const { ipcMain } = require('electron');
module.exports = win => {
  const opening = () => { if (!win.isDestroyed()) win.webContents.send('window-opening'); };
  win.on('show', opening);
  win.on('restore', opening);
  const minimize = event => { if (!win.isDestroyed() && event.sender === win.webContents) win.minimize(); };
  const hide = event => { if (!win.isDestroyed() && event.sender === win.webContents) win.hide(); };
  ipcMain.on('finish-minimize', minimize);
  ipcMain.on('finish-hide', hide);
  win.on('closed', () => { ipcMain.removeListener('finish-minimize', minimize); ipcMain.removeListener('finish-hide', hide); });
};
