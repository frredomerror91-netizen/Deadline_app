// Run with Electron after packaging. Uses a fresh, isolated profile.
const { app, BrowserWindow } = require('electron');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const profile = fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-release-clean-'));
app.setPath('userData', profile);
process.env.DDL_TEST = '1';
const archive = process.env.DDL_RELEASE_ASAR || path.join(__dirname, 'dist/win-unpacked/resources/app.asar');
require(path.join(archive, 'main.js'));
setTimeout(() => { console.error('Clean release check timed out'); app.exit(1); }, 30000).unref();
app.whenReady().then(async () => {
  try {
    const main = BrowserWindow.getAllWindows()[0];
    if (main.webContents.isLoading()) await new Promise(resolve => main.webContents.once('did-finish-load', resolve));
    const state = await main.webContents.executeJavaScript(`({
      count: tasks.length,
      saved: localStorage.getItem('deadline-desk.tasks'),
      theme: document.documentElement.dataset.theme,
      floating: document.body.classList.contains('floating-mode')
    })`);
    assert.equal(state.count, 0, 'No active, completed or archived tasks');
    assert.ok(state.saved === null || state.saved === '[]', 'No seeded personal records');
    assert.equal(state.theme, 'light');
    assert.equal(state.floating, false);
    console.log('PASS: packaged application starts with zero tasks and default preferences in an isolated profile');
    app.exit(0);
  } catch (error) { console.error(error); app.exit(1); }
});
