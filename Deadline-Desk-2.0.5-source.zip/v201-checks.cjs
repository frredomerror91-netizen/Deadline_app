const assert = require('node:assert/strict');
const { BrowserWindow } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve => setTimeout(resolve,ms));
module.exports = async main => {
  const js = code => main.webContents.executeJavaScript(code);
  await js("setFloatingMode(false); settings.motion=false; settings.highlightUrgent=true; settings.showCompleted=false; setView('all','总截止清单'); openModal()");
  assert.equal(await js("(()=>{const d=new Date();d.setDate(d.getDate()+1);d.setHours(15,0,0,0);return taskDeadlineInput.value===toDateTimeLocal(d);})()"),true);
  await js("closeModal(); tasks=[{id:'urgent',name:'两天内任务',deadline:toDateTimeLocal(new Date(Date.now()+3600000))},{id:'far',name:'远期任务',deadline:'2035-01-01T15:00'},{id:'legacy',name:'历史完成任务',deadline:'2025-01-01T15:00',completed:true}]; renderTasks()");
  assert.deepEqual(await js("[isUrgent({deadline:new Date(172800000).toISOString()},0),isUrgent({deadline:new Date(172800001).toISOString()},0),isUrgent({deadline:new Date(-1).toISOString()},0),isUrgent({deadline:new Date(0).toISOString(),completed:true},0)]"),[true,false,true,false]);
  assert.equal(await js("document.querySelector('#taskList [data-task-id=urgent]').classList.contains('is-urgent') && document.querySelector('#stripPreview [data-task-id=urgent]').classList.contains('is-urgent')"),true);
  await js("document.getElementById('settingsButton').click(); document.getElementById('settingUrgent').checked=false; document.getElementById('settingUrgent').dispatchEvent(new Event('change',{bubbles:true}))");
  assert.equal(await js("!document.querySelector('.is-urgent') && JSON.parse(localStorage.getItem(SETTINGS_KEY)).highlightUrgent===false"),true);
  await js("document.getElementById('settingUrgent').checked=true; document.getElementById('settingUrgent').dispatchEvent(new Event('change',{bubbles:true})); document.getElementById('settingsClose').click(); document.querySelector('#taskList [data-complete=urgent]').click()");
  await delay(80);
  assert.equal(await js("!!tasks.find(t=>t.id==='urgent').completedAt && !!JSON.parse(localStorage.getItem(STORAGE_KEY)).find(t=>t.id==='urgent').completedAt"),true);
  for(const period of ['year','month','week','day']) {
    await js(`document.querySelector('[data-completion-period="${period}"]').click()`);
    assert.equal(await js("document.querySelectorAll('#taskList [data-task-id]').length"),1,'Archive ignores hide-completed preference');
  }
  await js("document.querySelector('#taskList [data-complete=urgent]').click()"); await delay(80);
  assert.equal(await js("!tasks.find(t=>t.id==='urgent').completedAt && document.querySelectorAll('#taskList [data-task-id]').length===0"),true);
  await js("tasks.push(...[['a','2026-01-01T00:00:00'],['b','2026-01-04T23:59:59'],['c','2026-01-05T00:00:00'],['d','2025-12-29T00:00:00'],['e','2027-01-01T00:00:00']].map(([id,date])=>({id,name:id,deadline:'2030-01-01T15:00',completed:true,completedAt:new Date(date).toISOString()})));completionDate.value='2026-01-01'");
  for(const [period,expected] of [['day',['a']],['week',['a','b','d']],['month',['a','b','c']],['year',['a','b','c']]]) {
    await js(`setView('completed-${period}','完成清单')`);
    assert.deepEqual(await js("getFilteredTasks().map(t=>t.id).sort()"),expected.sort(),period+' completion dates, not deadlines');
  }
  await js("setView('completed-month','月完成'); completionDate.value='2026-01-31';shiftCompletionPeriod(1)");
  assert.equal(await js('completionDate.value'),'2026-02-01');
  await js("setView('completed-all','全部完成')");
  assert.equal(await js("document.querySelector('#taskList [data-task-id=legacy] .task-meta').textContent.includes('完成时间未记录')"),true);
  await js("persistTasks(); setView('completed-week','周完成');completionDate.value='2026-01-01';completionDate.onchange()");
  await delay(150);
  if(process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR,'v201-completion.png'),(await main.webContents.capturePage()).toPNG());
  await js("setView('all','总截止清单'); desktop.openEditor()"); await delay(300);
  const editor=BrowserWindow.getAllWindows().find(w=>w!==main);
  assert.ok(editor);
  if(editor.webContents.isLoading()) await new Promise(resolve=>editor.webContents.once('did-finish-load',resolve));
  assert.equal(await editor.webContents.executeJavaScript("(()=>{const d=new Date();d.setDate(d.getDate()+1);d.setHours(15,0,0,0);return new Date(deadlineInput.value).getTime()===d.getTime();})()"),true);
  editor.close();
  const loaded=new Promise(resolve=>main.webContents.once('did-finish-load',resolve));main.webContents.reload();await loaded;
  assert.equal(await js("settings.highlightUrgent===true && !!tasks.find(t=>t.id==='a').completedAt"),true);
  console.log('PASS: v2.0.1 completion timestamps/undo/legacy/period boundaries, urgent threshold/settings/persistence, tomorrow 15:00 defaults in both editors');
};
