const {test}=require('node:test');const assert=require('node:assert/strict');const {createTranslator,messages}=require('./i18n-core');
test('English translation keeps dynamic task text unchanged',()=>{const t=createTranslator('en'),name='今天 保存任务 <b>English</b>';assert.equal(t`删除 ${name}`,'Delete '+name);assert.equal(t('截止：最近优先'),'Due: Soonest first');assert.equal(createTranslator('zh-CN')`删除 ${name}`,'删除 '+name);});
test('catalog phrases translate',()=>{const t=createTranslator('en');for(const key of Object.keys(messages))if(key!=='简体中文')assert.doesNotMatch(t(key),/[\p{Script=Han}]/u,key);});
