const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const REPOSITORY = 'frredomerror91-netizen/Deadline_app';
const MAX_DOWNLOAD = 500 * 1024 * 1024;
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

function versionParts(value) {
  const match = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(value);
  if (!match) throw new Error('发布版本号须为 v主版本.次版本.修订号');
  return match.slice(1).map(Number);
}
function isNewer(next, current) {
  const a = versionParts(next), b = versionParts(current);
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] > b[i];
  return false;
}
function assetURL(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.host !== 'github.com' || url.username || url.password ||
      !url.pathname.startsWith(`/${REPOSITORY}/releases/download/`)) throw new Error('更新文件地址不属于发布仓库');
  return url.href;
}
function selectRelease(release, current) {
  if (release.draft || release.prerelease) throw new Error('仅支持正式发布版本');
  versionParts(release.tag_name);
  if (!isNewer(release.tag_name, current)) return null;
  const version = release.tag_name.replace(/^v/, '');
  const name = `Deadline-Desk-${version}.exe`;
  const asset = release.assets?.find(item => item.name === name);
  if (!asset || !Number.isSafeInteger(asset.size) || asset.size < 2 || asset.size > MAX_DOWNLOAD)
    throw new Error(`新版缺少有效的 Windows 更新文件 ${name}`);
  const checksum = release.assets.find(item => item.name === `${name}.sha256`);
  const digest = /^sha256:[a-f0-9]{64}$/i.test(asset.digest || '') ? asset.digest.slice(7).toLowerCase() : null;
  if (!digest && !checksum) throw new Error('发布缺少 SHA-256 校验文件，暂不能更新');
  return { version, name, size: asset.size, url: assetURL(asset.browser_download_url), digest,
    checksumURL: checksum ? assetURL(checksum.browser_download_url) : null };
}
async function request(fetcher, url, timeout, consume) {
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), timeout);
  try {
    const response = await fetcher(url, { signal: abort.signal, headers: { 'User-Agent': 'Deadline-Desk', 'Accept': url.startsWith('https://api.github.com/') ? 'application/vnd.github+json' : 'application/octet-stream' } });
    if (!response.ok) {
      if (response.status === 404) throw new Error('尚未发布正式版本或更新文件不存在');
      if (response.status === 403 || response.status === 429) throw new Error('GitHub 请求受限，请稍后再试');
      throw new Error(`下载服务返回 ${response.status}`);
    }
    return await consume(response);
  } catch (error) {
    if (abort.signal.aborted) throw new Error('连接超时，请检查网络后重试');
    throw error;
  } finally { clearTimeout(timer); }
}
async function readText(response, limit) {
  const chunks = []; let size = 0;
  for await (const chunk of response.body) {
    size += chunk.length;
    if (size > limit) throw new Error('更新信息超过允许大小');
    chunks.push(Buffer.from(chunk));
  }
  return Buffer.concat(chunks).toString('utf8');
}
async function download(fetcher, release, file, progress) {
  let expected = release.digest;
  if (!expected) {
    const text = await request(fetcher, release.checksumURL, 30000, response => readText(response, 4096));
    const match = /^([a-f0-9]{64})(?:\s+\*?([^\r\n]+))?\s*$/i.exec(text.trim());
    if (!match || (match[2] && match[2].trim() !== release.name)) throw new Error('SHA-256 校验文件无效');
    expected = match[1].toLowerCase();
  }
  const hash = crypto.createHash('sha256'); let size = 0, header = Buffer.alloc(0), lastPercent = -1;
  const handle = await fs.open(file, 'wx');
  try {
    await request(fetcher, release.url, 15 * 60 * 1000, async response => {
      for await (const chunk of response.body) {
        const data = Buffer.from(chunk); size += data.length;
        if (size > release.size || size > MAX_DOWNLOAD) throw new Error('下载文件大小不符');
        if (header.length < 2) header = Buffer.concat([header, data]).subarray(0, 2);
        hash.update(data);
        // FileHandle.write can perform a partial write.
        let offset = 0;
        while (offset < data.length) { const result = await handle.write(data, offset, data.length - offset); offset += result.bytesWritten; }
        const percent = Math.floor(size / release.size * 100);
        if (percent !== lastPercent) { lastPercent = percent; progress(percent); }
      }
    });
    if (size !== release.size || header.toString() !== 'MZ' || hash.digest('hex') !== expected)
      throw new Error('更新文件校验失败，原程序未更改，请重新检测更新');
    await handle.sync();
    return expected;
  } finally { await handle.close(); }
}
async function launchHelper(job, config) {
  const script = path.join(job, 'update-helper.ps1');
  await fs.copyFile(path.join(__dirname, 'update-helper.ps1'), script);
  const configPath = path.join(job, 'update.json');
  await fs.writeFile(configPath, JSON.stringify(config), 'utf8');
  const powershell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const child = spawn(powershell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-ConfigPath', configPath],
    { detached: true, windowsHide: true, stdio: 'ignore' });
  await new Promise((resolve, reject) => { child.once('spawn', resolve); child.once('error', reject); });
  child.unref();
  for (let attempt = 0; attempt < 100; attempt++) {
    if (await fs.stat(path.join(job, 'ready')).catch(() => null)) return;
    const failed = await fs.readFile(path.join(job, 'error.txt'), 'utf8').catch(() => null);
    if (failed) throw new Error(`无法准备更新：${failed.trim()}`);
    await pause(100);
  }
  throw new Error('更新助手未就绪，原程序保持运行');
}
function createUpdater(options) {
  let release, busy = false;
  let state = { version: options.version, phase: 'idle', message: '' };
  const publish = patch => { state = { ...state, ...patch }; options.notify?.({ ...state }); return { ...state }; };
  const fail = error => publish({ phase: 'error', message: `更新未完成：${error.message || '请检查网络后重试'}` });
  return {
    async status() {
      if (state.phase === 'idle') {
        const previous = await fs.readFile(path.join(options.directory, 'last-result.json'), 'utf8').then(text => JSON.parse(text.replace(/^\uFEFF/, ''))).catch(() => null);
        if (previous) state.message = previous.ok ? `上次更新已完成，当前 v${options.version}` : '上次更新失败，已保留旧版程序，可重新检测更新。';
      }
      return { ...state };
    },
    async check() {
      if (busy) return { ...state };
      busy = true; release = null; publish({ phase: 'checking', message: '正在连接 GitHub…', latest: null });
      try {
        const result = await request(options.fetch, `https://api.github.com/repos/${REPOSITORY}/releases/latest`, 30000,
          async response => JSON.parse(await readText(response, 2 * 1024 * 1024)));
        release = selectRelease(result, options.version);
        return publish(release ? { phase: 'available', latest: release.version, message: `发现新版 v${release.version}，点击更新后自动下载并重启。` }
          : { phase: 'current', message: '当前已是最新版本' });
      } catch (error) { return fail(error); } finally { busy = false; }
    },
    async install() {
      if (busy || !release || state.phase !== 'available') return { ...state };
      if (!options.enabled || !options.target || !path.isAbsolute(options.target) || path.extname(options.target).toLowerCase() !== '.exe')
        return fail(new Error('请运行免安装 EXE 版本后更新'));
      busy = true; let job;
      try {
        await fs.mkdir(options.directory, { recursive: true });
        job = await fs.mkdtemp(path.join(options.directory, 'job-'));
        const file = path.join(job, 'download.exe');
        publish({ phase: 'downloading', progress: 0, message: '下载并校验后会自动重启，任务数据保留。' });
        const digest = await download(options.fetch, release, file, progress => publish({ progress }));
        await (options.launchHelper || launchHelper)(job, { target: options.target, source: file, digest, pid: process.pid,
          result: path.join(options.directory, 'last-result.json') });
        await fs.writeFile(path.join(job, 'commit'), 'commit');
        publish({ phase: 'installing', message: '更新已校验，正在重启…' });
        options.quit();
        return { ...state };
      } catch (error) {
        if (job) await fs.writeFile(path.join(job, 'cancelled'), 'cancelled').catch(() => {});
        if (job) await fs.unlink(path.join(job, 'download.exe')).catch(() => {});
        return fail(error);
      } finally { busy = false; }
    }
  };
}
module.exports = { createUpdater, selectRelease, isNewer, download, REPOSITORY };
