param([Parameter(Mandatory=$true)][string]$ConfigPath)
$ErrorActionPreference = 'Stop'
$job = Split-Path -LiteralPath $ConfigPath
$config = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
$target = [IO.Path]::GetFullPath($config.target)
$stage = $target + '.new-' + [Guid]::NewGuid().ToString('N')
$backup = $target + '.previous-' + [Guid]::NewGuid().ToString('N') + '.exe'
$moved = $false
try {
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Original executable not found' }
    Copy-Item -LiteralPath $config.source -Destination $stage
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($stage)
    try { $digest = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
    if ($digest -ne $config.digest) { throw 'Checksum mismatch' }
    [IO.File]::WriteAllText((Join-Path $job 'ready'), 'ready')
    $deadline = (Get-Date).AddSeconds(20)
    while (-not (Test-Path -LiteralPath (Join-Path $job 'commit'))) {
        if ((Test-Path -LiteralPath (Join-Path $job 'cancelled')) -or (Get-Date) -gt $deadline) { throw 'Update cancelled' }
        Start-Sleep -Milliseconds 100
    }
    # Do not touch the running executable until Electron has exited and cleaned up its desktop menu.
    $deadline = (Get-Date).AddSeconds(90)
    while (Get-Process -Id $config.pid -ErrorAction SilentlyContinue) {
        if ((Get-Date) -gt $deadline) { throw 'Timed out waiting for app exit' }
        Start-Sleep -Milliseconds 250
    }
    # The portable launcher can hold the executable briefly after Electron exits.
    for ($attempt = 0; $attempt -lt 120; $attempt++) {
        try { Move-Item -LiteralPath $target -Destination $backup; $moved = $true; break }
        catch { if ($attempt -eq 119) { throw }; Start-Sleep -Milliseconds 500 }
    }
    Move-Item -LiteralPath $stage -Destination $target
    $started = Start-Process -FilePath $target -WorkingDirectory (Split-Path -LiteralPath $target) -PassThru
    Start-Sleep -Seconds 5
    if ($started.HasExited -and $started.ExitCode -ne 0) { throw 'New executable failed to start' }
    @{ok=$true; backup=$backup} | ConvertTo-Json | Set-Content -LiteralPath $config.result -Encoding UTF8
    # Keep the old executable as a recovery copy; never touch task data.
    Remove-Item -LiteralPath $config.source -ErrorAction SilentlyContinue
} catch {
    $reason = $_.Exception.Message
    [IO.File]::WriteAllText((Join-Path $job 'error.txt'), $reason)
    if ($moved -and (Test-Path -LiteralPath $backup)) {
        try {
            if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target }
            Move-Item -LiteralPath $backup -Destination $target
            Start-Process -FilePath $target -WorkingDirectory (Split-Path -LiteralPath $target)
        } catch { $reason += '; Restore failed. Previous executable: ' + $backup }
    }
    @{ok=$false; error=$reason; backup=$backup} | ConvertTo-Json | Set-Content -LiteralPath $config.result -Encoding UTF8
} finally {
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -ErrorAction SilentlyContinue }
}
