// Windows HWND_BOTTOM support, isolated from the renderer. No extra npm runtime.
const { spawn } = require('node:child_process');
module.exports = win => {
  if (process.platform !== 'win32') return { setBottom() {}, close() {} };
  let worker, desired = false, ready = false, failed = false;
  const handle = win.getNativeWindowHandle().readBigUInt64LE().toString();
  const script = `Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Threading;
public static class DeadlineWindowLayer {
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool IsChild(IntPtr parent, IntPtr child);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
  static volatile bool bottom = false;
  static volatile bool alive = true;
  public static void Run(long handle) {
    var hwnd = new IntPtr(handle);
    var thread = new Thread(() => {
      while (alive && IsWindow(hwnd)) {
        if (bottom && GetForegroundWindow() != hwnd && !IsChild(hwnd, GetForegroundWindow())) SetWindowPos(hwnd, new IntPtr(1), 0, 0, 0, 0, 0x0013);
        Thread.Sleep(200);
      }
    });
    thread.IsBackground = true; thread.Start();
    Console.WriteLine("ready"); Console.Out.Flush();
    string line;
    while ((line = Console.ReadLine()) != null) {
      bottom = line == "1";
      if (bottom) SetWindowPos(hwnd, new IntPtr(1), 0, 0, 0, 0, 0x0013);
    }
    alive = false;
  }
}
'@
[DeadlineWindowLayer]::Run(${handle})`;
  function start() {
    worker = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, stdio: ['pipe','pipe','pipe'] });
    worker.stdin.on('error', () => {});
    let output = '';
    worker.stdout.on('data', data => {
      output += data;
      if (!ready && output.includes('ready')) { ready = true; worker.stdin.write(desired ? '1\n' : '0\n'); }
    });
    worker.stderr.on('data', data => console.error('Window layer:', String(data)));
    worker.on('error', error => { failed = true; console.error('Window layer:', error.message); });
    worker.on('exit', () => { ready = false; worker = null; failed = true; });
  }
  return {
    setBottom(value) {
      if (value === desired) return;
      desired = value;
      if (value && !worker && !failed) start();
      if (worker && ready) worker.stdin.write(value ? '1\n' : '0\n');
    },
    close() { if (worker) { worker.stdin.end(); worker.kill(); } }
  };
};
