const { ipcMain, Tray, Menu, dialog } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

const { t } = require('./native-language');
module.exports = ({ app, win, mini, floatingSettings, openDesktopEditor }) => {
  const file = path.join(app.getPath('userData'), 'window-settings.json');
  let behavior = 'ask', exiting = false, asking = false, tray;
  const valid = value => ['ask', 'tray', 'quit'].includes(value);
  try { const saved = JSON.parse(fs.readFileSync(file, 'utf8')); if (valid(saved.closeBehavior)) behavior = saved.closeBehavior; } catch {}
  function save(value) {
    if (!valid(value)) throw new Error(t('无效关闭行为'));
    fs.writeFileSync(file, JSON.stringify({ closeBehavior: value }));
    behavior = value;
    win.webContents.send('close-behavior-changed', behavior);
    return behavior;
  }
  function reveal() {
    floatingSettings.activate();
    mini.reveal(); win.restore(); win.show(); win.focus();
  }
  function dispatch(action) {
    reveal();
    if (action === 'settings') win.webContents.send('open-settings');
    if (action === 'layer') floatingSettings.showMenu();
    if (action === 'add') openDesktopEditor();
  }
  function ensureTray() {
    if (tray) return true;
    try {
      tray = new Tray(path.join(__dirname, 'app-icon.png'));
      tray.setToolTip('Deadline Desk');
      refreshTray();
      tray.on('click', reveal);
      return true;
    } catch (error) { console.error('Tray creation failed:', error); return false; }
  }
  function refreshTray() {
    if (!tray) return;
    tray.setContextMenu(Menu.buildFromTemplate([
        { label: t('显示窗口'), click: reveal },
        { label: t('设置'), click: () => dispatch('settings') },
        { label: t('改变图层优先级'), click: () => dispatch('layer') },
        { label: t('增加任务'), click: () => dispatch('add') },
        { type: 'separator' },
        { label: t('退出程序'), click: () => app.quit() }
      ]));
  }
  async function closeRequested(event) {
    if (exiting) return;
    event.preventDefault();
    if (asking) return;
    asking = true;
    try {
      let action = behavior;
      if (action === 'ask') {
        const answer = await dialog.showMessageBox(win, {
          type: 'question', title: t('关闭 Deadline Desk'), message: t('要退出程序，还是最小化到系统托盘？'),
          detail: t('系统托盘位于屏幕右下角，可点击图标恢复窗口。此选择也可在设置中修改。'),
          buttons: [t('最小化到系统托盘'), t('直接退出'), t('取消')], defaultId: 0, cancelId: 2,
          checkboxLabel: t('不再提示，记住本次选择'), checkboxChecked: false
        });
        if (answer.response === 2) return;
        action = answer.response === 0 ? 'tray' : 'quit';
        if (answer.checkboxChecked) save(action);
      }
      if (action === 'quit') app.quit();
      else if (ensureTray()) { mini.closeEditor(); win.webContents.send('window-hiding'); }
      else await dialog.showMessageBox(win, { type: 'error', message: t('无法创建系统托盘，窗口已保留。请重试或选择直接退出。') });
    } catch (error) {
      await dialog.showMessageBox(win, { type: 'error', message: t('无法保存关闭设置，窗口已保留。'), detail: error.message });
    } finally { asking = false; }
  }
  ipcMain.handle('get-close-behavior', event => event.sender === win.webContents ? behavior : null);
  ipcMain.handle('save-close-behavior', (event, value) => {
    if (event.sender !== win.webContents) throw new Error(t('无效请求'));
    return save(value);
  });
  win.on('close', closeRequested);
  ensureTray();
  function updateJumpList(program = process.execPath) {
    if (process.platform !== 'win32' || process.env.DDL_TEST) return;
    // Explorer adds these application tasks above its own pin/close commands.
    const argsPrefix = app.isPackaged ? '' : `"${app.getAppPath()}" `;
    const tasks = [[t('设置'), '--settings'], [t('改变图层优先级'), '--layer-menu'], [t('增加任务'), '--add-task']];
    const result = app.setJumpList([{ type: 'tasks', items: tasks.map(([title, flag]) => ({
      type: 'task', title, program, args: argsPrefix + flag,
      iconPath: program, iconIndex: 0, description: title + ' · Deadline Desk'
    })) }]);
    if (result !== 'ok') console.error(t('任务栏快捷菜单:'), result);
  }
  updateJumpList();
  win.on('closed', () => {
    tray?.destroy(); tray = null;
    ipcMain.removeHandler('get-close-behavior'); ipcMain.removeHandler('save-close-behavior');
  });
  return { dispatch, refreshLanguage() { refreshTray(); updateJumpList(); }, allowQuit() {
    exiting = true;
    // The portable runtime is deleted on exit: cold-start tasks use the durable EXE.
    updateJumpList(process.env.PORTABLE_EXECUTABLE_FILE || process.execPath);
  } };
};
