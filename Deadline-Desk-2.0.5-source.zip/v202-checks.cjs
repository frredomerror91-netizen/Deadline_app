const assert = require('node:assert/strict');
const { app } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const delay = ms => new Promise(resolve=>setTimeout(resolve,ms));
module.exports = async main => {
  const js=code=>main.webContents.executeJavaScript(code);
  const shot=async name=>{if(!process.env.DDL_QA_DIR)return;main.show();main.focus();await delay(350);let capture=await main.webContents.capturePage();if(capture.isEmpty()){await delay(500);capture=await main.webContents.capturePage();}assert.equal(capture.isEmpty(),false,'Screenshot must contain pixels');fs.writeFileSync(path.join(process.env.DDL_QA_DIR,name+'.png'),capture.toPNG());};
  await js("setFloatingMode(false); settings.motion=false; tasks=[]; persistTasks(); document.querySelector('[data-view=completed-all]').click()");
  assert.equal(await js("document.querySelectorAll('.sidebar [data-view^=completed-]').length"),1);
  assert.equal(await js("!document.getElementById('centerAddButton') && !document.getElementById('completionTabs').hidden"),true);
  for(const period of ['year','month','week','day']) {
    await js(`document.querySelector('[data-completion-period=${period}]').click()`);
    assert.equal(await js('currentView'), 'completed-'+period);
    assert.equal(await js("document.querySelector('.sidebar [data-view=completed-all]').classList.contains('is-active')"),true);
  }
  assert.equal(await js('settings.retentionDays'),30);
  await js("tasks=[{id:'done',name:'已完成论文，可归档',deadline:'2030-01-01T15:00',completed:true,completedAt:new Date().toISOString()},{id:'todo',name:'未完成任务',deadline:'2030-02-01T15:00'}]; persistTasks();setView('completed-all','完成清单');renderTasks()");
  await shot('v202-completed');
  const completedAt=await js("tasks[0].completedAt");
  await js("document.querySelector('[data-archive=done]').click()");
  assert.equal(await js("!!tasks[0].archivedAt && !document.querySelector('#taskList [data-task-id=done]') && !document.querySelector('#stripTasks [data-task-id=done]') && !document.getElementById('centerAddButton')"),true);
  await js("archiveTask('todo')");assert.equal(await js('!!tasks[1].archivedAt'),false);
  for(const view of ['all','today','week','month','completed-all']) { await js(`setView('${view}','清单')`);assert.equal(await js("getFilteredTasks().some(t=>t.id==='done')"),false); }
  await js("document.querySelector('[data-view=trash]').click()");
  assert.equal(await js("document.querySelectorAll('.trash-row').length"),1);
  await js("document.querySelector('[data-restore]').click()");
  assert.equal(await js("tasks[0].archivedAt===undefined && tasks[0].completed"),true);
  assert.equal(await js('tasks[0].completedAt'),completedAt);
  await js("archiveTask('done');settings.retentionDays=1825;tasks.push({id:'older',name:'上个月归档的记录',deadline:'2030-01-01T15:00',completed:true,archivedAt:new Date(new Date().getFullYear(),new Date().getMonth()-1,15).toISOString()});persistTasks();setView('trash','回收站')");
  assert.equal(await js("document.querySelectorAll('.trash-month').length"),2);
  await shot('v202-trash');
  await js("window.confirm=()=>false;document.getElementById('trashRetention').value='7';document.getElementById('saveRetention').click()");
  assert.equal(await js('settings.retentionDays'),1825,'Declining a destructive shorter period preserves records');
  await js("document.getElementById('trashRetention').value='custom'; document.getElementById('trashRetention').dispatchEvent(new Event('change'))");
  for(const value of ['0','1826','1.5','']) {
    await js(`document.getElementById('customRetention').value='${value}';document.getElementById('saveRetention').click()`);
    assert.equal(await js('settings.retentionDays'),1825);
    assert.equal(await js("document.getElementById('retentionStatus').textContent.includes('整数')"),true);
  }
  await js("window.confirm=()=>true;document.getElementById('customRetention').value='1';document.getElementById('saveRetention').click()");
  assert.equal(await js("settings.retentionDays===1 && !tasks.some(t=>t.id==='older') && JSON.parse(localStorage.getItem(SETTINGS_KEY)).retentionDays===1"),true);
  for(const days of [7,30,90]) { await js(`document.getElementById('trashRetention').value='${days}';document.getElementById('saveRetention').click()`);assert.equal(await js('settings.retentionDays'),days); }
  await js("settings.retentionDays=30;tasks=[{id:'expired',name:'到期',deadline:'2030-01-01T15:00',completed:true,archivedAt:new Date(1000000000).toISOString()},{id:'keep',name:'未到期',deadline:'2030-01-01T15:00',completed:true,archivedAt:new Date(1000000001).toISOString()},{id:'active',name:'正常任务',deadline:'2030-01-01T15:00'}];purgeExpired(1000000000+30*86400000)");
  assert.deepEqual(await js('tasks.map(t=>t.id)'),['keep','active'],'Exact expiration cutoff only removes archived tasks');
  await js("persistTasks();localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings))");
  const loaded=new Promise(resolve=>main.webContents.once('did-finish-load',resolve));main.webContents.reload();await loaded;
  assert.deepEqual(await js('tasks.map(t=>t.id)'),['active'],'Startup removes expired records');
  // Verify the actual Explorer registration key with an isolated name and command execution.
  const menuModule=require('./desktop-menu');
  const key='HKCU\\Software\\Classes\\Directory\\Background\\shell\\DeadlineDesk-QA-'+process.pid;
  const menu=menuModule(app,{key});
  try { await menu.install();assert.equal((await menu.status()).ok,true); }
  finally { await menu.remove(); }
  assert.equal((await menu.status()).ok,false);
  const commands=[];
  const defaultMenu=menuModule(app,{run:async (_exe,args)=>{commands.push(args);return {stdout:menuModule.launchCommand(app)};}});
  await defaultMenu.install();
  assert.ok(commands.some(args=>args[0]==='add' && args[1]==='HKCU\\Software\\Classes\\Directory\\Background\\shell\\DeadlineDesk\\command'));
  console.log('PASS: v2.0.2 single completion navigation, tabs/empty state, archive/restore/month grouping, retention validation/persistence/cutoff/startup cleanup, Explorer menu registration/status/cleanup');
};
