const { t } = require('./native-language');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const run = promisify(execFile);
const MENU_KEY = 'HKCU\\Software\\Classes\\Directory\\Background\\shell\\DeadlineDesk';
const LEGACY_KEY = 'HKCU\\Software\\Classes\\DesktopBackground\\Shell\\DeadlineDesk';

function launchCommand(app) {
  const executable = process.execPath;
  const quote = value => {
    if (/["\r\n]/.test(value)) throw new Error(t('应用路径包含无效字符'));
    return `"${value}"`;
  };
  return `${quote(executable)}${app.isPackaged ? '' : ' ' + quote(app.getAppPath())} --add-task`;
}

module.exports = function desktopMenu(app, options = {}) {
  const key = options.key || MENU_KEY;
  const execute = options.run || run;
  const reg = args => execute('reg.exe', args, { windowsHide: true });
  return {
    async install() {
      if (process.platform !== 'win32') return;
      try {
        await reg(['add', key, '/ve', '/t', 'REG_SZ', '/d', t('添加任务 · Deadline Desk'), '/f']);
        await reg(['add', key + '\\command', '/ve', '/t', 'REG_SZ', '/d', launchCommand(app), '/f']);
        // Directory Background is the Explorer desktop background registration point.
        // Remove the old path to avoid duplicate entries on systems supporting both.
        if (!options.key) await reg(['delete', LEGACY_KEY, '/f']).catch(() => {});
        const status = await this.status();
        if (!status.ok) throw new Error(status.error);
      } catch (error) {
        await this.remove().catch(() => {});
        throw error;
      }
    },
    async status() {
      if (process.platform !== 'win32') return { ok: false, error: t('仅 Windows 支持桌面右键菜单') };
      try {
        const { stdout } = await reg(['query', key + '\\command', '/ve']);
        return stdout.includes(launchCommand(app)) ? { ok:true } : { ok:false, error:t('菜单启动路径不匹配，请点击修复菜单') };
      } catch { return { ok:false, error:t('未找到桌面菜单注册项，请点击修复菜单') }; }
    },
    async remove() {
      if (process.platform === 'win32') await reg(['delete', key, '/f']);
    }
  };
};
module.exports.launchCommand = launchCommand;
