const { t } = require('./native-language');
const { ipcMain, Menu, globalShortcut } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

module.exports = (app, win, isFloating, mini) => {
  const file = path.join(app.getPath('userData'), 'floating-settings.json');
  let state = { layer: 'top', shortcut: '', edgeCount: true }, registered = '', menuOpen = false;
  try { state = { ...state, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch {}
  if (!['top', 'normal', 'bottom'].includes(state.layer)) state.layer = 'top';
  const layer = require('./window-layer')(win);
  let lastTop, interacting = false, blurTimer;
  function activate() { interacting = true; apply(); mini.reveal(); }
  function endInteraction() {
    clearTimeout(blurTimer);
    blurTimer = setTimeout(() => {
      if (win.isDestroyed()) return;
      const editor = mini.getEditor();
      if (win.isFocused() || editor?.isFocused() || menuOpen) return;
      interacting = false; apply();
    }, 180);
  }
  win.on('focus', activate);
  win.on('blur', endInteraction);
  app.on('browser-window-blur', endInteraction);
  function apply() {
    if (win.isDestroyed()) return;
    mini.setEdgeCount(state.edgeCount !== false);
    const top = isFloating() && (state.layer === 'top' || (state.layer === 'bottom' && interacting));
    if (lastTop !== top || win.isAlwaysOnTop() !== top) win.setAlwaysOnTop(top, 'floating');
    lastTop = top;
    layer.setBottom(isFloating() && state.layer === 'bottom' && !menuOpen && !interacting);
  }
  function register(value) {
    if (value === registered) return true;
    if (value) {
      try {
        if (!globalShortcut.register(value, () => {
          mini.reveal(); win.restore(); win.show();
          win.webContents.send('toggle-floating');
        })) return false;
      } catch { return false; }
    }
    if (registered) globalShortcut.unregister(registered);
    registered = value;
    return true;
  }
  let startupError = register(state.shortcut) ? '' : t('快捷键注册失败，可能已被占用，请重新设置。');
  const snapshot = () => ({ ...state, error: startupError });
  ipcMain.handle('get-floating-settings', event => event.sender === win.webContents ? snapshot() : null);
  ipcMain.handle('save-floating-settings', (event, patch) => {
    if (event.sender !== win.webContents || !patch || typeof patch !== 'object') return { error: t('无效设置') };
    const next = { ...state };
    if ('edgeCount' in patch) {
      if (typeof patch.edgeCount !== 'boolean') return { error: t('无效设置') };
      next.edgeCount = patch.edgeCount;
    }
    if ('layer' in patch) {
      if (!['top', 'normal', 'bottom'].includes(patch.layer)) return { error: t('无效图层') };
      next.layer = patch.layer;
    }
    if ('shortcut' in patch) {
      if (typeof patch.shortcut !== 'string' || patch.shortcut.length > 100) return { error: t('无效快捷键') };
      next.shortcut = patch.shortcut;
    }
    if (!register(next.shortcut)) return { ...state, error: t('快捷键不可用或已被其他程序占用，原设置已保留。') };
    try { fs.writeFileSync(file, JSON.stringify(next)); }
    catch { register(state.shortcut); return { ...state, error: t('无法保存设置，请重试。') }; }
    state = next; startupError = ''; apply();
    win.webContents.send('floating-settings-changed', snapshot());
    return snapshot();
  });
  function showMenu() {
    mini.reveal(); mini.setMenuOpen(true); menuOpen = true; apply();
    const menu = Menu.buildFromTemplate([
      { label: t('增加任务'), click: () => { activate(); win.show(); mini.openEditor(); } },
      { label: t('图层优先级'), submenu: [['top',t('总在最顶层')],['normal',t('普通图层')],['bottom',t('总在最底层')]].map(([layer,label]) => ({
        label, type: 'radio', checked: state.layer === layer, click: () => {
          try { fs.writeFileSync(file, JSON.stringify({ ...state, layer })); state.layer = layer; startupError = ''; }
          catch { startupError = t('无法保存图层设置，请重试。'); }
          apply(); win.webContents.send('floating-settings-changed', snapshot());
        }
      })) },
      { type: 'separator' },
      { label: t('悬浮窗设置…'), click: () => win.webContents.send('open-floating-settings') }
    ]);
    menu.popup({ window: win, callback: () => { menuOpen = false; mini.setMenuOpen(false); apply(); } });
  }
  win.webContents.on('context-menu', () => { if (isFloating()) showMenu(); });
  const timer = setInterval(() => { apply(); if (interacting && !win.isFocused() && !mini.getEditor()?.isFocused() && !menuOpen) endInteraction(); }, 500);
  win.on('closed', () => { clearInterval(timer); clearTimeout(blurTimer); app.removeListener('browser-window-blur', endInteraction); layer.close(); if (registered) globalShortcut.unregister(registered); ipcMain.removeHandler('get-floating-settings'); ipcMain.removeHandler('save-floating-settings'); });
  return { apply, activate, showMenu };
};
