const fs = require('node:fs');
const path = require('node:path');
let language = 'zh-CN';
const file = () => path.join(require('electron').app.getPath('userData'), 'language.json');
try { if (JSON.parse(fs.readFileSync(file(), 'utf8')).language === 'en') language = 'en'; } catch {}
const { createTranslator } = require('./i18n-core');
const translators = { en: createTranslator('en'), 'zh-CN': createTranslator('zh-CN') };
module.exports = {
  get: () => language,
  t: (...args) => translators[language](...args),
  save(value) {
    if (!['zh-CN','en'].includes(value)) throw new Error('Invalid language');
    fs.writeFileSync(file(), JSON.stringify({ language: value })); language = value;
  }
};
