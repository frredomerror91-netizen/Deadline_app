const { app, BrowserWindow, screen, ipcMain } = require('electron');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
app.setPath('userData', fs.mkdtempSync(path.join(app.getPath('temp'), 'ddl-smoke-')));
process.env.DDL_TEST='1';
require('./main');
const checkSize = (actual, expected) => assert.ok(actual.every((value, i) => Math.abs(value - expected[i]) <= 1), JSON.stringify(actual));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
setTimeout(() => { console.error('Smoke test timed out'); app.exit(1); }, 100000).unref();
app.whenReady().then(async () => {
  try {
    console.log('Smoke: loading main');
    const main = BrowserWindow.getAllWindows()[0];
    async function widenFloating() {
      checkSize(main.getSize(), [360, 72]);
      await main.webContents.executeJavaScript('locked=false; renderLock()'); await delay(80);
      main.center();
      const original=screen.getCursorScreenPoint;let cursor={x:500,y:500};screen.getCursorScreenPoint=()=>cursor;
      ipcMain.emit('mini-resize',{sender:main.webContents},'e');cursor={x:740,y:500};await delay(80);
      ipcMain.emit('mini-resize',{sender:main.webContents},null);screen.getCursorScreenPoint=original;await delay(100);
    }
    main.show(); main.focus();
    if (main.webContents.isLoading()) await new Promise(resolve => main.webContents.once('did-finish-load', resolve));
    await main.webContents.executeJavaScript("document.getElementById('themeToggle').click()");
    console.log('Smoke: theme selected');
    assert.equal(await main.webContents.executeJavaScript("document.documentElement.dataset.theme"), 'dark');
    const reloaded = new Promise(resolve => main.webContents.once('did-finish-load', resolve));
    main.webContents.reload();
    await reloaded;
    console.log('Smoke: reloaded');
    assert.equal(await main.webContents.executeJavaScript(`(() => {
      const date = document.getElementById('todayLabel').getBoundingClientRect();
      const controls = document.querySelector('.window-controls').getBoundingClientRect();
      return date.right + 8 <= controls.left;
    })()`), true, 'Date must not overlap window controls');
    assert.equal(await main.webContents.executeJavaScript(`['#addButton svg', '#centerAddButton svg'].every(selector => {
      const icon = document.querySelector(selector), button = icon.closest('button');
      const a = icon.getBoundingClientRect(), b = button.getBoundingClientRect();
      return Math.abs((a.top + a.bottom - b.top - b.bottom) / 2) < 1;
    })`), true, 'Plus icons must be vertically centered');
    await main.webContents.executeJavaScript("document.getElementById('sortButton').click()");
    assert.equal(await main.webContents.executeJavaScript("document.getElementById('sortLabel').textContent"), '截止：最远优先');
    await main.webContents.executeJavaScript("document.getElementById('sortButton').click()");
    if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-empty.png'), (await main.webContents.capturePage()).toPNG());
    assert.equal(await main.webContents.executeJavaScript("document.documentElement.dataset.theme"), 'dark');
    await main.webContents.executeJavaScript(`tasks = [
      {id:'late',name:'稍后截止',deadline:toDateTimeLocal(new Date(Date.now()+172800000))},
      {id:'near',name:'最近截止',deadline:toDateTimeLocal(new Date(Date.now()+86400000))},
      {id:'past',name:'逾期未完成',deadline:toDateTimeLocal(new Date(Date.now()-86400000))},
      {id:'done',name:'已完成示例',deadline:toDateTimeLocal(new Date()),completed:true},
      {id:'other',name:'其他月份',deadline:'2030-01-15T12:00'}
    ]; persistTasks(); renderTasks();`);
    assert.equal(await main.webContents.executeJavaScript("document.querySelector('#stripTasks .strip-task-name').textContent"), '逾期未完成');
    await main.webContents.executeJavaScript("document.querySelector('#stripTasks [data-complete=past]').click()");
    assert.equal(await main.webContents.executeJavaScript("completing && document.querySelector('#stripTasks [data-complete=past]').disabled"), true);
    assert.equal(await main.webContents.executeJavaScript(`[...document.querySelectorAll('[data-task-id]')].flatMap(row => row.getAnimations()).every(animation => animation.effect.getKeyframes().every(frame => !('backgroundColor' in frame) && !('color' in frame)))`), true, 'Completion animation must not change color');
    for (let i = 0; i < 30 && await main.webContents.executeJavaScript('completing'); i++) await delay(100);
    assert.equal(await main.webContents.executeJavaScript("document.querySelector('#stripTasks .strip-task-name').textContent"), '最近截止');
    assert.ok(await main.webContents.executeJavaScript("JSON.parse(localStorage.getItem(STORAGE_KEY)).find(t=>t.id==='past').completed"));
    await main.webContents.executeJavaScript("setView('month','月截止清单'); monthFilter.value='2030-01'; monthFilter.dispatchEvent(new Event('change'))");
    assert.equal(await main.webContents.executeJavaScript("document.querySelectorAll('#taskList .task-row').length"), 1);
    assert.equal(await main.webContents.executeJavaScript("document.querySelector('#taskList .task-name').textContent"), '其他月份');
    await main.webContents.executeJavaScript("setView('all','总截止清单'); sortAscending=false; renderTasks()");
    assert.equal(await main.webContents.executeJavaScript("document.querySelector('#taskList .task-row').classList.contains('is-completed')"), false);
    await main.webContents.executeJavaScript("openModal(); document.getElementById('taskDeadlineTrigger').click()");
    assert.equal(await main.webContents.executeJavaScript("document.querySelector('.date-picker').open && taskDeadlineInput.type === 'hidden'"), true);
    await main.webContents.executeJavaScript("document.querySelector('.clock-hour').value='15'; document.querySelector('.clock-minute').value='42'; document.querySelector('.picker-confirm').click()");
    assert.equal(await main.webContents.executeJavaScript("taskDeadlineInput.value.endsWith('T15:42')"), true);
    const fieldPoint=await main.webContents.executeJavaScript("(()=>{const r=document.getElementById('taskDeadlineTrigger').getBoundingClientRect();return {x:Math.round(r.left+10),y:Math.round(r.top+r.height/2)}})()");
    main.webContents.sendInputEvent({type:'mouseDown',...fieldPoint,button:'left',clickCount:1});main.webContents.sendInputEvent({type:'mouseUp',...fieldPoint,button:'left',clickCount:1});await delay(250);
    assert.equal(await main.webContents.executeJavaScript("document.querySelector('.date-picker').open && getSelection().toString()===''"),true);
    if(process.env.DDL_QA_DIR)fs.writeFileSync(path.join(process.env.DDL_QA_DIR,'ddl-main-picker.png'),(await main.webContents.capturePage()).toPNG());
    main.webContents.sendInputEvent({type:'keyDown',keyCode:'Escape'}); main.webContents.sendInputEvent({type:'keyUp',keyCode:'Escape'});await delay(50);
    assert.equal(await main.webContents.executeJavaScript("!document.querySelector('.date-picker').open && !modalBackdrop.hidden"),true);
    await main.webContents.executeJavaScript("closeModal(); setView('month','月截止清单')"); await delay(30);
    await main.webContents.executeJavaScript("document.getElementById('monthFilterTrigger').click(); document.querySelector('.picker-year').value='2030'; document.querySelector('.picker-year').dispatchEvent(new Event('change')); document.querySelector('.picker-grid button').click(); document.querySelector('.picker-confirm').click()");
    assert.equal(await main.webContents.executeJavaScript("monthFilter.value"), '2030-01');
    await main.webContents.executeJavaScript("setView('all','总截止清单'); document.getElementById('windowMaximize').click()"); await delay(200);
    assert.equal(await main.webContents.executeJavaScript("document.getElementById('windowMaximize').title === '还原窗口'"), true);
    checkSize(main.getSize(), Object.values(screen.getDisplayMatching(main.getBounds()).workArea).slice(2));
    await main.webContents.executeJavaScript("document.getElementById('windowMaximize').click()"); await delay(200);
    assert.equal(await main.webContents.executeJavaScript("document.getElementById('windowMaximize').title === '还原窗口'"), false);
    await main.webContents.executeJavaScript("document.getElementById('floatingToggle').click()");
    await delay(300);
    await widenFloating();
    checkSize(main.getSize(), [600, 72]);
    assert.equal(await main.webContents.executeJavaScript("document.getElementById('stripDetails').hidden"), true);
    assert.equal(await main.webContents.executeJavaScript("document.querySelectorAll('#stripPreview .preview-task').length"), 2);
    assert.equal(await main.webContents.executeJavaScript("[...document.querySelectorAll('#stripPreview .strip-task-time')].every(el => /截止 \\d{4}\\/\\d+\\/\\d+ \\d{2}:\\d{2}/.test(el.textContent))"), true);
    const savedCursor = screen.getCursorScreenPoint;
    const origin = main.getBounds();
    let dragCursor = { x: origin.x + 50, y: origin.y + 20 };
    screen.getCursorScreenPoint = () => dragCursor;
    ipcMain.emit('mini-drag', { sender: main.webContents }, true);
    for (let i = 0; i < 60; i++) {
      dragCursor = { x: origin.x + 50 + i * 3, y: origin.y + 20 + (i % 10) * 3 };
      await delay(12);
      checkSize(main.getSize(), [600, 72]);
    }
    ipcMain.emit('mini-drag', { sender: main.webContents }, false);
    screen.getCursorScreenPoint = savedCursor;
    await main.webContents.executeJavaScript('setExpanded(true)');
    await delay(80);
    assert.ok(main.getSize()[1] > 72 && main.getSize()[1] < 360, 'Expansion must have intermediate height');
    await main.webContents.executeJavaScript('setExpanded(false)');
    await delay(350);
    checkSize(main.getSize(), [600, 72]);
    await main.webContents.executeJavaScript(`window.qaTasks = tasks; tasks = [{id:'layout', name:'高电第八章作业', deadline:'2026-09-24T21:00'}]; renderTasks();`);
    await delay(100);
    assert.equal(await main.webContents.executeJavaScript(`(() => {
      const name = document.querySelector('.preview-task .strip-task-name');
      const time = document.querySelector('.preview-task .task-countdown');
      return parseFloat(getComputedStyle(name).fontSize) >= 14 && time.getBoundingClientRect().left >= name.getBoundingClientRect().right;
    })()`), true, 'Single task must use horizontal space with larger type');
    if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-single.png'), (await main.webContents.capturePage()).toPNG());
    await main.webContents.executeJavaScript('tasks = window.qaTasks; delete window.qaTasks; renderTasks();');
    assert.equal(await main.webContents.executeJavaScript("document.getElementById('stripDetails').hidden"), true);
    if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-compact.png'), (await main.webContents.capturePage()).toPNG());
    for (let i = 0; i < 3; i++) {
      await main.webContents.executeJavaScript("setExpanded(true)"); await delay(350);
      checkSize(main.getSize(), [600, 360]);
      await main.webContents.executeJavaScript("setExpanded(false)"); await delay(350);
      checkSize(main.getSize(), [600, 72]);
    }
    await main.webContents.executeJavaScript("setExpanded(true)"); await delay(350);
    const miniSize = main.getSize();
    const bitmap = (await main.webContents.capturePage()).toBitmap();
    assert.equal(bitmap[3], 0, 'Floating corner must be transparent');
    assert.ok(Math.abs(miniSize[0] - 600) <= 4 && Math.abs(miniSize[1] - 360) <= 4, JSON.stringify(miniSize));
    assert.equal(main.isAlwaysOnTop(), true);
    const layout = await main.webContents.executeJavaScript("({bottom:document.getElementById('floatingStrip').getBoundingClientRect().bottom,height:innerHeight,css:getComputedStyle(document.getElementById('floatingStrip')).minHeight})");
    assert.ok(layout.bottom <= layout.height + 1, JSON.stringify(layout));
    await main.webContents.executeJavaScript("document.getElementById('stripLockButton').click()");
    await delay(100);
    assert.equal(main.isMovable(), false);
    await main.webContents.executeJavaScript("document.getElementById('stripAddButton').click()");
    await delay(600);
    const editor = BrowserWindow.getAllWindows().find(w => w !== main);
    assert.ok(editor);
    if (editor.webContents.isLoading()) await new Promise(resolve => editor.webContents.once('did-finish-load', resolve));
    assert.equal(await editor.webContents.executeJavaScript("document.documentElement.dataset.theme"), 'dark');
    if (process.env.DDL_QA_DIR) {
      fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-editor-dark.png'), (await editor.webContents.capturePage()).toPNG());
      fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-mini-dark.png'), (await main.webContents.capturePage()).toPNG());
    }
    await main.webContents.executeJavaScript("document.getElementById('themeToggle').click()");
    await delay(100);
    assert.equal(await editor.webContents.executeJavaScript("document.documentElement.dataset.theme"), 'gray');
    assert.ok(Math.abs(main.getSize()[0] - 600) <= 1 && Math.abs(main.getSize()[1] - 360) <= 1, JSON.stringify(main.getSize()));
    assert.equal(editor.isMovable(), true);
    await editor.webContents.executeJavaScript("document.getElementById('deadlineTrigger').click()");
    assert.equal(await editor.webContents.executeJavaScript("document.querySelector('.date-picker').open"), true);
    await delay(250);
    if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-picker.png'), (await editor.webContents.capturePage()).toPNG());
    await editor.webContents.executeJavaScript("document.querySelector('.picker-confirm').click()");
    await editor.webContents.executeJavaScript("document.getElementById('name').value='测试 DDL'; document.getElementById('quickForm').requestSubmit()");
    await delay(300);
    assert.equal(BrowserWindow.getAllWindows().length, 1);
    assert.ok(await main.webContents.executeJavaScript("document.getElementById('stripTasks').textContent.includes('测试 DDL')"));
    await main.webContents.executeJavaScript("document.getElementById('stripLockButton').click()");
    await delay(100);
    const area = screen.getDisplayMatching(main.getBounds()).workArea;
    main.setPosition(area.x + area.width - miniSize[0] + 5, area.y + 100);
    await delay(350);
    assert.ok(Math.abs(main.getBounds().x + main.getBounds().width - area.x - area.width) <= 1);
    const originalCursor = screen.getCursorScreenPoint;
    let cursor = { x: area.x + area.width - 150, y: area.y + 120 };
    screen.getCursorScreenPoint = () => cursor;
    ipcMain.emit('mini-drag', { sender: main.webContents }, true);
    for (let i = 0; i < 15; i++) {
      cursor = { ...cursor, x: cursor.x + 8 };
      await delay(25);
      checkSize(main.getSize(), [600, 360], `Repeated right-edge drag: ${JSON.stringify(main.getBounds())}`);
      assert.equal(main.getBounds().x + main.getBounds().width, area.x + area.width);
    }
    cursor = { ...cursor, x: area.x + area.width - 250 };
    await delay(50);
    assert.ok(main.getBounds().x + main.getBounds().width < area.x + area.width - 50, 'Drag back from edge');
    ipcMain.emit('mini-drag', { sender: main.webContents }, false);
    screen.getCursorScreenPoint = originalCursor;
    for (const offset of [20, 80, 160]) {
      let prevented = false;
      main.emit('will-move', { preventDefault() { prevented = true; } }, { ...main.getBounds(), x: area.x + area.width - miniSize[0] + offset });
      assert.equal(prevented, true);
      assert.ok(Math.abs(main.getSize()[0] - 600) <= 1 && Math.abs(main.getSize()[1] - 360) <= 1, JSON.stringify(main.getSize()));
    }
    await main.webContents.executeJavaScript("document.getElementById('stripCloseButton').click()");
    await delay(250);
    assert.ok(Math.abs(main.getSize()[0] - 940) <= 4 && Math.abs(main.getSize()[1] - 660) <= 4);
    assert.equal(main.isAlwaysOnTop(), false);
    if (process.env.DDL_QA_DIR) {
      await main.webContents.executeJavaScript("document.getElementById('themeToggle').click()");
      main.show();
      main.focus();
      await delay(500);
      fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-dark.png'), (await main.webContents.capturePage()).toPNG());
    }
    assert.equal(await main.webContents.executeJavaScript("countdown({deadline: new Date(90061000).toISOString()}, 1000)"), '剩余 1天1小时1分钟');
    assert.equal(await main.webContents.executeJavaScript("countdown({deadline: new Date(86340000).toISOString()}, 0)"), '剩余 23小时59分钟');
    assert.equal(await main.webContents.executeJavaScript("countdown({deadline: new Date(0).toISOString()}, 3660000)"), '已逾期 1小时1分钟');
    assert.equal(await main.webContents.executeJavaScript("countdown({deadline: new Date(86400000).toISOString()}, 0)"), '剩余 1天0小时0分钟');
    assert.equal(await main.webContents.executeJavaScript("countdown({deadline: new Date(0).toISOString()}, 90060000)"), '已逾期 1天1小时1分钟');
    await main.webContents.executeJavaScript("document.getElementById('settingsButton').click(); document.getElementById('settingCompleted').click(); document.getElementById('settingMotion').click(); document.getElementById('settingSort').value='desc'; document.getElementById('settingSort').dispatchEvent(new Event('change',{bubbles:true}))");
    assert.equal(await main.webContents.executeJavaScript("document.querySelectorAll('#taskList .is-completed').length"), 0);
    await delay(350);
    assert.equal(await main.webContents.executeJavaScript("!document.getElementById('settingsPage').hidden && document.getElementById('content').hidden && !document.querySelector('dialog').open"), true);
    if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-settings.png'), (await main.webContents.capturePage()).toPNG());
    await main.webContents.executeJavaScript("document.getElementById('themeToggle').click()");
    assert.equal(await main.webContents.executeJavaScript("document.getElementById('settingTheme').value === document.documentElement.dataset.theme"), true);
    await main.webContents.executeJavaScript("document.getElementById('settingsClose').click()");
    const preferencesReload = new Promise(resolve => main.webContents.once('did-finish-load', resolve));
    main.webContents.reload(); await preferencesReload;
    assert.equal(await main.webContents.executeJavaScript("settings.showCompleted === false && settings.motion === false && sortAscending === false"), true);
    await main.webContents.executeJavaScript("setFloatingMode(true)"); await delay(200);
    await widenFloating();
    checkSize(main.getSize(), [600, 72]);
    const work = screen.getDisplayMatching(main.getBounds()).workArea;
    main.setPosition(work.x + 10, work.y + work.height - 72);
    await main.webContents.executeJavaScript("document.getElementById('stripLockButton').click(); setExpanded(true)"); await delay(250);
    assert.ok(main.getBounds().y + main.getBounds().height <= work.y + work.height + 1);
    checkSize(main.getSize(), [600, 360]);
    await main.webContents.executeJavaScript("document.getElementById('stripLockButton').click(); setExpanded(false)"); await delay(100);
    main.center();
    const resizeCursorOriginal = screen.getCursorScreenPoint;
    let resizeCursor = {x:500,y:500}; screen.getCursorScreenPoint=()=>resizeCursor;
    async function resize(edge, dx, dy) {
      ipcMain.emit('mini-resize', {sender:main.webContents}, edge);
      resizeCursor={x:resizeCursor.x+dx,y:resizeCursor.y+dy}; await delay(80);
      ipcMain.emit('mini-resize', {sender:main.webContents}, null); await delay(100);
    }
    await resize('e', -500, 0); checkSize(main.getSize(),[360,72]);
    assert.equal(await main.webContents.executeJavaScript("getComputedStyle(document.querySelector('.preview-task:nth-child(2)')).display"),'none');
    assert.equal(await main.webContents.executeJavaScript("[...document.querySelectorAll('.strip-header button')].every(b=>{const r=b.getBoundingClientRect();return r.left>=0 && r.right<=innerWidth})"),true);
    if (process.env.DDL_QA_DIR) fs.writeFileSync(path.join(process.env.DDL_QA_DIR, 'ddl-minimum.png'), (await main.webContents.capturePage()).toPNG());
    main.center(); await resize('se', 120, 180); checkSize(main.getSize(),[480,252]);
    assert.equal(await main.webContents.executeJavaScript("expanded && !document.getElementById('stripDetails').hidden"),true);
    const beforeDrag=main.getSize();ipcMain.emit('mini-drag',{sender:main.webContents},true);resizeCursor.x+=30;await delay(100);ipcMain.emit('mini-drag',{sender:main.webContents},false);checkSize(main.getSize(),beforeDrag);
    await main.webContents.executeJavaScript("document.getElementById('stripLockButton').click()");await delay(50);
    await resize('e',100,0);checkSize(main.getSize(),beforeDrag);
    await main.webContents.executeJavaScript("document.getElementById('stripLockButton').click()");await delay(50);
    for(const edge of ['n','s','e','w','ne','nw','se','sw']) {main.center();await resize(edge,edge.includes('w')?-10:10,edge.includes('n')?-10:10);assert.ok(main.getSize()[0]>=360&&main.getSize()[1]>=72);}
    screen.getCursorScreenPoint=resizeCursorOriginal;
    await main.webContents.executeJavaScript("setFloatingMode(false); document.getElementById('windowMaximize').click()");await delay(200);assert.equal(await main.webContents.executeJavaScript("document.getElementById('windowMaximize').title === '还原窗口'"),true);
    await main.webContents.executeJavaScript("setFloatingMode(true)");await delay(150);await main.webContents.executeJavaScript("setFloatingMode(false)");await delay(200);assert.equal(await main.webContents.executeJavaScript("document.getElementById('windowMaximize').title === '还原窗口'"),true);
    await main.webContents.executeJavaScript("setFloatingMode(true)");await delay(100);
    await require('./v19-checks.cjs')(main);
    await require('./v20-checks.cjs')(main);
    await require('./v201-checks.cjs')(main);
    await require('./v202-checks.cjs')(main);
    await require('./v203-checks.cjs')(main);
    await main.webContents.executeJavaScript("desktop.saveCloseBehavior('quit')");
    const closed = new Promise(resolve=>main.once('closed',resolve));
    await main.webContents.executeJavaScript("document.getElementById('stripExitButton').click()"); await closed;
    console.log('PASS: v1.8 readable single-task layout, neutral completion animation, date/control separation, centered SVG plus icons, explicit sort toggle; all previous resize, picker, persistence and window regression checks');
    app.exit(0);
  } catch (error) { console.error(error); app.exit(1); }
});


