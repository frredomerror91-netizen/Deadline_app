function constrain(bounds, area, threshold = 16) {
  const right = area.x + area.width - bounds.width;
  const bottom = area.y + area.height - bounds.height;
  let x = Math.max(area.x, Math.min(bounds.x, right));
  let y = Math.max(area.y, Math.min(bounds.y, bottom));
  if (x - area.x <= threshold) x = area.x;
  if (right - x <= threshold) x = right;
  if (y - area.y <= threshold) y = area.y;
  if (bottom - y <= threshold) y = bottom;
  return { ...bounds, x, y };
}
function editorBounds(strip, area) {
  const width = Math.min(480, area.width), height = Math.min(270, area.height);
  return { x: area.x + Math.round((area.width-width)/2), y: area.y + Math.round((area.height-height)/2), width, height };
}
module.exports = { constrain, editorBounds };
