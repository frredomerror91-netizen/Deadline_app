const { app, BrowserWindow, ipcMain, screen } = require('electron');
const path = require('path');

const language = require('./native-language');
const { t } = language;
let mainWindow, lifecycle, rendererReady = false;
app.setAppUserModelId('com.deadlinedesk.app');
let updater;
for (const [channel, method] of [['update-status', 'status'], ['update-check', 'check'], ['update-install', 'install']]) {
  ipcMain.handle(channel, (event) => {
    if (!mainWindow || event.sender !== mainWindow.webContents || !updater) throw new Error(t('无效的更新请求'));
    return updater[method]();
  });
}
const primaryInstance = app.requestSingleInstanceLock();
let pendingAction = process.argv.includes('--settings') ? 'settings' : process.argv.includes('--layer-menu') ? 'layer' : '';
let pendingAdd = process.argv.includes('--add-task');
function openDesktopEditor() {
  if (!mainWindow || !rendererReady) { pendingAdd = true; return; }
  floatingSettings.activate(); mainWindow.restore(); mini.reveal(); mainWindow.show(); mini.openEditor();
  pendingAdd = false;
}
app.on('second-instance', (_event, argv) => {
  if (argv.includes('--add-task')) openDesktopEditor();
  else if (argv.includes('--settings') || argv.includes('--layer-menu')) {
    if (!lifecycle || !rendererReady) { pendingAction = argv.includes('--settings') ? 'settings' : 'layer'; return; }
    lifecycle.dispatch(argv.includes('--settings') ? 'settings' : 'layer');
  }
  else if (mainWindow) { mainWindow.restore(); mini.reveal(); mainWindow.show(); mainWindow.focus(); }
});
let desktopMenu, menuReady, quitting = false;
let menuError = '';
ipcMain.handle('desktop-menu', async (event, repair) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) return {ok:false,error:t('无效请求')};
  if (process.env.DDL_TEST) return {ok:true};
  try {
    await Promise.resolve(menuReady).catch(() => {});
    if (repair) { menuReady=desktopMenu.install(); await menuReady; menuError=''; }
    return await desktopMenu.status();
  } catch(error) { return {ok:false,error:menuError || error.message}; }
});
app.on('before-quit', event => {
  lifecycle?.allowQuit();
  if (!desktopMenu || quitting) return;
  event.preventDefault(); quitting = true;
  Promise.resolve(menuReady).then(() => desktopMenu.remove()).catch(error => console.error(t('桌面菜单清理失败:'), error.message)).finally(() => app.quit());
});
let normalBounds;
let floating = false;
let wasMaximized = false;
let mini, floatingSettings;
let maximized = false, restoreBounds;
function setMaximized(value) {
  if (value === maximized) return;
  if (value) {
    restoreBounds = mainWindow.getBounds();
    mainWindow.setBounds(screen.getDisplayMatching(restoreBounds).workArea);
  } else if (restoreBounds) mainWindow.setBounds(restoreBounds);
  maximized = value;
  mainWindow.webContents.send('window-maximized', value);
}

ipcMain.on('get-language-sync', event => { event.returnValue = language.get(); });
ipcMain.handle('save-language', async (event, value) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) throw new Error('Invalid sender');
  language.save(value);
  lifecycle?.refreshLanguage();
  if (desktopMenu) { menuReady = Promise.resolve(menuReady).then(() => desktopMenu.install()); await menuReady.catch(error => { menuError = error.message; }); }
  const editor = mini?.getEditor(); if (editor) editor.reload();
  return language.get();
});
function createWindow() {
  mainWindow = new BrowserWindow({
    show: false,
    width: 940,
    height: 660,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#00000000',
    transparent: true,
    icon: path.join(__dirname, 'app-icon.png'),
    frame: false,
    thickFrame: false,
    hasShadow: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  require('./window-motion')(mainWindow);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mini = require('./mini-window')(mainWindow, () => floating);
  floatingSettings = require('./floating-settings')(app, mainWindow, () => floating, mini);
  lifecycle = require('./window-lifecycle')({ app, win: mainWindow, mini, floatingSettings, openDesktopEditor });
  if (!updater) updater = require('./updater').createUpdater({
    version: app.isPackaged ? app.getVersion() : require('./package.json').version,
    target: process.env.PORTABLE_EXECUTABLE_FILE,
    enabled: app.isPackaged && process.platform === 'win32' && !process.env.DDL_TEST,
    directory: path.join(app.getPath('userData'), 'updates'),
    fetch: (...args) => require('electron').net.fetch(...args),
    quit: () => app.quit(),
    notify: state => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('update-state', state); }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  const sendState = () => mainWindow.webContents.send('window-maximized', maximized);
  mainWindow.webContents.on('did-start-loading', () => { rendererReady = false; });
  mainWindow.webContents.on('did-finish-load', () => { rendererReady = true; sendState(); if (pendingAdd) openDesktopEditor(); if (pendingAction) { lifecycle.dispatch(pendingAction); pendingAction = ''; } });
  mainWindow.on('closed', () => { mainWindow = null; });
}

ipcMain.on('set-floating-mode', (event, enabled) => {
  if (!mainWindow || event.sender !== mainWindow.webContents || typeof enabled !== 'boolean' || enabled === floating) return;
  mini.reveal();
  floating = enabled;
  if (enabled) {
    wasMaximized = maximized;
    if (wasMaximized) setMaximized(false);
    normalBounds = mainWindow.getBounds();
    mainWindow.setAlwaysOnTop(true, 'floating');
    mainWindow.setMinimumSize(360, 72);
    mainWindow.setMaximumSize(0, 0);
    mainWindow.setSize(360, 72);
    mainWindow.setResizable(false);
    const area = screen.getDisplayMatching(normalBounds).workArea;
    mainWindow.setPosition(area.x + area.width - 360, area.y);
  } else {
    mainWindow.setAlwaysOnTop(false);
    mainWindow.setResizable(true);
    mainWindow.setMaximumSize(0, 0);
    mainWindow.setMinimumSize(760, 520);
    if (normalBounds) mainWindow.setBounds(normalBounds, true);
    if (wasMaximized) setMaximized(true);
  }
  mini.modeChanged();
  floatingSettings.apply();
});

ipcMain.on('window-action', (event, action) => {
  if (!mainWindow || event.sender !== mainWindow.webContents) return;
  if (action === 'close') mainWindow.close();
  if (action === 'minimize') mainWindow.webContents.send('window-minimizing');
  if (action === 'maximize' && !floating) {
    setMaximized(!maximized);
  }
});

app.whenReady().then(() => {
  if (!primaryInstance) { app.quit(); return; }
  createWindow();
  if (!process.env.DDL_TEST) {
    desktopMenu = require('./desktop-menu')(app);
    menuReady = desktopMenu.install().catch(error => {
      menuError=error.message; console.error(error);
      require('electron').dialog.showMessageBox(mainWindow, { type:'warning', message:t('桌面右键添加任务菜单未能启用'), detail:t('请检查当前用户的注册表访问权限。应用内仍可正常添加任务。') });
    });
  }
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
