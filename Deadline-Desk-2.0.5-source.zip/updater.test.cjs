const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const execFile = promisify(require('node:child_process').execFile);
const { createUpdater, selectRelease, isNewer, download, REPOSITORY } = require('./updater');
const content = Buffer.from('MZ simulated executable');
const digest = crypto.createHash('sha256').update(content).digest('hex');
const fixture = () => ({ tag_name: 'v2.0.4', assets: [{ name: 'Deadline-Desk-2.0.4.exe', size: content.length,
  browser_download_url: `https://github.com/${REPOSITORY}/releases/download/v2.0.4/Deadline-Desk-2.0.4.exe`, digest: `sha256:${digest}` }] });
const temp = () => fs.mkdtemp(path.join(os.tmpdir(), 'ddl-update-test-'));

test('semantic version order, stable releases and trusted asset selection', () => {
  assert.equal(REPOSITORY, 'frredomerror91-netizen/Deadline_app');
  const oldRepository = fixture();
  oldRepository.assets[0].browser_download_url = 'https://github.com/frredomerror91-netizen/AgentProject/releases/download/v2.0.4/Deadline-Desk-2.0.4.exe';
  assert.throws(() => selectRelease(oldRepository, '2.0.3'));
  assert.equal(isNewer('v2.0.10', '2.0.9'), true);
  assert.equal(isNewer('v2.0.3', '2.0.3'), false);
  assert.equal(isNewer('v1.9.9', '2.0.3'), false);
  assert.throws(() => isNewer('v2.1.0-beta', '2.0.3'));
  assert.equal(selectRelease(fixture(), '2.0.4'), null);
  assert.equal(selectRelease(fixture(), '2.0.3').digest, digest);
  assert.throws(() => selectRelease({ ...fixture(), prerelease: true }, '2.0.3'));
  const invalid = fixture(); invalid.assets[0].browser_download_url = 'https://example.com/file.exe';
  assert.throws(() => selectRelease(invalid, '2.0.3'));
  const noHash = fixture(); delete noHash.assets[0].digest;
  assert.throws(() => selectRelease(noHash, '2.0.3'));
  assert.throws(() => selectRelease({ ...fixture(), assets: [] }, '2.0.3'));
});

test('download validates size, executable header and checksum, including sidecar fallback', async () => {
  const dir = await temp(), release = selectRelease(fixture(), '2.0.3');
  const progress = [];
  assert.equal(await download(async () => new Response(content), release, path.join(dir, 'ok.exe'), p => progress.push(p)), digest);
  assert.equal(progress.at(-1), 100);
  for (const [name, data] of [['truncated', content.subarray(0, 5)], ['oversized', Buffer.concat([content, content])],
    ['corrupt', Buffer.from('MZ changed executable!!')], ['html', Buffer.alloc(content.length, 65)]]) {
    await assert.rejects(download(async () => new Response(data), release, path.join(dir, name + '.exe'), () => {}));
  }
  await download(async url => new Response(url === 'checksum' ? `${digest}  ${release.name}\n` : content),
    { ...release, digest: null, checksumURL: 'checksum' }, path.join(dir, 'sidecar.exe'), () => {});
  await assert.rejects(download(async () => new Response(`${digest}  other.exe`),
    { ...release, digest: null, checksumURL: 'checksum' }, path.join(dir, 'bad-sidecar.exe'), () => {}));
});

test('check failure can retry; successful install is serialized and only quits after helper is ready', async () => {
  const dir = await temp(); let calls = 0, quit = 0, launched = 0, configured;
  const updater = createUpdater({ version: '2.0.3', target: path.join(dir, 'Deadline.exe'), directory: dir, enabled: true,
    fetch: async url => { calls++; if (calls === 1) throw new Error('offline'); return new Response(url.includes('/releases/latest') ? JSON.stringify(fixture()) : content); },
    launchHelper: async (job, config) => { launched++; configured = config; assert.equal(quit, 0); await new Promise(resolve => setTimeout(resolve, 30)); },
    quit: () => { quit++; } });
  assert.equal((await updater.check()).phase, 'error');
  assert.equal((await updater.check()).phase, 'available');
  await Promise.all([updater.install(), updater.install(), updater.check()]);
  assert.equal(quit, 1); assert.equal(launched, 1); assert.equal(configured.digest, digest);
  assert.equal((await updater.status()).phase, 'installing');
  assert.equal(await fs.readFile(path.join(path.dirname(configured.source), 'commit'), 'utf8'), 'commit');
  await updater.install(); assert.equal(quit, 1);
});

test('failed integrity or helper startup never exits or replaces the current application', async () => {
  for (const failure of ['checksum', 'helper']) {
    const dir = await temp(); let quit = false;
    const target = path.join(dir, 'original.exe'); await fs.writeFile(target, 'original');
    const updater = createUpdater({ version: '2.0.3', target, directory: dir, enabled: true,
      fetch: async url => new Response(url.includes('/releases/latest') ? JSON.stringify(fixture()) : failure === 'checksum' ? 'MZ wrong' : content),
      launchHelper: async () => { throw new Error('helper unavailable'); }, quit: () => { quit = true; } });
    await updater.check(); assert.equal((await updater.install()).phase, 'error');
    assert.equal(quit, false); assert.equal(await fs.readFile(target, 'utf8'), 'original');
    const job = (await fs.readdir(dir)).find(name => name.startsWith('job-'));
    assert.equal(await fs.readFile(path.join(dir, job, 'cancelled'), 'utf8'), 'cancelled');
    await assert.rejects(fs.stat(path.join(dir, job, 'download.exe')));
  }
});

test('Windows helper replaces and starts portable executable, and rolls back startup failure', { skip: process.platform !== 'win32' }, async () => {
  const dir = await temp();
  const powershell = path.join(process.env.SystemRoot, 'System32/WindowsPowerShell/v1.0/powershell.exe');
  for (const exitCode of [0, 7]) {
    const job = path.join(dir, `space ' dollar $ ${exitCode}`); await fs.mkdir(job);
    const target = path.join(job, 'Deadline Desk.exe'), source = path.join(job, 'download.exe');
    const quote = value => "'" + value.replace(/'/g, "''") + "'";
    for (const [file, code] of [[target, 0], [source, exitCode]]) {
      await execFile(powershell, ['-NoProfile', '-NonInteractive', '-Command',
        `Add-Type -TypeDefinition 'public class Program { public static int Main() { return ${code}; } }' -OutputAssembly ${quote(file)} -OutputType WindowsApplication`], { windowsHide: true });
    }
    const original = await fs.readFile(target), next = await fs.readFile(source);
    const config = { target, source, digest: crypto.createHash('sha256').update(next).digest('hex'), pid: 2147483647, result: path.join(job, 'result.json') };
    await fs.writeFile(path.join(job, 'update.json'), JSON.stringify(config)); await fs.writeFile(path.join(job, 'commit'), 'commit');
    await execFile(powershell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'update-helper.ps1'), '-ConfigPath', path.join(job, 'update.json')], { windowsHide: true, timeout: 30000 });
    const result = JSON.parse((await fs.readFile(config.result, 'utf8')).replace(/^\uFEFF/, ''));
    assert.equal(result.ok, exitCode === 0, JSON.stringify(result));
    assert.deepEqual(await fs.readFile(target), exitCode === 0 ? next : original);
    if (exitCode === 0) assert.deepEqual(await fs.readFile(result.backup), original);
  }
});
