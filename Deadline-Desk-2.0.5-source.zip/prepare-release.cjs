const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process'),{createRequire}=require('node:module');
const pkg=require('./package.json'),base=`Deadline-Desk-${pkg.version}`,out=path.join(__dirname,'dist',`github-v${pkg.version}`);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const br=createRequire(require.resolve('electron-builder')),asar=createRequire(br.resolve('app-builder-lib'))('@electron/asar');
const archive=path.join(__dirname,'dist/win-unpacked/resources/app.asar');
assert.equal(JSON.parse(asar.extractFile(archive,'package.json')).version,pkg.version);
for(const f of pkg.build.files.filter(f=>f!=='package.json'))assert.equal(hash(asar.extractFile(archive,f)),hash(fs.readFileSync(path.join(__dirname,f))),f);
fs.mkdirSync(out,{recursive:true});const exe=fs.readFileSync(path.join(__dirname,'dist',base+'.exe'));fs.writeFileSync(path.join(out,base+'.exe'),exe);
for(const dir of [out,path.join(__dirname,'dist')])fs.writeFileSync(path.join(dir,base+'.exe.sha256'),hash(exe)+'  '+base+'.exe\n');
const files=fs.readdirSync(__dirname,{withFileTypes:true}).filter(f=>f.isFile()&&/\.(js|cjs|css|html|png|json|yaml|ps1|md)$/.test(f.name)).map(f=>f.name);
execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',`
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$files=$env:DDL_FILES|ConvertFrom-Json
$zipPath=Join-Path $env:DDL_OUT ($env:DDL_BASE+'-source.zip')
if(Test-Path -LiteralPath $zipPath){Remove-Item -LiteralPath $zipPath}
$zip=[IO.Compression.ZipFile]::Open($zipPath,'Create')
try {foreach($f in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $env:DDL_ROOT $f),$f)|Out-Null}}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
$sha=[Security.Cryptography.SHA256]::Create()
try {
if($zip.Entries.Count -ne $files.Count){throw 'ZIP count mismatch'}
foreach($e in $zip.Entries){
if($files -cnotcontains $e.FullName){throw 'Unexpected entry'}
$s=$e.Open();try{$a=[BitConverter]::ToString($sha.ComputeHash($s))}finally{$s.Dispose()}
$s=[IO.File]::OpenRead((Join-Path $env:DDL_ROOT $e.FullName));try{$b=[BitConverter]::ToString($sha.ComputeHash($s))}finally{$s.Dispose()}
if($a -ne $b){throw ('ZIP mismatch: '+$e.FullName)}
}
}finally{$zip.Dispose();$sha.Dispose()}
`],{windowsHide:true,env:{...process.env,DDL_ROOT:__dirname,DDL_OUT:out,DDL_BASE:base,DDL_FILES:JSON.stringify(files)}});
console.log(`Verified v${pkg.version}: packed source, EXE SHA-256 and ${files.length} ZIP entries. ${out}`);
